[wui.basic](../README.md) / [Exports](../modules.md) / GradientColor

# Class: GradientColor

## Table of contents

### Constructors

- [constructor](GradientColor.md#constructor)

### Properties

- [m\_gradient](GradientColor.md#m_gradient)

### Accessors

- [gradient](GradientColor.md#gradient)

### Methods

- [addColorStop](GradientColor.md#addcolorstop)
- [forEach](GradientColor.md#foreach)

## Constructors

### constructor

• **new GradientColor**()

#### Defined in

painting/gradientcolor.ts:6

## Properties

### m\_gradient

• `Private` **m\_gradient**: `Map`<`number`, [`Color`](Color.md)\>

#### Defined in

painting/gradientcolor.ts:4

## Accessors

### gradient

• `get` **gradient**(): `Map`<`number`, [`Color`](Color.md)\>

#### Returns

`Map`<`number`, [`Color`](Color.md)\>

#### Defined in

painting/gradientcolor.ts:13

## Methods

### addColorStop

▸ **addColorStop**(`position`, `color`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `position` | `number` |
| `color` | [`Color`](Color.md) |

#### Returns

`void`

#### Defined in

painting/gradientcolor.ts:9

___

### forEach

▸ **forEach**(`callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `callback` | (`value`: [`Color`](Color.md), `key`: `number`) => `void` |

#### Returns

`void`

#### Defined in

painting/gradientcolor.ts:17
