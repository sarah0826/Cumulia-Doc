[wui.basic](../README.md) / [Exports](../modules.md) / LeftArrow

# Class: LeftArrow

The LeftArrow is a left arrow.

## Hierarchy

- [`Icon`](Icon.md)

  ↳ **`LeftArrow`**

## Table of contents

### Constructors

- [constructor](LeftArrow.md#constructor)

### Properties

- [m\_children](LeftArrow.md#m_children)
- [m\_content](LeftArrow.md#m_content)
- [m\_dom](LeftArrow.md#m_dom)
- [m\_parent](LeftArrow.md#m_parent)

### Accessors

- [blocked](LeftArrow.md#blocked)
- [children](LeftArrow.md#children)
- [css](LeftArrow.md#css)
- [dom](LeftArrow.md#dom)
- [enabled](LeftArrow.md#enabled)
- [height](LeftArrow.md#height)
- [id](LeftArrow.md#id)
- [left](LeftArrow.md#left)
- [parent](LeftArrow.md#parent)
- [position](LeftArrow.md#position)
- [rect](LeftArrow.md#rect)
- [scale](LeftArrow.md#scale)
- [size](LeftArrow.md#size)
- [source](LeftArrow.md#source)
- [style](LeftArrow.md#style)
- [tooltip](LeftArrow.md#tooltip)
- [top](LeftArrow.md#top)
- [visible](LeftArrow.md#visible)
- [width](LeftArrow.md#width)
- [sender](LeftArrow.md#sender)

### Methods

- [addAttr](LeftArrow.md#addattr)
- [addClass](LeftArrow.md#addclass)
- [attach](LeftArrow.md#attach)
- [bind](LeftArrow.md#bind)
- [clearChildren](LeftArrow.md#clearchildren)
- [close](LeftArrow.md#close)
- [delegate](LeftArrow.md#delegate)
- [destroy](LeftArrow.md#destroy)
- [detach](LeftArrow.md#detach)
- [emit](LeftArrow.md#emit)
- [free](LeftArrow.md#free)
- [hasAttr](LeftArrow.md#hasattr)
- [hasClass](LeftArrow.md#hasclass)
- [hide](LeftArrow.md#hide)
- [insertChild](LeftArrow.md#insertchild)
- [raise](LeftArrow.md#raise)
- [removeAttr](LeftArrow.md#removeattr)
- [removeClass](LeftArrow.md#removeclass)
- [setFlex](LeftArrow.md#setflex)
- [show](LeftArrow.md#show)
- [toggleAttr](LeftArrow.md#toggleattr)
- [toggleClass](LeftArrow.md#toggleclass)
- [unbind](LeftArrow.md#unbind)

## Constructors

### constructor

• **new LeftArrow**(`parent?`)

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent?` | [`Widget`](Widget.md) |

#### Overrides

[Icon](Icon.md).[constructor](Icon.md#constructor)

#### Defined in

widget/icon.ts:208

## Properties

### m\_children

• `Protected` **m\_children**: [`Widget`](Widget.md)[] = `[]`

#### Inherited from

[Icon](Icon.md).[m_children](Icon.md#m_children)

#### Defined in

widget/widget.ts:15

___

### m\_content

• `Protected` **m\_content**: [`Widget`](Widget.md)

#### Inherited from

[Icon](Icon.md).[m_content](Icon.md#m_content)

#### Defined in

widget/widget.ts:14

___

### m\_dom

• `Protected` **m\_dom**: `HTMLElement`

#### Inherited from

[Icon](Icon.md).[m_dom](Icon.md#m_dom)

#### Defined in

widget/widget.ts:12

___

### m\_parent

• `Protected` **m\_parent**: [`Widget`](Widget.md)

#### Inherited from

[Icon](Icon.md).[m_parent](Icon.md#m_parent)

#### Defined in

widget/widget.ts:13

## Accessors

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Inherited from

Icon.blocked

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Inherited from

Icon.blocked

#### Defined in

abstract/eventwatcher.ts:85

___

### children

• `get` **children**(): readonly [`Widget`](Widget.md)[]

Returns the list of children.

#### Returns

readonly [`Widget`](Widget.md)[]

#### Inherited from

Icon.children

#### Defined in

widget/widget.ts:104

___

### css

• `set` **css**(`style`): `void`

Sets the style of this widget. See also [id](Widget.md#id) [addClass](Widget.md#addclass).

#### Parameters

| Name | Type |
| :------ | :------ |
| `style` | `Partial`<[`StyleSheets`](../interfaces/StyleSheets.md)\> |

#### Returns

`void`

#### Inherited from

Icon.css

#### Defined in

widget/widget.ts:244

___

### dom

• `get` **dom**(): `HTMLElement`

Returns the dom of this widget.

#### Returns

`HTMLElement`

#### Inherited from

Icon.dom

#### Defined in

widget/widget.ts:111

___

### enabled

• `get` **enabled**(): `boolean`

Returns whether this widget or its parent chain is enabled or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

Icon.enabled

#### Defined in

widget/widget.ts:207

• `set` **enabled**(`enabled`): `void`

Sets whether this widget is enabled or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `enabled` | `boolean` |

#### Returns

`void`

#### Inherited from

Icon.enabled

#### Defined in

widget/widget.ts:214

___

### height

• `get` **height**(): `number`

Returns the height of this widget.

#### Returns

`number`

#### Inherited from

Icon.height

#### Defined in

widget/widget.ts:160

• `set` **height**(`height`): `void`

Sets the height of this widget to the given height.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `height` | `number` | The unit of height is px. |

#### Returns

`void`

#### Inherited from

Icon.height

#### Defined in

widget/widget.ts:177

___

### id

• `get` **id**(): `string`

Returns the id of this widget.

#### Returns

`string`

#### Inherited from

Icon.id

#### Defined in

widget/widget.ts:221

• `set` **id**(`id`): `void`

Set the id of this widget to the given id.
The id is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `id` | `string` |

#### Returns

`void`

#### Inherited from

Icon.id

#### Defined in

widget/widget.ts:230

___

### left

• `get` **left**(): `number`

Returns the left coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

Icon.left

#### Defined in

widget/widget.ts:280

• `set` **left**(`left`): `void`

Sets the left coordinate of this widget to the given left.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `left` | `number` | The unit of left is px. |

#### Returns

`void`

#### Inherited from

Icon.left

#### Defined in

widget/widget.ts:273

___

### parent

• `get` **parent**(): [`Widget`](Widget.md)

Returns the parent of this widget, or undefined if it does not have any parent widget.

#### Returns

[`Widget`](Widget.md)

#### Inherited from

Icon.parent

#### Defined in

widget/widget.ts:85

• `set` **parent**(`parent`): `void`

Sets the parent of the widget to the given parent.
If the new parent widget is the old parent widget, this function does nothing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

Icon.parent

#### Defined in

widget/widget.ts:93

___

### position

• `get` **position**(): [`Point`](Point.md)

Returns the position of this widget relative to its parent.

#### Returns

[`Point`](Point.md)

#### Inherited from

Icon.position

#### Defined in

widget/widget.ts:311

• `set` **position**(`position`): `void`

Sets the position of this widget to the given position.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `position` | [`Point`](Point.md) | The unit of position is px. |

#### Returns

`void`

#### Inherited from

Icon.position

#### Defined in

widget/widget.ts:303

___

### rect

• `get` **rect**(): [`Rect`](Rect.md)

Returns the rect of this widget relative to the desktop.

#### Returns

[`Rect`](Rect.md)

#### Inherited from

Icon.rect

#### Defined in

widget/widget.ts:318

___

### scale

• `get` **scale**(): [`ScaleSize`](../enums/ScaleSize.md)

Returns the size mode of this icon.

#### Returns

[`ScaleSize`](../enums/ScaleSize.md)

#### Inherited from

Icon.scale

#### Defined in

widget/icon.ts:52

• `set` **scale**(`scale`): `void`

Sets the size mode of this icon to the given scale. 
This icon's default size is Size(16, 16). When in large icon mode, the size of this icon is Size(32, 32).

#### Parameters

| Name | Type |
| :------ | :------ |
| `scale` | [`ScaleSize`](../enums/ScaleSize.md) |

#### Returns

`void`

#### Inherited from

Icon.scale

#### Defined in

widget/icon.ts:60

___

### size

• `get` **size**(): [`Size`](Size.md)

Returns the size of this widget.

#### Returns

[`Size`](Size.md)

#### Inherited from

Icon.size

#### Defined in

widget/widget.ts:118

• `set` **size**(`size`): `void`

Sets the size of this widget to the given size.
If the size is Size(0, 0) will cause the widget to not appear on screen.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `size` | [`Size`](Size.md) | The unit of size is px. |

#### Returns

`void`

#### Inherited from

Icon.size

#### Defined in

widget/widget.ts:128

___

### source

• `get` **source**(): `string`

Returns the source of this icon.

#### Returns

`string`

#### Inherited from

Icon.source

#### Defined in

widget/icon.ts:24

• `set` **source**(`source`): `void`

Sets the source of this icon to the given source, it is usually an address or URL. 
In a few cases, the source is font icon if it begins with '&#'.

#### Parameters

| Name | Type |
| :------ | :------ |
| `source` | `string` |

#### Returns

`void`

#### Inherited from

Icon.source

#### Defined in

widget/icon.ts:32

___

### style

• `get` **style**(): `CSSStyleDeclaration`

Returns the style of this widget.

#### Returns

`CSSStyleDeclaration`

#### Inherited from

Icon.style

#### Defined in

widget/widget.ts:237

___

### tooltip

• `get` **tooltip**(): `string`

Returns the tooltip of this widget.
By default, the value of this property is an empty string.

#### Returns

`string`

#### Inherited from

Icon.tooltip

#### Defined in

widget/widget.ts:254

• `set` **tooltip**(`tooltip`): `void`

Sets the tooltip of this widget to the given tooltip.

#### Parameters

| Name | Type |
| :------ | :------ |
| `tooltip` | `string` |

#### Returns

`void`

#### Inherited from

Icon.tooltip

#### Defined in

widget/widget.ts:261

___

### top

• `get` **top**(): `number`

Returns the top coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

Icon.top

#### Defined in

widget/widget.ts:295

• `set` **top**(`top`): `void`

Sets the top coordinate of this widget to the given top.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `top` | `number` | The unit of top is px. |

#### Returns

`void`

#### Inherited from

Icon.top

#### Defined in

widget/widget.ts:288

___

### visible

• `get` **visible**(): `boolean`

Returns whether this widget or its parent chain is visible or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

Icon.visible

#### Defined in

widget/widget.ts:185

• `set` **visible**(`visible`): `void`

Sets whether this widget is visible or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `visible` | `boolean` |

#### Returns

`void`

#### Inherited from

Icon.visible

#### Defined in

widget/widget.ts:192

___

### width

• `get` **width**(): `number`

Returns the width of this widget.

#### Returns

`number`

#### Inherited from

Icon.width

#### Defined in

widget/widget.ts:136

• `set` **width**(`width`): `void`

Sets the width of this widget to the given width.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `width` | `number` | The unit of width is px. |

#### Returns

`void`

#### Inherited from

Icon.width

#### Defined in

widget/widget.ts:153

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Inherited from

Icon.sender

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### addAttr

▸ **addAttr**(`attr`): `void`

Adds the attribute of this widget.
The attribute is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[addAttr](Icon.md#addattr)

#### Defined in

widget/widget.ts:375

___

### addClass

▸ **addClass**(`className`): `void`

Adds the class name of this widget.
The class name is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[addClass](Icon.md#addclass)

#### Defined in

widget/widget.ts:344

___

### attach

▸ `Protected` **attach**(): `void`

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[attach](Icon.md#attach)

#### Defined in

widget/widget.ts:461

___

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[bind](Icon.md#bind)

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[bind](Icon.md#bind)

#### Defined in

abstract/eventwatcher.ts:29

___

### clearChildren

▸ **clearChildren**(): `void`

Clears all widgets in the list of children.

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[clearChildren](Icon.md#clearchildren)

#### Defined in

widget/widget.ts:450

___

### close

▸ **close**(): `void`

Closes this widget.
This function is equivalent to setting this widget's parent to undefined.

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[close](Icon.md#close)

#### Defined in

widget/widget.ts:62

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[delegate](Icon.md#delegate)

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[delegate](Icon.md#delegate)

#### Defined in

abstract/eventwatcher.ts:68

___

### destroy

▸ **destroy**(): `void`

Destroys the widget, All the widget's children are destroyed first.

The widget is destroyed when it’s parent is destroyed. When the widget is destroyed, make sure to release all resources, such as timers, etc.
Releases the resources in function free(), The system will call this function automatically when the parent widget or itself is destroyed.
See also [free](Widget.md#free).

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[destroy](Icon.md#destroy)

#### Defined in

widget/widget.ts:40

___

### detach

▸ `Protected` **detach**(): `void`

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[detach](Icon.md#detach)

#### Defined in

widget/widget.ts:471

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Inherited from

[Icon](Icon.md).[emit](Icon.md#emit)

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Inherited from

[Icon](Icon.md).[emit](Icon.md#emit)

#### Defined in

abstract/eventwatcher.ts:49

___

### free

▸ `Protected` **free**(): `void`

Frees the resources.See also [destroy](Widget.md#destroy).

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[free](Icon.md#free)

#### Defined in

widget/widget.ts:55

___

### hasAttr

▸ **hasAttr**(`attr`): `boolean`

Returns whether this widget contains the attribute.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`boolean`

#### Inherited from

[Icon](Icon.md).[hasAttr](Icon.md#hasattr)

#### Defined in

widget/widget.ts:389

___

### hasClass

▸ **hasClass**(`className`): `boolean`

Returns whether this widget contains the class name.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`boolean`

#### Inherited from

[Icon](Icon.md).[hasClass](Icon.md#hasclass)

#### Defined in

widget/widget.ts:358

___

### hide

▸ **hide**(): `void`

Hides the widget and its child widgets.
This function is equivalent to setting the visible property to false.

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[hide](Icon.md#hide)

#### Defined in

widget/widget.ts:78

___

### insertChild

▸ **insertChild**(`index`, `widget`): `void`

Inserts the child widget at index in the list of children.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[insertChild](Icon.md#insertchild)

#### Defined in

widget/widget.ts:431

___

### raise

▸ **raise**(): `boolean`

Raises this widget to the top of the parent widget's children.
The display order of this widget is determined by the order in which they appear in the parent widget's children.

#### Returns

`boolean`

#### Inherited from

[Icon](Icon.md).[raise](Icon.md#raise)

#### Defined in

widget/widget.ts:406

___

### removeAttr

▸ **removeAttr**(`attr`): `void`

Removes the attribute of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[removeAttr](Icon.md#removeattr)

#### Defined in

widget/widget.ts:382

___

### removeClass

▸ **removeClass**(`className`): `void`

Removes the class name of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[removeClass](Icon.md#removeclass)

#### Defined in

widget/widget.ts:351

___

### setFlex

▸ **setFlex**(`orientation`, `alignItem?`, `spacing?`): `void`

Sets whether the widget uses flex layout.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `orientation` | [`Orientation`](../enums/Orientation.md) | Horizontal or vertical. |
| `alignItem?` | ``"center"`` \| ``"inherit"`` \| ``"stretch"`` \| ``"flex-start"`` \| ``"flex-end"`` \| ``"initial"`` \| ``"baseline"`` | @see(https://developer.mozilla.org/en-US/docs/Web/CSS/align-items) |
| `spacing?` | `number` | the spacing between widgets inside the layout. |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[setFlex](Icon.md#setflex)

#### Defined in

widget/widget.ts:329

___

### show

▸ **show**(): `void`

Shows the widget and its child widgets.
This function is equivalent to setting the visible property to true.

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[show](Icon.md#show)

#### Defined in

widget/widget.ts:70

___

### toggleAttr

▸ **toggleAttr**(`attr`, `on`): `void`

If param attr is true, adds the attribute, otherwise removes the attribute.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `attr` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[toggleAttr](Icon.md#toggleattr)

#### Defined in

widget/widget.ts:398

___

### toggleClass

▸ **toggleClass**(`className`, `on`): `void`

If param on is true, adds the class name, otherwise removes the class name.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `className` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[toggleClass](Icon.md#toggleclass)

#### Defined in

widget/widget.ts:367

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[unbind](Icon.md#unbind)

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[Icon](Icon.md).[unbind](Icon.md#unbind)

#### Defined in

abstract/eventwatcher.ts:38
