[wui.basic](../README.md) / [Exports](../modules.md) / EventWatcher

# Class: EventWatcher

The EventWatcher class is used to handle events.
When an event watcher emits an event, all of the callback functions binded to the event are called synchronously.

## Hierarchy

- **`EventWatcher`**

  ↳ [`Timer`](Timer.md)

  ↳ [`Widget`](Widget.md)

  ↳ [`ButtonGroup`](ButtonGroup.md)

  ↳ [`AbstractItemDelegate`](AbstractItemDelegate.md)

## Table of contents

### Constructors

- [constructor](EventWatcher.md#constructor)

### Properties

- [m\_blocked](EventWatcher.md#m_blocked)
- [m\_events](EventWatcher.md#m_events)
- [s\_sender](EventWatcher.md#s_sender)

### Accessors

- [blocked](EventWatcher.md#blocked)
- [sender](EventWatcher.md#sender)

### Methods

- [bind](EventWatcher.md#bind)
- [delegate](EventWatcher.md#delegate)
- [emit](EventWatcher.md#emit)
- [unbind](EventWatcher.md#unbind)

## Constructors

### constructor

• **new EventWatcher**()

Constructs an event watcher.

#### Defined in

abstract/eventwatcher.ts:15

## Properties

### m\_blocked

• `Private` **m\_blocked**: `boolean` = `false`

#### Defined in

abstract/eventwatcher.ts:9

___

### m\_events

• `Private` **m\_events**: `Map`<`string`, (...`data`: `any`[]) => `void`\>

#### Defined in

abstract/eventwatcher.ts:8

___

### s\_sender

▪ `Static` `Private` **s\_sender**: [`EventWatcher`](EventWatcher.md)

#### Defined in

abstract/eventwatcher.ts:10

## Accessors

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Defined in

abstract/eventwatcher.ts:85

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Defined in

abstract/eventwatcher.ts:29

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Defined in

abstract/eventwatcher.ts:68

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Defined in

abstract/eventwatcher.ts:49

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Defined in

abstract/eventwatcher.ts:38
