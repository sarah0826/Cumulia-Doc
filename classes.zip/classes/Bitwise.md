[wui.basic](../README.md) / [Exports](../modules.md) / Bitwise

# Class: Bitwise

## Table of contents

### Constructors

- [constructor](Bitwise.md#constructor)

### Methods

- [test](Bitwise.md#test)

## Constructors

### constructor

• **new Bitwise**()

## Methods

### test

▸ `Static` **test**(`value`, `bit`): `boolean`

Returns true if the flag bit is set, otherwise false.

#### Parameters

| Name | Type |
| :------ | :------ |
| `value` | `number` |
| `bit` | `number` |

#### Returns

`boolean`

#### Defined in

tools/bitwise.ts:5
