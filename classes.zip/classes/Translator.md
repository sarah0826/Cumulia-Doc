[wui.basic](../README.md) / [Exports](../modules.md) / Translator

# Class: Translator

The Translator class is a dictionary used to translate into other version.

## Table of contents

### Constructors

- [constructor](Translator.md#constructor)

### Properties

- [dictionary](Translator.md#dictionary)

## Constructors

### constructor

• **new Translator**()

## Properties

### dictionary

▪ `Static` **dictionary**: `Record`<`string`, `string`\> = `{}`

#### Defined in

start/translator.ts:5
