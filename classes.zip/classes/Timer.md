[wui.basic](../README.md) / [Exports](../modules.md) / Timer

# Class: Timer

The Timer class provides repetitive and single-shot timers.

## Hierarchy

- [`EventWatcher`](EventWatcher.md)

  ↳ **`Timer`**

## Table of contents

### Constructors

- [constructor](Timer.md#constructor)

### Properties

- [m\_active](Timer.md#m_active)
- [m\_id](Timer.md#m_id)
- [m\_interval](Timer.md#m_interval)
- [m\_singleShot](Timer.md#m_singleshot)

### Accessors

- [active](Timer.md#active)
- [blocked](Timer.md#blocked)
- [interval](Timer.md#interval)
- [singleShot](Timer.md#singleshot)
- [timerId](Timer.md#timerid)
- [sender](Timer.md#sender)

### Methods

- [bind](Timer.md#bind)
- [delegate](Timer.md#delegate)
- [destroyTimer](Timer.md#destroytimer)
- [emit](Timer.md#emit)
- [restart](Timer.md#restart)
- [start](Timer.md#start)
- [startTimer](Timer.md#starttimer)
- [stop](Timer.md#stop)
- [unbind](Timer.md#unbind)

## Constructors

### constructor

• **new Timer**()

Constructs a timer.

#### Overrides

[EventWatcher](EventWatcher.md).[constructor](EventWatcher.md#constructor)

#### Defined in

abstract/timer.ts:15

## Properties

### m\_active

• `Private` **m\_active**: `boolean` = `false`

#### Defined in

abstract/timer.ts:10

___

### m\_id

• `Private` **m\_id**: `number`

#### Defined in

abstract/timer.ts:9

___

### m\_interval

• `Private` **m\_interval**: `number` = `0`

#### Defined in

abstract/timer.ts:7

___

### m\_singleShot

• `Private` **m\_singleShot**: `boolean` = `false`

#### Defined in

abstract/timer.ts:8

## Accessors

### active

• `get` **active**(): `boolean`

Returns true if the timer is running; otherwise returns false.

#### Returns

`boolean`

#### Defined in

abstract/timer.ts:49

___

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Inherited from

EventWatcher.blocked

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Inherited from

EventWatcher.blocked

#### Defined in

abstract/eventwatcher.ts:85

___

### interval

• `get` **interval**(): `number`

Returns the timeout interval in milliseconds.
The default value for this property is 0. A timer with a timeout interval of 0 will time out as soon as all the events in the system's event queue have been processed.

#### Returns

`number`

#### Defined in

abstract/timer.ts:57

• `set` **interval**(`msec`): `void`

Sets the timeout interval of this timer.

#### Parameters

| Name | Type |
| :------ | :------ |
| `msec` | `number` |

#### Returns

`void`

#### Defined in

abstract/timer.ts:64

___

### singleShot

• `get` **singleShot**(): `boolean`

Returns whether the timer is a single-shot timer or not.

#### Returns

`boolean`

#### Defined in

abstract/timer.ts:29

• `set` **singleShot**(`singleShot`): `void`

Sets whether the timer is a single-shot timer or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `singleShot` | `boolean` |

#### Returns

`void`

#### Defined in

abstract/timer.ts:36

___

### timerId

• `get` **timerId**(): `number`

Returns the timer id.

#### Returns

`number`

#### Defined in

abstract/timer.ts:22

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Inherited from

EventWatcher.sender

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[bind](EventWatcher.md#bind)

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[bind](EventWatcher.md#bind)

#### Defined in

abstract/eventwatcher.ts:29

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[delegate](EventWatcher.md#delegate)

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[delegate](EventWatcher.md#delegate)

#### Defined in

abstract/eventwatcher.ts:68

___

### destroyTimer

▸ `Private` **destroyTimer**(): `void`

#### Returns

`void`

#### Defined in

abstract/timer.ts:89

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Inherited from

[EventWatcher](EventWatcher.md).[emit](EventWatcher.md#emit)

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Inherited from

[EventWatcher](EventWatcher.md).[emit](EventWatcher.md#emit)

#### Defined in

abstract/eventwatcher.ts:49

___

### restart

▸ **restart**(): `void`

Restarts this timer.

#### Returns

`void`

#### Defined in

abstract/timer.ts:128

___

### start

▸ **start**(`msec?`): `void`

Starts this timer with a timeout of msec milliseconds.

#### Parameters

| Name | Type |
| :------ | :------ |
| `msec?` | `number` |

#### Returns

`void`

#### Defined in

abstract/timer.ts:105

___

### startTimer

▸ `Private` **startTimer**(): `void`

#### Returns

`void`

#### Defined in

abstract/timer.ts:74

___

### stop

▸ **stop**(): `void`

Stops this timer.

#### Returns

`void`

#### Defined in

abstract/timer.ts:119

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[unbind](EventWatcher.md#unbind)

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[unbind](EventWatcher.md#unbind)

#### Defined in

abstract/eventwatcher.ts:38
