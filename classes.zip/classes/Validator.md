[wui.basic](../README.md) / [Exports](../modules.md) / Validator

# Class: Validator

The Validator class is validation of input text.

## Hierarchy

- **`Validator`**

  ↳ [`NumberValidator`](NumberValidator.md)

## Table of contents

### Constructors

- [constructor](Validator.md#constructor)

### Properties

- [m\_pattern](Validator.md#m_pattern)

### Accessors

- [pattern](Validator.md#pattern)

### Methods

- [fixup](Validator.md#fixup)
- [validate](Validator.md#validate)

## Constructors

### constructor

• **new Validator**(`pattern?`)

Constructs a validator with a regular expression.

#### Parameters

| Name | Type |
| :------ | :------ |
| `pattern?` | `RegExp` |

#### Defined in

validator/validator.ts:12

## Properties

### m\_pattern

• `Private` **m\_pattern**: `RegExp`

#### Defined in

validator/validator.ts:7

## Accessors

### pattern

• `get` **pattern**(): `RegExp`

Returns the regular expression of this validator.

#### Returns

`RegExp`

#### Defined in

validator/validator.ts:36

• `set` **pattern**(`pattern`): `void`

Sets the regular expression of this validator to pattern.

#### Parameters

| Name | Type |
| :------ | :------ |
| `pattern` | `RegExp` |

#### Returns

`void`

#### Defined in

validator/validator.ts:43

## Methods

### fixup

▸ **fixup**(`input`): `string`

This function attempts to change input to be valid according to this validator's rules.

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` |

#### Returns

`string`

#### Defined in

validator/validator.ts:29

___

### validate

▸ **validate**(`input`): [`ValidatorState`](../enums/ValidatorState.md)

Returns [Invalid](../enums/ValidatorState.md#invalid) if input is invalid according to this validator's rules, and [Acceptable](../enums/ValidatorState.md#acceptable) if the input is valid.

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` |

#### Returns

[`ValidatorState`](../enums/ValidatorState.md)

#### Defined in

validator/validator.ts:19
