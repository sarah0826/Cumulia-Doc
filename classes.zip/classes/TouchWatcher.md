[wui.basic](../README.md) / [Exports](../modules.md) / TouchWatcher

# Class: TouchWatcher

## Table of contents

### Constructors

- [constructor](TouchWatcher.md#constructor)

### Properties

- [lastTime](TouchWatcher.md#lasttime)

### Methods

- [start](TouchWatcher.md#start)
- [touched](TouchWatcher.md#touched)

## Constructors

### constructor

• **new TouchWatcher**()

## Properties

### lastTime

▪ `Static` `Private` **lastTime**: `number` = `0`

#### Defined in

capable/touchwatcher.ts:2

## Methods

### start

▸ `Static` **start**(): `void`

#### Returns

`void`

#### Defined in

capable/touchwatcher.ts:4

___

### touched

▸ `Static` **touched**(): `boolean`

#### Returns

`boolean`

#### Defined in

capable/touchwatcher.ts:8
