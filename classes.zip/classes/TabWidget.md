[wui.basic](../README.md) / [Exports](../modules.md) / TabWidget

# Class: TabWidget

The TabWidget class provides a stack of tabbed widgets. 
A tab widget provides a tab bar [TabBar](TabBar.md) and a page area that is used to display pages related to each tab. By default, the tab bar is shown above the page area.

## Hierarchy

- [`Widget`](Widget.md)

  ↳ **`TabWidget`**

## Table of contents

### Constructors

- [constructor](TabWidget.md#constructor)

### Properties

- [m\_children](TabWidget.md#m_children)
- [m\_content](TabWidget.md#m_content)
- [m\_dom](TabWidget.md#m_dom)
- [m\_parent](TabWidget.md#m_parent)
- [m\_stackedWidget](TabWidget.md#m_stackedwidget)
- [m\_tabBar](TabWidget.md#m_tabbar)

### Accessors

- [blocked](TabWidget.md#blocked)
- [children](TabWidget.md#children)
- [count](TabWidget.md#count)
- [css](TabWidget.md#css)
- [currentWidget](TabWidget.md#currentwidget)
- [dom](TabWidget.md#dom)
- [enabled](TabWidget.md#enabled)
- [height](TabWidget.md#height)
- [id](TabWidget.md#id)
- [index](TabWidget.md#index)
- [left](TabWidget.md#left)
- [parent](TabWidget.md#parent)
- [position](TabWidget.md#position)
- [rect](TabWidget.md#rect)
- [size](TabWidget.md#size)
- [style](TabWidget.md#style)
- [tabBar](TabWidget.md#tabbar)
- [tabPosition](TabWidget.md#tabposition)
- [tooltip](TabWidget.md#tooltip)
- [top](TabWidget.md#top)
- [visible](TabWidget.md#visible)
- [width](TabWidget.md#width)
- [sender](TabWidget.md#sender)

### Methods

- [add](TabWidget.md#add)
- [addAttr](TabWidget.md#addattr)
- [addClass](TabWidget.md#addclass)
- [at](TabWidget.md#at)
- [attach](TabWidget.md#attach)
- [bind](TabWidget.md#bind)
- [clear](TabWidget.md#clear)
- [clearChildren](TabWidget.md#clearchildren)
- [close](TabWidget.md#close)
- [delegate](TabWidget.md#delegate)
- [destroy](TabWidget.md#destroy)
- [detach](TabWidget.md#detach)
- [emit](TabWidget.md#emit)
- [free](TabWidget.md#free)
- [getTabEnabled](TabWidget.md#gettabenabled)
- [getTabIcon](TabWidget.md#gettabicon)
- [getTabText](TabWidget.md#gettabtext)
- [hasAttr](TabWidget.md#hasattr)
- [hasClass](TabWidget.md#hasclass)
- [hide](TabWidget.md#hide)
- [insert](TabWidget.md#insert)
- [insertChild](TabWidget.md#insertchild)
- [raise](TabWidget.md#raise)
- [remove](TabWidget.md#remove)
- [removeAttr](TabWidget.md#removeattr)
- [removeClass](TabWidget.md#removeclass)
- [setFlex](TabWidget.md#setflex)
- [setTabEnabled](TabWidget.md#settabenabled)
- [setTabIcon](TabWidget.md#settabicon)
- [setTabText](TabWidget.md#settabtext)
- [show](TabWidget.md#show)
- [toggleAttr](TabWidget.md#toggleattr)
- [toggleClass](TabWidget.md#toggleclass)
- [unbind](TabWidget.md#unbind)

## Constructors

### constructor

• **new TabWidget**(`parent?`)

Constructs a tabbed widget with parent.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent?` | [`Widget`](Widget.md) |

#### Overrides

[Widget](Widget.md).[constructor](Widget.md#constructor)

#### Defined in

container/tabwidget.ts:14

## Properties

### m\_children

• `Protected` **m\_children**: [`Widget`](Widget.md)[] = `[]`

#### Inherited from

[Widget](Widget.md).[m_children](Widget.md#m_children)

#### Defined in

widget/widget.ts:15

___

### m\_content

• `Protected` **m\_content**: [`Widget`](Widget.md)

#### Inherited from

[Widget](Widget.md).[m_content](Widget.md#m_content)

#### Defined in

widget/widget.ts:14

___

### m\_dom

• `Protected` **m\_dom**: `HTMLElement`

#### Inherited from

[Widget](Widget.md).[m_dom](Widget.md#m_dom)

#### Defined in

widget/widget.ts:12

___

### m\_parent

• `Protected` **m\_parent**: [`Widget`](Widget.md)

#### Inherited from

[Widget](Widget.md).[m_parent](Widget.md#m_parent)

#### Defined in

widget/widget.ts:13

___

### m\_stackedWidget

• `Private` **m\_stackedWidget**: [`StackedWidget`](StackedWidget.md)

#### Defined in

container/tabwidget.ts:9

___

### m\_tabBar

• `Private` **m\_tabBar**: [`TabBar`](TabBar.md)

#### Defined in

container/tabwidget.ts:8

## Accessors

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Inherited from

Widget.blocked

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Inherited from

Widget.blocked

#### Defined in

abstract/eventwatcher.ts:85

___

### children

• `get` **children**(): readonly [`Widget`](Widget.md)[]

Returns the list of children.

#### Returns

readonly [`Widget`](Widget.md)[]

#### Inherited from

Widget.children

#### Defined in

widget/widget.ts:104

___

### count

• `get` **count**(): `number`

Returns the number of tabs in the tab widget.

#### Returns

`number`

#### Defined in

container/tabwidget.ts:74

___

### css

• `set` **css**(`style`): `void`

Sets the style of this widget. See also [id](Widget.md#id) [addClass](Widget.md#addclass).

#### Parameters

| Name | Type |
| :------ | :------ |
| `style` | `Partial`<[`StyleSheets`](../interfaces/StyleSheets.md)\> |

#### Returns

`void`

#### Inherited from

Widget.css

#### Defined in

widget/widget.ts:244

___

### currentWidget

• `get` **currentWidget**(): [`Widget`](Widget.md)

Returns the tab page that is visible.

#### Returns

[`Widget`](Widget.md)

#### Defined in

container/tabwidget.ts:88

___

### dom

• `get` **dom**(): `HTMLElement`

Returns the dom of this widget.

#### Returns

`HTMLElement`

#### Inherited from

Widget.dom

#### Defined in

widget/widget.ts:111

___

### enabled

• `get` **enabled**(): `boolean`

Returns whether this widget or its parent chain is enabled or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

Widget.enabled

#### Defined in

widget/widget.ts:207

• `set` **enabled**(`enabled`): `void`

Sets whether this widget is enabled or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `enabled` | `boolean` |

#### Returns

`void`

#### Inherited from

Widget.enabled

#### Defined in

widget/widget.ts:214

___

### height

• `get` **height**(): `number`

Returns the height of this widget.

#### Returns

`number`

#### Inherited from

Widget.height

#### Defined in

widget/widget.ts:160

• `set` **height**(`height`): `void`

Sets the height of this widget to the given height.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `height` | `number` | The unit of height is px. |

#### Returns

`void`

#### Inherited from

Widget.height

#### Defined in

widget/widget.ts:177

___

### id

• `get` **id**(): `string`

Returns the id of this widget.

#### Returns

`string`

#### Inherited from

Widget.id

#### Defined in

widget/widget.ts:221

• `set` **id**(`id`): `void`

Set the id of this widget to the given id.
The id is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `id` | `string` |

#### Returns

`void`

#### Inherited from

Widget.id

#### Defined in

widget/widget.ts:230

___

### index

• `get` **index**(): `number`

Returns the index position of the page that is visible.
The index is -1 if there is no current widget.

#### Returns

`number`

#### Defined in

container/tabwidget.ts:96

• `set` **index**(`index`): `void`

Sets the current index of this tab widget to index.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |

#### Returns

`void`

#### Defined in

container/tabwidget.ts:103

___

### left

• `get` **left**(): `number`

Returns the left coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

Widget.left

#### Defined in

widget/widget.ts:280

• `set` **left**(`left`): `void`

Sets the left coordinate of this widget to the given left.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `left` | `number` | The unit of left is px. |

#### Returns

`void`

#### Inherited from

Widget.left

#### Defined in

widget/widget.ts:273

___

### parent

• `get` **parent**(): [`Widget`](Widget.md)

Returns the parent of this widget, or undefined if it does not have any parent widget.

#### Returns

[`Widget`](Widget.md)

#### Inherited from

Widget.parent

#### Defined in

widget/widget.ts:85

• `set` **parent**(`parent`): `void`

Sets the parent of the widget to the given parent.
If the new parent widget is the old parent widget, this function does nothing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

Widget.parent

#### Defined in

widget/widget.ts:93

___

### position

• `get` **position**(): [`Point`](Point.md)

Returns the position of this widget relative to its parent.

#### Returns

[`Point`](Point.md)

#### Inherited from

Widget.position

#### Defined in

widget/widget.ts:311

• `set` **position**(`position`): `void`

Sets the position of this widget to the given position.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `position` | [`Point`](Point.md) | The unit of position is px. |

#### Returns

`void`

#### Inherited from

Widget.position

#### Defined in

widget/widget.ts:303

___

### rect

• `get` **rect**(): [`Rect`](Rect.md)

Returns the rect of this widget relative to the desktop.

#### Returns

[`Rect`](Rect.md)

#### Inherited from

Widget.rect

#### Defined in

widget/widget.ts:318

___

### size

• `get` **size**(): [`Size`](Size.md)

Returns the size of this widget.

#### Returns

[`Size`](Size.md)

#### Inherited from

Widget.size

#### Defined in

widget/widget.ts:118

• `set` **size**(`size`): `void`

Sets the size of this widget to the given size.
If the size is Size(0, 0) will cause the widget to not appear on screen.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `size` | [`Size`](Size.md) | The unit of size is px. |

#### Returns

`void`

#### Inherited from

Widget.size

#### Defined in

widget/widget.ts:128

___

### style

• `get` **style**(): `CSSStyleDeclaration`

Returns the style of this widget.

#### Returns

`CSSStyleDeclaration`

#### Inherited from

Widget.style

#### Defined in

widget/widget.ts:237

___

### tabBar

• `get` **tabBar**(): [`TabBar`](TabBar.md)

Returns the tab bar of this tab widget.

#### Returns

[`TabBar`](TabBar.md)

#### Defined in

container/tabwidget.ts:112

___

### tabPosition

• `get` **tabPosition**(): [`TabPosition`](../enums/TabPosition.md)

Returns the position of the tab bar in this tab widget.

#### Returns

[`TabPosition`](../enums/TabPosition.md)

#### Defined in

container/tabwidget.ts:162

• `set` **tabPosition**(`position`): `void`

Sets the position of the tab bar in this tab widget to position.

#### Parameters

| Name | Type |
| :------ | :------ |
| `position` | [`TabPosition`](../enums/TabPosition.md) |

#### Returns

`void`

#### Defined in

container/tabwidget.ts:169

___

### tooltip

• `get` **tooltip**(): `string`

Returns the tooltip of this widget.
By default, the value of this property is an empty string.

#### Returns

`string`

#### Inherited from

Widget.tooltip

#### Defined in

widget/widget.ts:254

• `set` **tooltip**(`tooltip`): `void`

Sets the tooltip of this widget to the given tooltip.

#### Parameters

| Name | Type |
| :------ | :------ |
| `tooltip` | `string` |

#### Returns

`void`

#### Inherited from

Widget.tooltip

#### Defined in

widget/widget.ts:261

___

### top

• `get` **top**(): `number`

Returns the top coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

Widget.top

#### Defined in

widget/widget.ts:295

• `set` **top**(`top`): `void`

Sets the top coordinate of this widget to the given top.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `top` | `number` | The unit of top is px. |

#### Returns

`void`

#### Inherited from

Widget.top

#### Defined in

widget/widget.ts:288

___

### visible

• `get` **visible**(): `boolean`

Returns whether this widget or its parent chain is visible or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

Widget.visible

#### Defined in

widget/widget.ts:185

• `set` **visible**(`visible`): `void`

Sets whether this widget is visible or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `visible` | `boolean` |

#### Returns

`void`

#### Inherited from

Widget.visible

#### Defined in

widget/widget.ts:192

___

### width

• `get` **width**(): `number`

Returns the width of this widget.

#### Returns

`number`

#### Inherited from

Widget.width

#### Defined in

widget/widget.ts:136

• `set` **width**(`width`): `void`

Sets the width of this widget to the given width.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `width` | `number` | The unit of width is px. |

#### Returns

`void`

#### Inherited from

Widget.width

#### Defined in

widget/widget.ts:153

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Inherited from

Widget.sender

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### add

▸ **add**(`page`, `text`, `image?`): `void`

Adds a tab with the given page, text, and image to the tab widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `page` | [`Widget`](Widget.md) |
| `text` | `string` |
| `image?` | `string` |

#### Returns

`void`

#### Defined in

container/tabwidget.ts:34

___

### addAttr

▸ **addAttr**(`attr`): `void`

Adds the attribute of this widget.
The attribute is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[addAttr](Widget.md#addattr)

#### Defined in

widget/widget.ts:375

___

### addClass

▸ **addClass**(`className`): `void`

Adds the class name of this widget.
The class name is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[addClass](Widget.md#addclass)

#### Defined in

widget/widget.ts:344

___

### at

▸ **at**(`index`): [`Widget`](Widget.md)

Returns the tab page at position index.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |

#### Returns

[`Widget`](Widget.md)

#### Defined in

container/tabwidget.ts:81

___

### attach

▸ `Protected` **attach**(): `void`

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[attach](Widget.md#attach)

#### Defined in

widget/widget.ts:461

___

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[bind](Widget.md#bind)

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[bind](Widget.md#bind)

#### Defined in

abstract/eventwatcher.ts:29

___

### clear

▸ **clear**(): `void`

Removes all the tabs.

#### Returns

`void`

#### Defined in

container/tabwidget.ts:66

___

### clearChildren

▸ **clearChildren**(): `void`

Clears all widgets in the list of children.

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[clearChildren](Widget.md#clearchildren)

#### Defined in

widget/widget.ts:450

___

### close

▸ **close**(): `void`

Closes this widget.
This function is equivalent to setting this widget's parent to undefined.

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[close](Widget.md#close)

#### Defined in

widget/widget.ts:62

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[delegate](Widget.md#delegate)

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[delegate](Widget.md#delegate)

#### Defined in

abstract/eventwatcher.ts:68

___

### destroy

▸ **destroy**(): `void`

Destroys the widget, All the widget's children are destroyed first.

The widget is destroyed when it’s parent is destroyed. When the widget is destroyed, make sure to release all resources, such as timers, etc.
Releases the resources in function free(), The system will call this function automatically when the parent widget or itself is destroyed.
See also [free](Widget.md#free).

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[destroy](Widget.md#destroy)

#### Defined in

widget/widget.ts:40

___

### detach

▸ `Protected` **detach**(): `void`

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[detach](Widget.md#detach)

#### Defined in

widget/widget.ts:471

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Inherited from

[Widget](Widget.md).[emit](Widget.md#emit)

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Inherited from

[Widget](Widget.md).[emit](Widget.md#emit)

#### Defined in

abstract/eventwatcher.ts:49

___

### free

▸ `Protected` **free**(): `void`

Frees the resources.See also [destroy](Widget.md#destroy).

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[free](Widget.md#free)

#### Defined in

widget/widget.ts:55

___

### getTabEnabled

▸ **getTabEnabled**(`index`): `boolean`

Returns true if the tab at position index is enabled; otherwise returns false.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |

#### Returns

`boolean`

#### Defined in

container/tabwidget.ts:155

___

### getTabIcon

▸ **getTabIcon**(`index`): `string`

Returns the icon of the tab at position index.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |

#### Returns

`string`

#### Defined in

container/tabwidget.ts:140

___

### getTabText

▸ **getTabText**(`index`): `string`

Returns the text of the tab at position index.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |

#### Returns

`string`

#### Defined in

container/tabwidget.ts:126

___

### hasAttr

▸ **hasAttr**(`attr`): `boolean`

Returns whether this widget contains the attribute.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`boolean`

#### Inherited from

[Widget](Widget.md).[hasAttr](Widget.md#hasattr)

#### Defined in

widget/widget.ts:389

___

### hasClass

▸ **hasClass**(`className`): `boolean`

Returns whether this widget contains the class name.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`boolean`

#### Inherited from

[Widget](Widget.md).[hasClass](Widget.md#hasclass)

#### Defined in

widget/widget.ts:358

___

### hide

▸ **hide**(): `void`

Hides the widget and its child widgets.
This function is equivalent to setting the visible property to false.

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[hide](Widget.md#hide)

#### Defined in

widget/widget.ts:78

___

### insert

▸ **insert**(`index`, `page`, `text`, `image?`): `void`

Inserts a tab with the given page, text, and image into the tab widget at position index.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `page` | [`Widget`](Widget.md) |
| `text` | `string` |
| `image?` | `string` |

#### Returns

`void`

#### Defined in

container/tabwidget.ts:46

___

### insertChild

▸ **insertChild**(`index`, `widget`): `void`

Inserts the child widget at index in the list of children.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[insertChild](Widget.md#insertchild)

#### Defined in

widget/widget.ts:431

___

### raise

▸ **raise**(): `boolean`

Raises this widget to the top of the parent widget's children.
The display order of this widget is determined by the order in which they appear in the parent widget's children.

#### Returns

`boolean`

#### Inherited from

[Widget](Widget.md).[raise](Widget.md#raise)

#### Defined in

widget/widget.ts:406

___

### remove

▸ **remove**(`index`): `void`

Removes the tab at position index from this tab widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |

#### Returns

`void`

#### Defined in

container/tabwidget.ts:58

___

### removeAttr

▸ **removeAttr**(`attr`): `void`

Removes the attribute of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[removeAttr](Widget.md#removeattr)

#### Defined in

widget/widget.ts:382

___

### removeClass

▸ **removeClass**(`className`): `void`

Removes the class name of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[removeClass](Widget.md#removeclass)

#### Defined in

widget/widget.ts:351

___

### setFlex

▸ **setFlex**(`orientation`, `alignItem?`, `spacing?`): `void`

Sets whether the widget uses flex layout.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `orientation` | [`Orientation`](../enums/Orientation.md) | Horizontal or vertical. |
| `alignItem?` | ``"center"`` \| ``"inherit"`` \| ``"stretch"`` \| ``"flex-start"`` \| ``"flex-end"`` \| ``"initial"`` \| ``"baseline"`` | @see(https://developer.mozilla.org/en-US/docs/Web/CSS/align-items) |
| `spacing?` | `number` | the spacing between widgets inside the layout. |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[setFlex](Widget.md#setflex)

#### Defined in

widget/widget.ts:329

___

### setTabEnabled

▸ **setTabEnabled**(`index`, `enabled`): `void`

If enabled is true then the tab at position index is enabled; otherwise the tab at position index is disabled.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `enabled` | `boolean` |

#### Returns

`void`

#### Defined in

container/tabwidget.ts:147

___

### setTabIcon

▸ **setTabIcon**(`index`, `image`): `void`

Sets the icon of the tab at position index to icon.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `image` | `string` |

#### Returns

`void`

#### Defined in

container/tabwidget.ts:133

___

### setTabText

▸ **setTabText**(`index`, `text`): `void`

Sets the text of the tab at position index to text.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `text` | `string` |

#### Returns

`void`

#### Defined in

container/tabwidget.ts:119

___

### show

▸ **show**(): `void`

Shows the widget and its child widgets.
This function is equivalent to setting the visible property to true.

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[show](Widget.md#show)

#### Defined in

widget/widget.ts:70

___

### toggleAttr

▸ **toggleAttr**(`attr`, `on`): `void`

If param attr is true, adds the attribute, otherwise removes the attribute.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `attr` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[toggleAttr](Widget.md#toggleattr)

#### Defined in

widget/widget.ts:398

___

### toggleClass

▸ **toggleClass**(`className`, `on`): `void`

If param on is true, adds the class name, otherwise removes the class name.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `className` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[toggleClass](Widget.md#toggleclass)

#### Defined in

widget/widget.ts:367

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[unbind](Widget.md#unbind)

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[Widget](Widget.md).[unbind](Widget.md#unbind)

#### Defined in

abstract/eventwatcher.ts:38
