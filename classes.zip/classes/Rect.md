[wui.basic](../README.md) / [Exports](../modules.md) / Rect

# Class: Rect

The Rect is normally expressed as a top-left corner and a size.

## Table of contents

### Constructors

- [constructor](Rect.md#constructor)

### Properties

- [m\_x1](Rect.md#m_x1)
- [m\_x2](Rect.md#m_x2)
- [m\_y1](Rect.md#m_y1)
- [m\_y2](Rect.md#m_y2)

### Accessors

- [bottom](Rect.md#bottom)
- [bottomLeft](Rect.md#bottomleft)
- [bottomRight](Rect.md#bottomright)
- [center](Rect.md#center)
- [height](Rect.md#height)
- [left](Rect.md#left)
- [right](Rect.md#right)
- [size](Rect.md#size)
- [top](Rect.md#top)
- [topLeft](Rect.md#topleft)
- [topRight](Rect.md#topright)
- [width](Rect.md#width)
- [x](Rect.md#x)
- [y](Rect.md#y)

### Methods

- [clone](Rect.md#clone)
- [compare](Rect.md#compare)
- [contains](Rect.md#contains)
- [copy](Rect.md#copy)
- [isNull](Rect.md#isnull)
- [isValid](Rect.md#isvalid)
- [moveLeft](Rect.md#moveleft)
- [moveRight](Rect.md#moveright)
- [moveTo](Rect.md#moveto)
- [translate](Rect.md#translate)
- [translated](Rect.md#translated)
- [fromPoint](Rect.md#frompoint)

## Constructors

### constructor

• **new Rect**(`x?`, `y?`, `width?`, `height?`)

Constructs a rect with (x, y) as its top-left corner and the given width and height.

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `0` |
| `y` | `number` | `0` |
| `width` | `number` | `0` |
| `height` | `number` | `0` |

#### Defined in

core/rect.ts:15

## Properties

### m\_x1

• `Private` **m\_x1**: `number`

#### Defined in

core/rect.ts:7

___

### m\_x2

• `Private` **m\_x2**: `number`

#### Defined in

core/rect.ts:9

___

### m\_y1

• `Private` **m\_y1**: `number`

#### Defined in

core/rect.ts:8

___

### m\_y2

• `Private` **m\_y2**: `number`

#### Defined in

core/rect.ts:10

## Accessors

### bottom

• `get` **bottom**(): `number`

Returns the y-coordinate of the rect's bottom edge.

#### Returns

`number`

#### Defined in

core/rect.ts:79

• `set` **bottom**(`pos`): `void`

Sets the bottom edge of the rect to the given pos.

#### Parameters

| Name | Type |
| :------ | :------ |
| `pos` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:86

___

### bottomLeft

• `get` **bottomLeft**(): [`Point`](Point.md)

Returns the position of the rect's bottom-left corner.

#### Returns

[`Point`](Point.md)

#### Defined in

core/rect.ts:107

___

### bottomRight

• `get` **bottomRight**(): [`Point`](Point.md)

Returns the position of the rect's bottom-right corner.

#### Returns

[`Point`](Point.md)

#### Defined in

core/rect.ts:114

___

### center

• `get` **center**(): [`Point`](Point.md)

Returns the center point of the rect.

#### Returns

[`Point`](Point.md)

#### Defined in

core/rect.ts:171

___

### height

• `get` **height**(): `number`

Returns the height of the rect.

#### Returns

`number`

#### Defined in

core/rect.ts:164

• `set` **height**(`h`): `void`

Sets the height of the rect to the given h. The bottom edge is changed, but not the top one.

#### Parameters

| Name | Type |
| :------ | :------ |
| `h` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:157

___

### left

• `get` **left**(): `number`

Returns the x-coordinate of the rect's left edge. Equivalent to [x](Rect.md#x).

#### Returns

`number`

#### Defined in

core/rect.ts:37

• `set` **left**(`pos`): `void`

Sets the left edge of the rect to the given pos.

#### Parameters

| Name | Type |
| :------ | :------ |
| `pos` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:44

___

### right

• `get` **right**(): `number`

Returns the x-coordinate of the rect's right edge.

#### Returns

`number`

#### Defined in

core/rect.ts:65

• `set` **right**(`pos`): `void`

Sets the right edge of the rect to the given pos.

#### Parameters

| Name | Type |
| :------ | :------ |
| `pos` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:72

___

### size

• `get` **size**(): [`Size`](Size.md)

Returns the size of the rect.

#### Returns

[`Size`](Size.md)

#### Defined in

core/rect.ts:180

___

### top

• `get` **top**(): `number`

Returns the y-coordinate of the rect's top edge. Equivalent to [y](Rect.md#y).

#### Returns

`number`

#### Defined in

core/rect.ts:51

• `set` **top**(`pos`): `void`

Sets the top edge of the rect to the given pos.

#### Parameters

| Name | Type |
| :------ | :------ |
| `pos` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:58

___

### topLeft

• `get` **topLeft**(): [`Point`](Point.md)

Returns the position of the rect's top-left corner.

#### Returns

[`Point`](Point.md)

#### Defined in

core/rect.ts:93

___

### topRight

• `get` **topRight**(): [`Point`](Point.md)

Returns the position of the rect's top-right corner.

#### Returns

[`Point`](Point.md)

#### Defined in

core/rect.ts:100

___

### width

• `get` **width**(): `number`

Returns the width of the rect.

#### Returns

`number`

#### Defined in

core/rect.ts:150

• `set` **width**(`w`): `void`

Sets the width of the rect to the given w. The right edge is changed, but not the left one.

#### Parameters

| Name | Type |
| :------ | :------ |
| `w` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:143

___

### x

• `get` **x**(): `number`

#### Returns

`number`

#### Defined in

core/rect.ts:125

• `set` **x**(`x`): `void`

Equivalent to [left](Rect.md#left).

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:121

___

### y

• `get` **y**(): `number`

#### Returns

`number`

#### Defined in

core/rect.ts:136

• `set` **y**(`y`): `void`

Equivalent to [top](Rect.md#top).

#### Parameters

| Name | Type |
| :------ | :------ |
| `y` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:132

## Methods

### clone

▸ **clone**(): [`Rect`](Rect.md)

Returns a copy of this rect.

#### Returns

[`Rect`](Rect.md)

#### Defined in

core/rect.ts:304

___

### compare

▸ **compare**(`other`): `boolean`

Returns true if this rect and other are equal; otherwise returns false.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Rect`](Rect.md) |

#### Returns

`boolean`

#### Defined in

core/rect.ts:311

___

### contains

▸ **contains**(`p`, `proper?`): `boolean`

Returns true if the given p is inside or on the edge of the rect, otherwise returns false.

#### Parameters

| Name | Type | Default value | Description |
| :------ | :------ | :------ | :------ |
| `p` | [`Point`](Point.md) | `undefined` | - |
| `proper` | `boolean` | `false` | The default value is false. If proper is true, this function only returns true if the given p is inside the rect (i.e., not on the edge). |

#### Returns

`boolean`

#### Defined in

core/rect.ts:233

___

### copy

▸ **copy**(`other`): `void`

Copies the other rect to this rect.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Rect`](Rect.md) |

#### Returns

`void`

#### Defined in

core/rect.ts:294

___

### isNull

▸ **isNull**(): `boolean`

Returns true if both the width and height is 0, otherwise returns false.

#### Returns

`boolean`

#### Defined in

core/rect.ts:280

___

### isValid

▸ **isValid**(): `boolean`

Returns true if the rect is valid(left <= right && top <= bottom), otherwise returns false.

#### Returns

`boolean`

#### Defined in

core/rect.ts:287

___

### moveLeft

▸ **moveLeft**(`left`): `void`

Moves the rect horizontally, leaving the rect's left edge at the given x coordinate.

#### Parameters

| Name | Type |
| :------ | :------ |
| `left` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:214

___

### moveRight

▸ **moveRight**(`right`): `void`

Moves the rect horizontally, leaving the rect's right edge at the given x coordinate.

#### Parameters

| Name | Type |
| :------ | :------ |
| `right` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:223

___

### moveTo

▸ **moveTo**(`x`, `y`): `void`

Moves the rect, leaving the top-left corner at the given position (x, y).

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:204

___

### translate

▸ **translate**(`dx`, `dy`): `void`

Moves dx along the x axis and dy along the y axis, relative to the current position.

#### Parameters

| Name | Type |
| :------ | :------ |
| `dx` | `number` |
| `dy` | `number` |

#### Returns

`void`

#### Defined in

core/rect.ts:187

___

### translated

▸ **translated**(`dx`, `dy`): [`Rect`](Rect.md)

Returns a copy of the rect that is translated dx along the x axis and dy along the y axis, relative to the current position.

#### Parameters

| Name | Type |
| :------ | :------ |
| `dx` | `number` |
| `dy` | `number` |

#### Returns

[`Rect`](Rect.md)

#### Defined in

core/rect.ts:197

___

### fromPoint

▸ `Static` **fromPoint**(`topLeft`, `bottomRight`): [`Rect`](Rect.md)

Constructs a rect with the given topLeft and bottomRight corners.

#### Parameters

| Name | Type |
| :------ | :------ |
| `topLeft` | [`Point`](Point.md) |
| `bottomRight` | [`Point`](Point.md) |

#### Returns

[`Rect`](Rect.md)

#### Defined in

core/rect.ts:25
