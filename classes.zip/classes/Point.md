[wui.basic](../README.md) / [Exports](../modules.md) / Point

# Class: Point

The Point is specified by a x coordinate and a y coordinate.

## Table of contents

### Constructors

- [constructor](Point.md#constructor)

### Properties

- [m\_x](Point.md#m_x)
- [m\_y](Point.md#m_y)

### Accessors

- [x](Point.md#x)
- [y](Point.md#y)

### Methods

- [add](Point.md#add)
- [clone](Point.md#clone)
- [compare](Point.md#compare)
- [copy](Point.md#copy)
- [div](Point.md#div)
- [isNull](Point.md#isnull)
- [manhattanDist](Point.md#manhattandist)
- [mul](Point.md#mul)
- [neg](Point.md#neg)
- [sub](Point.md#sub)

## Constructors

### constructor

• **new Point**(`x?`, `y?`)

Constructs a point with the given coordinates (x, y).

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `0` |
| `y` | `number` | `0` |

#### Defined in

core/point.ts:11

## Properties

### m\_x

• `Private` **m\_x**: `number`

#### Defined in

core/point.ts:5

___

### m\_y

• `Private` **m\_y**: `number`

#### Defined in

core/point.ts:6

## Accessors

### x

• `get` **x**(): `number`

Returns the x coordinate of this point.

#### Returns

`number`

#### Defined in

core/point.ts:19

• `set` **x**(`x`): `void`

Sets the x coordinate of this point to the given x coordinate.

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |

#### Returns

`void`

#### Defined in

core/point.ts:26

___

### y

• `get` **y**(): `number`

Returns the y coordinate of this point.

#### Returns

`number`

#### Defined in

core/point.ts:33

• `set` **y**(`y`): `void`

Sets the y coordinate of this point to the given y coordinate.

#### Parameters

| Name | Type |
| :------ | :------ |
| `y` | `number` |

#### Returns

`void`

#### Defined in

core/point.ts:40

## Methods

### add

▸ **add**(`other`): `void`

Adds the given point to this point. See also [sub](Point.md#sub)

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Point`](Point.md) |

#### Returns

`void`

#### Defined in

core/point.ts:69

___

### clone

▸ **clone**(): [`Point`](Point.md)

Returns a copy of this point.

#### Returns

[`Point`](Point.md)

#### Defined in

core/point.ts:109

___

### compare

▸ **compare**(`other`): `boolean`

Returns true if this point and other are equal; otherwise returns false.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Point`](Point.md) |

#### Returns

`boolean`

#### Defined in

core/point.ts:116

___

### copy

▸ **copy**(`other`): `void`

Copies the other point to this point.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Point`](Point.md) |

#### Returns

`void`

#### Defined in

core/point.ts:101

___

### div

▸ **div**(`divisor`): `void`

Divides both x and y by the given divisor. See also [mul](Point.md#mul)

#### Parameters

| Name | Type |
| :------ | :------ |
| `divisor` | `number` |

#### Returns

`void`

#### Defined in

core/point.ts:93

___

### isNull

▸ **isNull**(): `boolean`

Returns true if both the x and y coordinates are set to 0, otherwise returns false.

#### Returns

`boolean`

#### Defined in

core/point.ts:54

___

### manhattanDist

▸ **manhattanDist**(): `number`

Returns the sum of the absolute values of x and y.

#### Returns

`number`

#### Defined in

core/point.ts:47

___

### mul

▸ **mul**(`factor`): `void`

Multiplies this point's coordinates by the given factor. See also [div](Point.md#div)

#### Parameters

| Name | Type |
| :------ | :------ |
| `factor` | `number` |

#### Returns

`void`

#### Defined in

core/point.ts:85

___

### neg

▸ **neg**(): `void`

Changes the sign of both components.

#### Returns

`void`

#### Defined in

core/point.ts:61

___

### sub

▸ **sub**(`other`): `void`

Subtracts the given point from this point. See also [add](Point.md#add)

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Point`](Point.md) |

#### Returns

`void`

#### Defined in

core/point.ts:77
