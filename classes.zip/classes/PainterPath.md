[wui.basic](../README.md) / [Exports](../modules.md) / PainterPath

# Class: PainterPath

## Table of contents

### Constructors

- [constructor](PainterPath.md#constructor)

### Properties

- [m\_context](PainterPath.md#m_context)

### Methods

- [addArc](PainterPath.md#addarc)
- [addCircle](PainterPath.md#addcircle)
- [addRect](PainterPath.md#addrect)
- [addTriangle](PainterPath.md#addtriangle)
- [arcTo](PainterPath.md#arcto)
- [beginPath](PainterPath.md#beginpath)
- [clip](PainterPath.md#clip)
- [closePath](PainterPath.md#closepath)
- [contains](PainterPath.md#contains)
- [cubicTo](PainterPath.md#cubicto)
- [lineTo](PainterPath.md#lineto)
- [moveTo](PainterPath.md#moveto)
- [quadTo](PainterPath.md#quadto)

## Constructors

### constructor

• **new PainterPath**(`context`)

#### Parameters

| Name | Type |
| :------ | :------ |
| `context` | `CanvasRenderingContext2D` |

#### Defined in

painting/painterpath.ts:4

## Properties

### m\_context

• `Private` **m\_context**: `CanvasRenderingContext2D`

#### Defined in

painting/painterpath.ts:2

## Methods

### addArc

▸ **addArc**(`x`, `y`, `radius`, `startAngle`, `endAngle`, `anticlockwise?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `radius` | `number` | `undefined` |
| `startAngle` | `number` | `undefined` |
| `endAngle` | `number` | `undefined` |
| `anticlockwise` | `boolean` | `false` |

#### Returns

`void`

#### Defined in

painting/painterpath.ts:62

___

### addCircle

▸ **addCircle**(`x`, `y`, `radius`, `anticlockwise?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `radius` | `number` | `undefined` |
| `anticlockwise` | `boolean` | `false` |

#### Returns

`void`

#### Defined in

painting/painterpath.ts:66

___

### addRect

▸ **addRect**(`x`, `y`, `width`, `height`, `anticlockwise?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `width` | `number` | `undefined` |
| `height` | `number` | `undefined` |
| `anticlockwise` | `boolean` | `false` |

#### Returns

`void`

#### Defined in

painting/painterpath.ts:48

___

### addTriangle

▸ **addTriangle**(`x1`, `y1`, `x2`, `y2`, `x3`, `y3`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x1` | `number` |
| `y1` | `number` |
| `x2` | `number` |
| `y2` | `number` |
| `x3` | `number` |
| `y3` | `number` |

#### Returns

`void`

#### Defined in

painting/painterpath.ts:40

___

### arcTo

▸ **arcTo**(`x1`, `y1`, `x2`, `y2`, `radius`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x1` | `number` |
| `y1` | `number` |
| `x2` | `number` |
| `y2` | `number` |
| `radius` | `number` |

#### Returns

`void`

#### Defined in

painting/painterpath.ts:28

___

### beginPath

▸ **beginPath**(): `void`

#### Returns

`void`

#### Defined in

painting/painterpath.ts:8

___

### clip

▸ **clip**(): `void`

#### Returns

`void`

#### Defined in

painting/painterpath.ts:71

___

### closePath

▸ **closePath**(): `void`

#### Returns

`void`

#### Defined in

painting/painterpath.ts:12

___

### contains

▸ **contains**(`x`, `y`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`boolean`

#### Defined in

painting/painterpath.ts:16

___

### cubicTo

▸ **cubicTo**(`c1X`, `c1Y`, `c2X`, `c2Y`, `endPointX`, `endPointY`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `c1X` | `number` |
| `c1Y` | `number` |
| `c2X` | `number` |
| `c2Y` | `number` |
| `endPointX` | `number` |
| `endPointY` | `number` |

#### Returns

`void`

#### Defined in

painting/painterpath.ts:36

___

### lineTo

▸ **lineTo**(`x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Defined in

painting/painterpath.ts:24

___

### moveTo

▸ **moveTo**(`x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Defined in

painting/painterpath.ts:20

___

### quadTo

▸ **quadTo**(`cx`, `cy`, `endPointX`, `endPointY`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `cx` | `number` |
| `cy` | `number` |
| `endPointX` | `number` |
| `endPointY` | `number` |

#### Returns

`void`

#### Defined in

painting/painterpath.ts:32
