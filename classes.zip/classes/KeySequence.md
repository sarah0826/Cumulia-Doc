[wui.basic](../README.md) / [Exports](../modules.md) / KeySequence

# Class: KeySequence

The KeySequence class provides a key sequence used by shortcuts.

## Table of contents

### Constructors

- [constructor](KeySequence.md#constructor)

### Properties

- [m\_key](KeySequence.md#m_key)
- [m\_modifier](KeySequence.md#m_modifier)

### Accessors

- [key](KeySequence.md#key)
- [modifier](KeySequence.md#modifier)

### Methods

- [toString](KeySequence.md#tostring)

## Constructors

### constructor

• **new KeySequence**(`event`)

Constructs a key sequence with a keyboard event.

#### Parameters

| Name | Type |
| :------ | :------ |
| `event` | `KeyboardEvent` |

#### Defined in

tools/keysequence.ts:14

## Properties

### m\_key

• `Private` **m\_key**: [`Key`](../enums/Key.md)

#### Defined in

tools/keysequence.ts:8

___

### m\_modifier

• `Private` **m\_modifier**: [`Modifier`](../enums/Modifier.md)

#### Defined in

tools/keysequence.ts:7

## Accessors

### key

• `get` **key**(): [`Key`](../enums/Key.md)

Returns the code of the key.

#### Returns

[`Key`](../enums/Key.md)

#### Defined in

tools/keysequence.ts:48

___

### modifier

• `get` **modifier**(): [`Modifier`](../enums/Modifier.md)

Returns the keyboard modifier flag.

#### Returns

[`Modifier`](../enums/Modifier.md)

#### Defined in

tools/keysequence.ts:41

## Methods

### toString

▸ **toString**(): `string`

Return a string representation of the key sequence.

#### Returns

`string`

#### Defined in

tools/keysequence.ts:22
