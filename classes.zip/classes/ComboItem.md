[wui.basic](../README.md) / [Exports](../modules.md) / ComboItem

# Class: ComboItem

The ComboItem is a single item in a combobox and typically used to display text.

## Hierarchy

- [`MenuItem`](MenuItem.md)

  ↳ **`ComboItem`**

## Table of contents

### Constructors

- [constructor](ComboItem.md#constructor)

### Properties

- [m\_children](ComboItem.md#m_children)
- [m\_content](ComboItem.md#m_content)
- [m\_dom](ComboItem.md#m_dom)
- [m\_icon](ComboItem.md#m_icon)
- [m\_parent](ComboItem.md#m_parent)
- [m\_spacer](ComboItem.md#m_spacer)
- [m\_text](ComboItem.md#m_text)

### Accessors

- [alignment](ComboItem.md#alignment)
- [blocked](ComboItem.md#blocked)
- [checked](ComboItem.md#checked)
- [children](ComboItem.md#children)
- [css](ComboItem.md#css)
- [dom](ComboItem.md#dom)
- [enabled](ComboItem.md#enabled)
- [height](ComboItem.md#height)
- [id](ComboItem.md#id)
- [image](ComboItem.md#image)
- [left](ComboItem.md#left)
- [orientation](ComboItem.md#orientation)
- [parent](ComboItem.md#parent)
- [position](ComboItem.md#position)
- [rect](ComboItem.md#rect)
- [selected](ComboItem.md#selected)
- [shortcutKey](ComboItem.md#shortcutkey)
- [size](ComboItem.md#size)
- [spacing](ComboItem.md#spacing)
- [style](ComboItem.md#style)
- [text](ComboItem.md#text)
- [tooltip](ComboItem.md#tooltip)
- [top](ComboItem.md#top)
- [visible](ComboItem.md#visible)
- [width](ComboItem.md#width)
- [sender](ComboItem.md#sender)

### Methods

- [addAttr](ComboItem.md#addattr)
- [addClass](ComboItem.md#addclass)
- [align2Str](ComboItem.md#align2str)
- [attach](ComboItem.md#attach)
- [bind](ComboItem.md#bind)
- [clearChildren](ComboItem.md#clearchildren)
- [close](ComboItem.md#close)
- [create](ComboItem.md#create)
- [delegate](ComboItem.md#delegate)
- [destroy](ComboItem.md#destroy)
- [detach](ComboItem.md#detach)
- [emit](ComboItem.md#emit)
- [executable](ComboItem.md#executable)
- [free](ComboItem.md#free)
- [hasAttr](ComboItem.md#hasattr)
- [hasClass](ComboItem.md#hasclass)
- [hide](ComboItem.md#hide)
- [insertChild](ComboItem.md#insertchild)
- [raise](ComboItem.md#raise)
- [removeAttr](ComboItem.md#removeattr)
- [removeClass](ComboItem.md#removeclass)
- [setFlex](ComboItem.md#setflex)
- [show](ComboItem.md#show)
- [str2Align](ComboItem.md#str2align)
- [toggleAttr](ComboItem.md#toggleattr)
- [toggleClass](ComboItem.md#toggleclass)
- [unbind](ComboItem.md#unbind)

## Constructors

### constructor

• **new ComboItem**(`parent?`, `text?`)

Constructs a combobox item.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent?` | [`Menu`](Menu.md) |
| `text?` | `string` |

#### Overrides

[MenuItem](MenuItem.md).[constructor](MenuItem.md#constructor)

#### Defined in

widget/combobox.ts:11

## Properties

### m\_children

• `Protected` **m\_children**: [`Widget`](Widget.md)[] = `[]`

#### Inherited from

[MenuItem](MenuItem.md).[m_children](MenuItem.md#m_children)

#### Defined in

widget/widget.ts:15

___

### m\_content

• `Protected` **m\_content**: [`Widget`](Widget.md)

#### Inherited from

[MenuItem](MenuItem.md).[m_content](MenuItem.md#m_content)

#### Defined in

widget/widget.ts:14

___

### m\_dom

• `Protected` **m\_dom**: `HTMLElement`

#### Inherited from

[MenuItem](MenuItem.md).[m_dom](MenuItem.md#m_dom)

#### Defined in

widget/widget.ts:12

___

### m\_icon

• `Protected` **m\_icon**: [`Icon`](Icon.md)

#### Inherited from

[MenuItem](MenuItem.md).[m_icon](MenuItem.md#m_icon)

#### Defined in

widget/menu.ts:10

___

### m\_parent

• `Protected` **m\_parent**: [`Widget`](Widget.md)

#### Inherited from

[MenuItem](MenuItem.md).[m_parent](MenuItem.md#m_parent)

#### Defined in

widget/widget.ts:13

___

### m\_spacer

• `Protected` **m\_spacer**: [`Spacer`](Spacer.md)

#### Inherited from

[MenuItem](MenuItem.md).[m_spacer](MenuItem.md#m_spacer)

#### Defined in

widget/menu.ts:12

___

### m\_text

• `Protected` **m\_text**: [`Text`](Text.md)

#### Inherited from

[MenuItem](MenuItem.md).[m_text](MenuItem.md#m_text)

#### Defined in

widget/menu.ts:11

## Accessors

### alignment

• `get` **alignment**(): [`Alignment`](../enums/Alignment.md)

Returns the alignment along the main axis.

#### Returns

[`Alignment`](../enums/Alignment.md)

#### Inherited from

MenuItem.alignment

#### Defined in

layout/flex.ts:61

• `set` **alignment**(`alignment`): `void`

Sets the alignment along the main axis to the given alignment.

#### Parameters

| Name | Type |
| :------ | :------ |
| `alignment` | [`Alignment`](../enums/Alignment.md) |

#### Returns

`void`

#### Inherited from

MenuItem.alignment

#### Defined in

layout/flex.ts:54

___

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Inherited from

MenuItem.blocked

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Inherited from

MenuItem.blocked

#### Defined in

abstract/eventwatcher.ts:85

___

### checked

• `get` **checked**(): `boolean`

Returns the check state of this menu item.

#### Returns

`boolean`

#### Inherited from

MenuItem.checked

#### Defined in

widget/menu.ts:79

• `set` **checked**(`checked`): `void`

Sets the check state of this menu item to checked.

#### Parameters

| Name | Type |
| :------ | :------ |
| `checked` | `boolean` |

#### Returns

`void`

#### Inherited from

MenuItem.checked

#### Defined in

widget/menu.ts:86

___

### children

• `get` **children**(): readonly [`Widget`](Widget.md)[]

Returns the list of children.

#### Returns

readonly [`Widget`](Widget.md)[]

#### Inherited from

MenuItem.children

#### Defined in

widget/widget.ts:104

___

### css

• `set` **css**(`style`): `void`

Sets the style of this widget. See also [id](Widget.md#id) [addClass](Widget.md#addclass).

#### Parameters

| Name | Type |
| :------ | :------ |
| `style` | `Partial`<[`StyleSheets`](../interfaces/StyleSheets.md)\> |

#### Returns

`void`

#### Inherited from

MenuItem.css

#### Defined in

widget/widget.ts:244

___

### dom

• `get` **dom**(): `HTMLElement`

Returns the dom of this widget.

#### Returns

`HTMLElement`

#### Inherited from

MenuItem.dom

#### Defined in

widget/widget.ts:111

___

### enabled

• `get` **enabled**(): `boolean`

Returns whether this widget or its parent chain is enabled or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

MenuItem.enabled

#### Defined in

widget/widget.ts:207

• `set` **enabled**(`enabled`): `void`

Sets whether this widget is enabled or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `enabled` | `boolean` |

#### Returns

`void`

#### Inherited from

MenuItem.enabled

#### Defined in

widget/widget.ts:214

___

### height

• `get` **height**(): `number`

Returns the height of this widget.

#### Returns

`number`

#### Inherited from

MenuItem.height

#### Defined in

widget/widget.ts:160

• `set` **height**(`height`): `void`

Sets the height of this widget to the given height.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `height` | `number` | The unit of height is px. |

#### Returns

`void`

#### Inherited from

MenuItem.height

#### Defined in

widget/widget.ts:177

___

### id

• `get` **id**(): `string`

Returns the id of this widget.

#### Returns

`string`

#### Inherited from

MenuItem.id

#### Defined in

widget/widget.ts:221

• `set` **id**(`id`): `void`

Set the id of this widget to the given id.
The id is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `id` | `string` |

#### Returns

`void`

#### Inherited from

MenuItem.id

#### Defined in

widget/widget.ts:230

___

### image

• `get` **image**(): `string`

Returns the image of this menu item.

#### Returns

`string`

#### Inherited from

MenuItem.image

#### Defined in

widget/menu.ts:51

• `set` **image**(`image`): `void`

Sets the image of this menu item to image.

#### Parameters

| Name | Type |
| :------ | :------ |
| `image` | `string` |

#### Returns

`void`

#### Inherited from

MenuItem.image

#### Defined in

widget/menu.ts:58

___

### left

• `get` **left**(): `number`

Returns the left coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

MenuItem.left

#### Defined in

widget/widget.ts:280

• `set` **left**(`left`): `void`

Sets the left coordinate of this widget to the given left.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `left` | `number` | The unit of left is px. |

#### Returns

`void`

#### Inherited from

MenuItem.left

#### Defined in

widget/widget.ts:273

___

### orientation

• `get` **orientation**(): [`Orientation`](../enums/Orientation.md)

Returns the orientation of this flex layout.

#### Returns

[`Orientation`](../enums/Orientation.md)

#### Inherited from

MenuItem.orientation

#### Defined in

layout/flex.ts:24

• `set` **orientation**(`orientation`): `void`

Sets the orientation of this flex layout to the given orientation.

#### Parameters

| Name | Type |
| :------ | :------ |
| `orientation` | [`Orientation`](../enums/Orientation.md) |

#### Returns

`void`

#### Inherited from

MenuItem.orientation

#### Defined in

layout/flex.ts:31

___

### parent

• `get` **parent**(): [`Widget`](Widget.md)

Returns the parent of this widget, or undefined if it does not have any parent widget.

#### Returns

[`Widget`](Widget.md)

#### Inherited from

MenuItem.parent

#### Defined in

widget/widget.ts:85

• `set` **parent**(`parent`): `void`

Sets the parent of the widget to the given parent.
If the new parent widget is the old parent widget, this function does nothing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

MenuItem.parent

#### Defined in

widget/widget.ts:93

___

### position

• `get` **position**(): [`Point`](Point.md)

Returns the position of this widget relative to its parent.

#### Returns

[`Point`](Point.md)

#### Inherited from

MenuItem.position

#### Defined in

widget/widget.ts:311

• `set` **position**(`position`): `void`

Sets the position of this widget to the given position.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `position` | [`Point`](Point.md) | The unit of position is px. |

#### Returns

`void`

#### Inherited from

MenuItem.position

#### Defined in

widget/widget.ts:303

___

### rect

• `get` **rect**(): [`Rect`](Rect.md)

Returns the rect of this widget relative to the desktop.

#### Returns

[`Rect`](Rect.md)

#### Inherited from

MenuItem.rect

#### Defined in

widget/widget.ts:318

___

### selected

• `get` **selected**(): `boolean`

Returns true if this item is selected; otherwise returns false.

#### Returns

`boolean`

#### Defined in

widget/combobox.ts:21

• `set` **selected**(`selected`): `void`

Sets the selected state of this item to the given select.

#### Parameters

| Name | Type |
| :------ | :------ |
| `selected` | `boolean` |

#### Returns

`void`

#### Defined in

widget/combobox.ts:28

___

### shortcutKey

• `get` **shortcutKey**(): `string`

Returns the shortcut key sequence shown on this menu item.

#### Returns

`string`

#### Inherited from

MenuItem.shortcutKey

#### Defined in

widget/menu.ts:101

• `set` **shortcutKey**(`key`): `void`

Sets the shortcut key sequence of this menu item to key, such as "Ctrl+X".

#### Parameters

| Name | Type |
| :------ | :------ |
| `key` | `string` |

#### Returns

`void`

#### Inherited from

MenuItem.shortcutKey

#### Defined in

widget/menu.ts:94

___

### size

• `get` **size**(): [`Size`](Size.md)

Returns the size of this widget.

#### Returns

[`Size`](Size.md)

#### Inherited from

MenuItem.size

#### Defined in

widget/widget.ts:118

• `set` **size**(`size`): `void`

Sets the size of this widget to the given size.
If the size is Size(0, 0) will cause the widget to not appear on screen.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `size` | [`Size`](Size.md) | The unit of size is px. |

#### Returns

`void`

#### Inherited from

MenuItem.size

#### Defined in

widget/widget.ts:128

___

### spacing

• `get` **spacing**(): `number`

Returns the spacing between widgets inside this flex layout.

#### Returns

`number`

#### Inherited from

MenuItem.spacing

#### Defined in

layout/flex.ts:47

• `set` **spacing**(`spacing`): `void`

Set the spacing to the given pacing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `spacing` | `number` |

#### Returns

`void`

#### Inherited from

MenuItem.spacing

#### Defined in

layout/flex.ts:39

___

### style

• `get` **style**(): `CSSStyleDeclaration`

Returns the style of this widget.

#### Returns

`CSSStyleDeclaration`

#### Inherited from

MenuItem.style

#### Defined in

widget/widget.ts:237

___

### text

• `get` **text**(): `string`

Returns the text of this menu item.

#### Returns

`string`

#### Inherited from

MenuItem.text

#### Defined in

widget/menu.ts:65

• `set` **text**(`text`): `void`

Sets the text of this menu item to text.

#### Parameters

| Name | Type |
| :------ | :------ |
| `text` | `string` |

#### Returns

`void`

#### Inherited from

MenuItem.text

#### Defined in

widget/menu.ts:72

___

### tooltip

• `get` **tooltip**(): `string`

Returns the tooltip of this widget.
By default, the value of this property is an empty string.

#### Returns

`string`

#### Inherited from

MenuItem.tooltip

#### Defined in

widget/widget.ts:254

• `set` **tooltip**(`tooltip`): `void`

Sets the tooltip of this widget to the given tooltip.

#### Parameters

| Name | Type |
| :------ | :------ |
| `tooltip` | `string` |

#### Returns

`void`

#### Inherited from

MenuItem.tooltip

#### Defined in

widget/widget.ts:261

___

### top

• `get` **top**(): `number`

Returns the top coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

MenuItem.top

#### Defined in

widget/widget.ts:295

• `set` **top**(`top`): `void`

Sets the top coordinate of this widget to the given top.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `top` | `number` | The unit of top is px. |

#### Returns

`void`

#### Inherited from

MenuItem.top

#### Defined in

widget/widget.ts:288

___

### visible

• `get` **visible**(): `boolean`

Returns whether this widget or its parent chain is visible or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

MenuItem.visible

#### Defined in

widget/widget.ts:185

• `set` **visible**(`visible`): `void`

Sets whether this widget is visible or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `visible` | `boolean` |

#### Returns

`void`

#### Inherited from

MenuItem.visible

#### Defined in

widget/widget.ts:192

___

### width

• `get` **width**(): `number`

Returns the width of this widget.

#### Returns

`number`

#### Inherited from

MenuItem.width

#### Defined in

widget/widget.ts:136

• `set` **width**(`width`): `void`

Sets the width of this widget to the given width.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `width` | `number` | The unit of width is px. |

#### Returns

`void`

#### Inherited from

MenuItem.width

#### Defined in

widget/widget.ts:153

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Inherited from

MenuItem.sender

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### addAttr

▸ **addAttr**(`attr`): `void`

Adds the attribute of this widget.
The attribute is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[addAttr](MenuItem.md#addattr)

#### Defined in

widget/widget.ts:375

___

### addClass

▸ **addClass**(`className`): `void`

Adds the class name of this widget.
The class name is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[addClass](MenuItem.md#addclass)

#### Defined in

widget/widget.ts:344

___

### align2Str

▸ `Protected` **align2Str**(`align`): `string`

#### Parameters

| Name | Type |
| :------ | :------ |
| `align` | [`Alignment`](../enums/Alignment.md) |

#### Returns

`string`

#### Inherited from

[MenuItem](MenuItem.md).[align2Str](MenuItem.md#align2str)

#### Defined in

layout/flex.ts:66

___

### attach

▸ `Protected` **attach**(): `void`

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[attach](MenuItem.md#attach)

#### Defined in

widget/widget.ts:461

___

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[bind](MenuItem.md#bind)

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[bind](MenuItem.md#bind)

#### Defined in

abstract/eventwatcher.ts:29

___

### clearChildren

▸ **clearChildren**(): `void`

Clears all widgets in the list of children.

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[clearChildren](MenuItem.md#clearchildren)

#### Defined in

widget/widget.ts:450

___

### close

▸ **close**(): `void`

Closes this widget.
This function is equivalent to setting this widget's parent to undefined.

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[close](MenuItem.md#close)

#### Defined in

widget/widget.ts:62

___

### create

▸ `Protected` **create**(): `void`

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[create](MenuItem.md#create)

#### Defined in

widget/menu.ts:31

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[delegate](MenuItem.md#delegate)

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[delegate](MenuItem.md#delegate)

#### Defined in

abstract/eventwatcher.ts:68

___

### destroy

▸ **destroy**(): `void`

Destroys the widget, All the widget's children are destroyed first.

The widget is destroyed when it’s parent is destroyed. When the widget is destroyed, make sure to release all resources, such as timers, etc.
Releases the resources in function free(), The system will call this function automatically when the parent widget or itself is destroyed.
See also [free](Widget.md#free).

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[destroy](MenuItem.md#destroy)

#### Defined in

widget/widget.ts:40

___

### detach

▸ `Protected` **detach**(): `void`

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[detach](MenuItem.md#detach)

#### Defined in

widget/widget.ts:471

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Inherited from

[MenuItem](MenuItem.md).[emit](MenuItem.md#emit)

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Inherited from

[MenuItem](MenuItem.md).[emit](MenuItem.md#emit)

#### Defined in

abstract/eventwatcher.ts:49

___

### executable

▸ `Protected` **executable**(): `void`

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[executable](MenuItem.md#executable)

#### Defined in

widget/menu.ts:40

___

### free

▸ `Protected` **free**(): `void`

Frees the resources.See also [destroy](Widget.md#destroy).

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[free](MenuItem.md#free)

#### Defined in

widget/widget.ts:55

___

### hasAttr

▸ **hasAttr**(`attr`): `boolean`

Returns whether this widget contains the attribute.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`boolean`

#### Inherited from

[MenuItem](MenuItem.md).[hasAttr](MenuItem.md#hasattr)

#### Defined in

widget/widget.ts:389

___

### hasClass

▸ **hasClass**(`className`): `boolean`

Returns whether this widget contains the class name.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`boolean`

#### Inherited from

[MenuItem](MenuItem.md).[hasClass](MenuItem.md#hasclass)

#### Defined in

widget/widget.ts:358

___

### hide

▸ **hide**(): `void`

Hides the widget and its child widgets.
This function is equivalent to setting the visible property to false.

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[hide](MenuItem.md#hide)

#### Defined in

widget/widget.ts:78

___

### insertChild

▸ **insertChild**(`index`, `widget`): `void`

Inserts the child widget at index in the list of children.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[insertChild](MenuItem.md#insertchild)

#### Defined in

widget/widget.ts:431

___

### raise

▸ **raise**(): `boolean`

Raises this widget to the top of the parent widget's children.
The display order of this widget is determined by the order in which they appear in the parent widget's children.

#### Returns

`boolean`

#### Inherited from

[MenuItem](MenuItem.md).[raise](MenuItem.md#raise)

#### Defined in

widget/widget.ts:406

___

### removeAttr

▸ **removeAttr**(`attr`): `void`

Removes the attribute of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[removeAttr](MenuItem.md#removeattr)

#### Defined in

widget/widget.ts:382

___

### removeClass

▸ **removeClass**(`className`): `void`

Removes the class name of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[removeClass](MenuItem.md#removeclass)

#### Defined in

widget/widget.ts:351

___

### setFlex

▸ **setFlex**(`orientation`, `alignItem?`, `spacing?`): `void`

Sets whether the widget uses flex layout.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `orientation` | [`Orientation`](../enums/Orientation.md) | Horizontal or vertical. |
| `alignItem?` | ``"center"`` \| ``"inherit"`` \| ``"stretch"`` \| ``"flex-start"`` \| ``"flex-end"`` \| ``"initial"`` \| ``"baseline"`` | @see(https://developer.mozilla.org/en-US/docs/Web/CSS/align-items) |
| `spacing?` | `number` | the spacing between widgets inside the layout. |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[setFlex](MenuItem.md#setflex)

#### Defined in

widget/widget.ts:329

___

### show

▸ **show**(): `void`

Shows the widget and its child widgets.
This function is equivalent to setting the visible property to true.

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[show](MenuItem.md#show)

#### Defined in

widget/widget.ts:70

___

### str2Align

▸ `Protected` **str2Align**(`str`): [`Alignment`](../enums/Alignment.md)

#### Parameters

| Name | Type |
| :------ | :------ |
| `str` | `string` |

#### Returns

[`Alignment`](../enums/Alignment.md)

#### Inherited from

[MenuItem](MenuItem.md).[str2Align](MenuItem.md#str2align)

#### Defined in

layout/flex.ts:79

___

### toggleAttr

▸ **toggleAttr**(`attr`, `on`): `void`

If param attr is true, adds the attribute, otherwise removes the attribute.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `attr` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[toggleAttr](MenuItem.md#toggleattr)

#### Defined in

widget/widget.ts:398

___

### toggleClass

▸ **toggleClass**(`className`, `on`): `void`

If param on is true, adds the class name, otherwise removes the class name.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `className` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[toggleClass](MenuItem.md#toggleclass)

#### Defined in

widget/widget.ts:367

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[unbind](MenuItem.md#unbind)

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[MenuItem](MenuItem.md).[unbind](MenuItem.md#unbind)

#### Defined in

abstract/eventwatcher.ts:38
