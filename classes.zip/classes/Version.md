[wui.basic](../README.md) / [Exports](../modules.md) / Version

# Class: Version

The Version class is used to get the current version number.

## Table of contents

### Constructors

- [constructor](Version.md#constructor)

### Properties

- [major](Version.md#major)
- [minor](Version.md#minor)

### Methods

- [toString](Version.md#tostring)

## Constructors

### constructor

• **new Version**()

## Properties

### major

▪ `Static` **major**: `number` = `1`

#### Defined in

core/version.ts:5

___

### minor

▪ `Static` **minor**: `number` = `1`

#### Defined in

core/version.ts:6

## Methods

### toString

▸ `Static` **toString**(): `string`

Returns the version number as a string.

#### Returns

`string`

#### Defined in

core/version.ts:11
