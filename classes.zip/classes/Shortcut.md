[wui.basic](../README.md) / [Exports](../modules.md) / Shortcut

# Class: Shortcut

The Shortcut class is used to handle global shortcut keys for a application.

## Table of contents

### Constructors

- [constructor](Shortcut.md#constructor)

### Properties

- [s\_eventWatcher](Shortcut.md#s_eventwatcher)

### Methods

- [bind](Shortcut.md#bind)
- [unbind](Shortcut.md#unbind)

## Constructors

### constructor

• **new Shortcut**()

Constructs an event watcher for shortcut keys.

#### Defined in

abstract/shortcut.ts:12

## Properties

### s\_eventWatcher

▪ `Static` `Private` **s\_eventWatcher**: [`EventWatcher`](EventWatcher.md)

#### Defined in

abstract/shortcut.ts:7

## Methods

### bind

▸ **bind**(`name`, `callback`): `void`

Adds a callback function that's going to be called when the user presses the shortcut key named name.

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | () => `void` |

#### Returns

`void`

#### Defined in

abstract/shortcut.ts:25

___

### unbind

▸ **unbind**(`name`): `void`

Removes the specified watcher for the shortcut key named name.

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Defined in

abstract/shortcut.ts:32
