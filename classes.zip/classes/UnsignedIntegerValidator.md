[wui.basic](../README.md) / [Exports](../modules.md) / UnsignedIntegerValidator

# Class: UnsignedIntegerValidator

The UnsignedIntegerValidator class is a validator that ensures a string contains a valid unsigned integer within a specified range.

## Hierarchy

- [`NumberValidator`](NumberValidator.md)

  ↳ **`UnsignedIntegerValidator`**

## Table of contents

### Constructors

- [constructor](UnsignedIntegerValidator.md#constructor)

### Properties

- [m\_maximum](UnsignedIntegerValidator.md#m_maximum)
- [m\_minimum](UnsignedIntegerValidator.md#m_minimum)

### Accessors

- [maximum](UnsignedIntegerValidator.md#maximum)
- [minimum](UnsignedIntegerValidator.md#minimum)
- [pattern](UnsignedIntegerValidator.md#pattern)

### Methods

- [fixup](UnsignedIntegerValidator.md#fixup)
- [toValue](UnsignedIntegerValidator.md#tovalue)
- [validate](UnsignedIntegerValidator.md#validate)

## Constructors

### constructor

• **new UnsignedIntegerValidator**(`minimum?`, `maximum?`)

Constructs an unsigned integer validator with a minimum and a maximum.

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `minimum` | `number` | `0` |
| `maximum` | `number` | `Number.POSITIVE_INFINITY` |

#### Overrides

[NumberValidator](NumberValidator.md).[constructor](NumberValidator.md#constructor)

#### Defined in

validator/unsignedinteger.ts:11

## Properties

### m\_maximum

• `Protected` **m\_maximum**: `number` = `Number.POSITIVE_INFINITY`

#### Inherited from

[NumberValidator](NumberValidator.md).[m_maximum](NumberValidator.md#m_maximum)

#### Defined in

validator/number.ts:8

___

### m\_minimum

• `Protected` **m\_minimum**: `number` = `Number.NEGATIVE_INFINITY`

#### Inherited from

[NumberValidator](NumberValidator.md).[m_minimum](NumberValidator.md#m_minimum)

#### Defined in

validator/number.ts:7

## Accessors

### maximum

• `get` **maximum**(): `number`

Returns the number validator's maximum value.

#### Returns

`number`

#### Inherited from

NumberValidator.maximum

#### Defined in

validator/number.ts:72

• `set` **maximum**(`maximum`): `void`

Sets the number validator's maximum value to maximum.

#### Parameters

| Name | Type |
| :------ | :------ |
| `maximum` | `number` |

#### Returns

`void`

#### Inherited from

NumberValidator.maximum

#### Defined in

validator/number.ts:79

___

### minimum

• `get` **minimum**(): `number`

Returns the number validator's minimum value.

#### Returns

`number`

#### Inherited from

NumberValidator.minimum

#### Defined in

validator/number.ts:58

• `set` **minimum**(`minimum`): `void`

Sets the number validator's minimum value to minimum.

#### Parameters

| Name | Type |
| :------ | :------ |
| `minimum` | `number` |

#### Returns

`void`

#### Inherited from

NumberValidator.minimum

#### Defined in

validator/number.ts:65

___

### pattern

• `get` **pattern**(): `RegExp`

Returns the regular expression of this validator.

#### Returns

`RegExp`

#### Inherited from

NumberValidator.pattern

#### Defined in

validator/validator.ts:36

• `set` **pattern**(`pattern`): `void`

Sets the regular expression of this validator to pattern.

#### Parameters

| Name | Type |
| :------ | :------ |
| `pattern` | `RegExp` |

#### Returns

`void`

#### Inherited from

NumberValidator.pattern

#### Defined in

validator/validator.ts:43

## Methods

### fixup

▸ **fixup**(`input`): `string`

This function attempts to change input to be valid according to this validator's rules.

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` |

#### Returns

`string`

#### Inherited from

[NumberValidator](NumberValidator.md).[fixup](NumberValidator.md#fixup)

#### Defined in

validator/number.ts:39

___

### toValue

▸ `Protected` **toValue**(`input`): `number`

Converts the string to an unsigned integer.

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` |

#### Returns

`number`

#### Overrides

[NumberValidator](NumberValidator.md).[toValue](NumberValidator.md#tovalue)

#### Defined in

validator/unsignedinteger.ts:18

___

### validate

▸ **validate**(`input`): [`ValidatorState`](../enums/ValidatorState.md)

Returns [Invalid](../enums/ValidatorState.md#invalid) if input is invalid according to this validator's rules.
Returns [Intermediate](../enums/ValidatorState.md#intermediate) if input is likely that a little more editing will make the input acceptable.
Returns [Acceptable](../enums/ValidatorState.md#acceptable) if the input is valid.

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` |

#### Returns

[`ValidatorState`](../enums/ValidatorState.md)

#### Inherited from

[NumberValidator](NumberValidator.md).[validate](NumberValidator.md#validate)

#### Defined in

validator/number.ts:25
