[wui.basic](../README.md) / [Exports](../modules.md) / RadioButton

# Class: RadioButton

The RadioButton class is a radio button with a text label, radio buttons typically present the user with a "one of many" choice. 
In a group of radio buttons, only one radio button at a time can be checked; if the user selects another button, the previously selected button is switched off.

## Hierarchy

- [`ToggleButton`](ToggleButton.md)

  ↳ **`RadioButton`**

## Table of contents

### Constructors

- [constructor](RadioButton.md#constructor)

### Properties

- [m\_children](RadioButton.md#m_children)
- [m\_content](RadioButton.md#m_content)
- [m\_dom](RadioButton.md#m_dom)
- [m\_icon](RadioButton.md#m_icon)
- [m\_mode](RadioButton.md#m_mode)
- [m\_parent](RadioButton.md#m_parent)
- [m\_text](RadioButton.md#m_text)
- [Horizontal](RadioButton.md#horizontal)
- [IconMask](RadioButton.md#iconmask)
- [LargeIcon](RadioButton.md#largeicon)
- [LargeMode](RadioButton.md#largemode)
- [LargeText](RadioButton.md#largetext)
- [SmallIcon](RadioButton.md#smallicon)
- [SmallMode](RadioButton.md#smallmode)
- [SmallText](RadioButton.md#smalltext)
- [TextMask](RadioButton.md#textmask)
- [TextMode](RadioButton.md#textmode)
- [ToolMode](RadioButton.md#toolmode)
- [Vertical](RadioButton.md#vertical)

### Accessors

- [blocked](RadioButton.md#blocked)
- [checked](RadioButton.md#checked)
- [children](RadioButton.md#children)
- [css](RadioButton.md#css)
- [dom](RadioButton.md#dom)
- [enabled](RadioButton.md#enabled)
- [group](RadioButton.md#group)
- [height](RadioButton.md#height)
- [id](RadioButton.md#id)
- [image](RadioButton.md#image)
- [left](RadioButton.md#left)
- [mode](RadioButton.md#mode)
- [parent](RadioButton.md#parent)
- [position](RadioButton.md#position)
- [rect](RadioButton.md#rect)
- [size](RadioButton.md#size)
- [style](RadioButton.md#style)
- [text](RadioButton.md#text)
- [toggled](RadioButton.md#toggled)
- [tooltip](RadioButton.md#tooltip)
- [top](RadioButton.md#top)
- [visible](RadioButton.md#visible)
- [width](RadioButton.md#width)
- [sender](RadioButton.md#sender)

### Methods

- [addAttr](RadioButton.md#addattr)
- [addClass](RadioButton.md#addclass)
- [attach](RadioButton.md#attach)
- [bind](RadioButton.md#bind)
- [clearChildren](RadioButton.md#clearchildren)
- [close](RadioButton.md#close)
- [delegate](RadioButton.md#delegate)
- [destroy](RadioButton.md#destroy)
- [detach](RadioButton.md#detach)
- [emit](RadioButton.md#emit)
- [free](RadioButton.md#free)
- [hasAttr](RadioButton.md#hasattr)
- [hasClass](RadioButton.md#hasclass)
- [hide](RadioButton.md#hide)
- [insertChild](RadioButton.md#insertchild)
- [raise](RadioButton.md#raise)
- [removeAttr](RadioButton.md#removeattr)
- [removeClass](RadioButton.md#removeclass)
- [setFlex](RadioButton.md#setflex)
- [show](RadioButton.md#show)
- [toggleAttr](RadioButton.md#toggleattr)
- [toggleClass](RadioButton.md#toggleclass)
- [unbind](RadioButton.md#unbind)
- [update](RadioButton.md#update)

## Constructors

### constructor

• **new RadioButton**(`parent?`, `text?`)

Constructs a radio button with the given parent and text.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent?` | [`Widget`](Widget.md) |
| `text?` | `string` |

#### Overrides

[ToggleButton](ToggleButton.md).[constructor](ToggleButton.md#constructor)

#### Defined in

widget/togglebutton.ts:121

## Properties

### m\_children

• `Protected` **m\_children**: [`Widget`](Widget.md)[] = `[]`

#### Inherited from

[ToggleButton](ToggleButton.md).[m_children](ToggleButton.md#m_children)

#### Defined in

widget/widget.ts:15

___

### m\_content

• `Protected` **m\_content**: [`Widget`](Widget.md)

#### Inherited from

[ToggleButton](ToggleButton.md).[m_content](ToggleButton.md#m_content)

#### Defined in

widget/widget.ts:14

___

### m\_dom

• `Protected` **m\_dom**: `HTMLElement`

#### Inherited from

[ToggleButton](ToggleButton.md).[m_dom](ToggleButton.md#m_dom)

#### Defined in

widget/widget.ts:12

___

### m\_icon

• `Protected` **m\_icon**: [`Icon`](Icon.md)

#### Inherited from

[ToggleButton](ToggleButton.md).[m_icon](ToggleButton.md#m_icon)

#### Defined in

widget/button.ts:21

___

### m\_mode

• `Protected` **m\_mode**: `number`

#### Inherited from

[ToggleButton](ToggleButton.md).[m_mode](ToggleButton.md#m_mode)

#### Defined in

widget/button.ts:23

___

### m\_parent

• `Protected` **m\_parent**: [`Widget`](Widget.md)

#### Inherited from

[ToggleButton](ToggleButton.md).[m_parent](ToggleButton.md#m_parent)

#### Defined in

widget/widget.ts:13

___

### m\_text

• `Protected` **m\_text**: [`Text`](Text.md)

#### Inherited from

[ToggleButton](ToggleButton.md).[m_text](ToggleButton.md#m_text)

#### Defined in

widget/button.ts:22

___

### Horizontal

▪ `Static` `Readonly` **Horizontal**: ``256``

#### Inherited from

[ToggleButton](ToggleButton.md).[Horizontal](ToggleButton.md#horizontal)

#### Defined in

widget/button.ts:12

___

### IconMask

▪ `Static` `Readonly` **IconMask**: ``240``

#### Inherited from

[ToggleButton](ToggleButton.md).[IconMask](ToggleButton.md#iconmask)

#### Defined in

widget/button.ts:14

___

### LargeIcon

▪ `Static` `Readonly` **LargeIcon**: ``32``

#### Inherited from

[ToggleButton](ToggleButton.md).[LargeIcon](ToggleButton.md#largeicon)

#### Defined in

widget/button.ts:11

___

### LargeMode

▪ `Static` `Readonly` **LargeMode**: `number`

#### Inherited from

[ToggleButton](ToggleButton.md).[LargeMode](ToggleButton.md#largemode)

#### Defined in

widget/button.ts:16

___

### LargeText

▪ `Static` `Readonly` **LargeText**: ``2``

#### Inherited from

[ToggleButton](ToggleButton.md).[LargeText](ToggleButton.md#largetext)

#### Defined in

widget/button.ts:9

___

### SmallIcon

▪ `Static` `Readonly` **SmallIcon**: ``16``

#### Inherited from

[ToggleButton](ToggleButton.md).[SmallIcon](ToggleButton.md#smallicon)

#### Defined in

widget/button.ts:10

___

### SmallMode

▪ `Static` `Readonly` **SmallMode**: `number`

#### Inherited from

[ToggleButton](ToggleButton.md).[SmallMode](ToggleButton.md#smallmode)

#### Defined in

widget/button.ts:17

___

### SmallText

▪ `Static` `Readonly` **SmallText**: ``1``

#### Inherited from

[ToggleButton](ToggleButton.md).[SmallText](ToggleButton.md#smalltext)

#### Defined in

widget/button.ts:8

___

### TextMask

▪ `Static` `Readonly` **TextMask**: ``15``

#### Inherited from

[ToggleButton](ToggleButton.md).[TextMask](ToggleButton.md#textmask)

#### Defined in

widget/button.ts:15

___

### TextMode

▪ `Static` `Readonly` **TextMode**: `number`

#### Inherited from

[ToggleButton](ToggleButton.md).[TextMode](ToggleButton.md#textmode)

#### Defined in

widget/button.ts:18

___

### ToolMode

▪ `Static` `Readonly` **ToolMode**: `number`

#### Inherited from

[ToggleButton](ToggleButton.md).[ToolMode](ToggleButton.md#toolmode)

#### Defined in

widget/button.ts:19

___

### Vertical

▪ `Static` `Readonly` **Vertical**: ``512``

#### Inherited from

[ToggleButton](ToggleButton.md).[Vertical](ToggleButton.md#vertical)

#### Defined in

widget/button.ts:13

## Accessors

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Inherited from

ToggleButton.blocked

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Inherited from

ToggleButton.blocked

#### Defined in

abstract/eventwatcher.ts:85

___

### checked

• `get` **checked**(): `boolean`

This property is the same as [toggled](ToggleButton.md#toggled).

#### Returns

`boolean`

#### Inherited from

ToggleButton.checked

#### Defined in

widget/togglebutton.ts:103

• `set` **checked**(`checked`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `checked` | `boolean` |

#### Returns

`void`

#### Inherited from

ToggleButton.checked

#### Defined in

widget/togglebutton.ts:107

___

### children

• `get` **children**(): readonly [`Widget`](Widget.md)[]

Returns the list of children.

#### Returns

readonly [`Widget`](Widget.md)[]

#### Inherited from

ToggleButton.children

#### Defined in

widget/widget.ts:104

___

### css

• `set` **css**(`style`): `void`

Sets the style of this widget. See also [id](Widget.md#id) [addClass](Widget.md#addclass).

#### Parameters

| Name | Type |
| :------ | :------ |
| `style` | `Partial`<[`StyleSheets`](../interfaces/StyleSheets.md)\> |

#### Returns

`void`

#### Inherited from

ToggleButton.css

#### Defined in

widget/widget.ts:244

___

### dom

• `get` **dom**(): `HTMLButtonElement`

Returns the dom of this button.

#### Returns

`HTMLButtonElement`

#### Inherited from

ToggleButton.dom

#### Defined in

widget/button.ts:48

___

### enabled

• `get` **enabled**(): `boolean`

Returns whether this widget or its parent chain is enabled or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

ToggleButton.enabled

#### Defined in

widget/widget.ts:207

• `set` **enabled**(`enabled`): `void`

Sets whether this widget is enabled or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `enabled` | `boolean` |

#### Returns

`void`

#### Inherited from

ToggleButton.enabled

#### Defined in

widget/widget.ts:214

___

### group

• `get` **group**(): [`ButtonGroup`](ButtonGroup.md)

Returns the group that this button belongs to.
If the button is not a member of any button group, this function returns undefined.

#### Returns

[`ButtonGroup`](ButtonGroup.md)

#### Inherited from

ToggleButton.group

#### Defined in

widget/togglebutton.ts:72

• `set` **group**(`group`): `void`

Adds this button to the given button group.

#### Parameters

| Name | Type |
| :------ | :------ |
| `group` | [`ButtonGroup`](ButtonGroup.md) |

#### Returns

`void`

#### Inherited from

ToggleButton.group

#### Defined in

widget/togglebutton.ts:79

___

### height

• `get` **height**(): `number`

Returns the height of this widget.

#### Returns

`number`

#### Inherited from

ToggleButton.height

#### Defined in

widget/widget.ts:160

• `set` **height**(`height`): `void`

Sets the height of this widget to the given height.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `height` | `number` | The unit of height is px. |

#### Returns

`void`

#### Inherited from

ToggleButton.height

#### Defined in

widget/widget.ts:177

___

### id

• `get` **id**(): `string`

Returns the id of this widget.

#### Returns

`string`

#### Inherited from

ToggleButton.id

#### Defined in

widget/widget.ts:221

• `set` **id**(`id`): `void`

Set the id of this widget to the given id.
The id is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `id` | `string` |

#### Returns

`void`

#### Inherited from

ToggleButton.id

#### Defined in

widget/widget.ts:230

___

### image

• `get` **image**(): `string`

Returns the image shown on this button.

#### Returns

`string`

#### Inherited from

ToggleButton.image

#### Defined in

widget/button.ts:55

• `set` **image**(`icon`): `void`

Sets the image shown on this button to the given icon.

#### Parameters

| Name | Type |
| :------ | :------ |
| `icon` | `string` |

#### Returns

`void`

#### Inherited from

ToggleButton.image

#### Defined in

widget/button.ts:62

___

### left

• `get` **left**(): `number`

Returns the left coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

ToggleButton.left

#### Defined in

widget/widget.ts:280

• `set` **left**(`left`): `void`

Sets the left coordinate of this widget to the given left.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `left` | `number` | The unit of left is px. |

#### Returns

`void`

#### Inherited from

ToggleButton.left

#### Defined in

widget/widget.ts:273

___

### mode

• `get` **mode**(): `number`

Returns the mode of this button, the default mode is TextMode.

The image is shown on this button when in icon mode. 
The image's default size is Size(16, 16). When in large icon mode, the image's size is Size(32, 32).

#### Returns

`number`

#### Inherited from

ToggleButton.mode

#### Defined in

widget/button.ts:112

• `set` **mode**(`mode`): `void`

Sets the mode of the button to the given mode.

#### Parameters

| Name | Type |
| :------ | :------ |
| `mode` | `number` |

#### Returns

`void`

#### Inherited from

ToggleButton.mode

#### Defined in

widget/button.ts:119

___

### parent

• `get` **parent**(): [`Widget`](Widget.md)

Returns the parent of this widget, or undefined if it does not have any parent widget.

#### Returns

[`Widget`](Widget.md)

#### Inherited from

ToggleButton.parent

#### Defined in

widget/widget.ts:85

• `set` **parent**(`parent`): `void`

Sets the parent of the widget to the given parent.
If the new parent widget is the old parent widget, this function does nothing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

ToggleButton.parent

#### Defined in

widget/widget.ts:93

___

### position

• `get` **position**(): [`Point`](Point.md)

Returns the position of this widget relative to its parent.

#### Returns

[`Point`](Point.md)

#### Inherited from

ToggleButton.position

#### Defined in

widget/widget.ts:311

• `set` **position**(`position`): `void`

Sets the position of this widget to the given position.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `position` | [`Point`](Point.md) | The unit of position is px. |

#### Returns

`void`

#### Inherited from

ToggleButton.position

#### Defined in

widget/widget.ts:303

___

### rect

• `get` **rect**(): [`Rect`](Rect.md)

Returns the rect of this widget relative to the desktop.

#### Returns

[`Rect`](Rect.md)

#### Inherited from

ToggleButton.rect

#### Defined in

widget/widget.ts:318

___

### size

• `get` **size**(): [`Size`](Size.md)

Returns the size of this widget.

#### Returns

[`Size`](Size.md)

#### Inherited from

ToggleButton.size

#### Defined in

widget/widget.ts:118

• `set` **size**(`size`): `void`

Sets the size of this widget to the given size.
If the size is Size(0, 0) will cause the widget to not appear on screen.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `size` | [`Size`](Size.md) | The unit of size is px. |

#### Returns

`void`

#### Inherited from

ToggleButton.size

#### Defined in

widget/widget.ts:128

___

### style

• `get` **style**(): `CSSStyleDeclaration`

Returns the style of this widget.

#### Returns

`CSSStyleDeclaration`

#### Inherited from

ToggleButton.style

#### Defined in

widget/widget.ts:237

___

### text

• `get` **text**(): `string`

Returns the text shown on this button.

#### Returns

`string`

#### Inherited from

ToggleButton.text

#### Defined in

widget/button.ts:82

• `set` **text**(`text`): `void`

Sets the text shown on this button to the given text.

#### Parameters

| Name | Type |
| :------ | :------ |
| `text` | `string` |

#### Returns

`void`

#### Inherited from

ToggleButton.text

#### Defined in

widget/button.ts:89

___

### toggled

• `get` **toggled**(): `boolean`

Returns whether the button is checked or not.

#### Returns

`boolean`

#### Inherited from

ToggleButton.toggled

#### Defined in

widget/togglebutton.ts:86

• `set` **toggled**(`toggled`): `void`

Sets whether the button is checked or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `toggled` | `boolean` |

#### Returns

`void`

#### Inherited from

ToggleButton.toggled

#### Defined in

widget/togglebutton.ts:93

___

### tooltip

• `get` **tooltip**(): `string`

Returns the tooltip of this widget.
By default, the value of this property is an empty string.

#### Returns

`string`

#### Inherited from

ToggleButton.tooltip

#### Defined in

widget/widget.ts:254

• `set` **tooltip**(`tooltip`): `void`

Sets the tooltip of this widget to the given tooltip.

#### Parameters

| Name | Type |
| :------ | :------ |
| `tooltip` | `string` |

#### Returns

`void`

#### Inherited from

ToggleButton.tooltip

#### Defined in

widget/widget.ts:261

___

### top

• `get` **top**(): `number`

Returns the top coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

ToggleButton.top

#### Defined in

widget/widget.ts:295

• `set` **top**(`top`): `void`

Sets the top coordinate of this widget to the given top.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `top` | `number` | The unit of top is px. |

#### Returns

`void`

#### Inherited from

ToggleButton.top

#### Defined in

widget/widget.ts:288

___

### visible

• `get` **visible**(): `boolean`

Returns whether this widget or its parent chain is visible or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

ToggleButton.visible

#### Defined in

widget/widget.ts:185

• `set` **visible**(`visible`): `void`

Sets whether this widget is visible or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `visible` | `boolean` |

#### Returns

`void`

#### Inherited from

ToggleButton.visible

#### Defined in

widget/widget.ts:192

___

### width

• `get` **width**(): `number`

Returns the width of this widget.

#### Returns

`number`

#### Inherited from

ToggleButton.width

#### Defined in

widget/widget.ts:136

• `set` **width**(`width`): `void`

Sets the width of this widget to the given width.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `width` | `number` | The unit of width is px. |

#### Returns

`void`

#### Inherited from

ToggleButton.width

#### Defined in

widget/widget.ts:153

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Inherited from

ToggleButton.sender

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### addAttr

▸ **addAttr**(`attr`): `void`

Adds the attribute of this widget.
The attribute is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[addAttr](ToggleButton.md#addattr)

#### Defined in

widget/widget.ts:375

___

### addClass

▸ **addClass**(`className`): `void`

Adds the class name of this widget.
The class name is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[addClass](ToggleButton.md#addclass)

#### Defined in

widget/widget.ts:344

___

### attach

▸ `Protected` **attach**(): `void`

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[attach](ToggleButton.md#attach)

#### Defined in

widget/widget.ts:461

___

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[bind](ToggleButton.md#bind)

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[bind](ToggleButton.md#bind)

#### Defined in

abstract/eventwatcher.ts:29

___

### clearChildren

▸ **clearChildren**(): `void`

Clears all widgets in the list of children.

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[clearChildren](ToggleButton.md#clearchildren)

#### Defined in

widget/widget.ts:450

___

### close

▸ **close**(): `void`

Closes this widget.
This function is equivalent to setting this widget's parent to undefined.

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[close](ToggleButton.md#close)

#### Defined in

widget/widget.ts:62

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[delegate](ToggleButton.md#delegate)

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[delegate](ToggleButton.md#delegate)

#### Defined in

abstract/eventwatcher.ts:68

___

### destroy

▸ **destroy**(): `void`

Destroys the widget, All the widget's children are destroyed first.

The widget is destroyed when it’s parent is destroyed. When the widget is destroyed, make sure to release all resources, such as timers, etc.
Releases the resources in function free(), The system will call this function automatically when the parent widget or itself is destroyed.
See also [free](Widget.md#free).

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[destroy](ToggleButton.md#destroy)

#### Defined in

widget/widget.ts:40

___

### detach

▸ `Protected` **detach**(): `void`

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[detach](ToggleButton.md#detach)

#### Defined in

widget/widget.ts:471

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Inherited from

[ToggleButton](ToggleButton.md).[emit](ToggleButton.md#emit)

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Inherited from

[ToggleButton](ToggleButton.md).[emit](ToggleButton.md#emit)

#### Defined in

abstract/eventwatcher.ts:49

___

### free

▸ `Protected` **free**(): `void`

Frees the resources.See also [destroy](Widget.md#destroy).

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[free](ToggleButton.md#free)

#### Defined in

widget/widget.ts:55

___

### hasAttr

▸ **hasAttr**(`attr`): `boolean`

Returns whether this widget contains the attribute.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`boolean`

#### Inherited from

[ToggleButton](ToggleButton.md).[hasAttr](ToggleButton.md#hasattr)

#### Defined in

widget/widget.ts:389

___

### hasClass

▸ **hasClass**(`className`): `boolean`

Returns whether this widget contains the class name.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`boolean`

#### Inherited from

[ToggleButton](ToggleButton.md).[hasClass](ToggleButton.md#hasclass)

#### Defined in

widget/widget.ts:358

___

### hide

▸ **hide**(): `void`

Hides the widget and its child widgets.
This function is equivalent to setting the visible property to false.

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[hide](ToggleButton.md#hide)

#### Defined in

widget/widget.ts:78

___

### insertChild

▸ **insertChild**(`index`, `widget`): `void`

Inserts the child widget at index in the list of children.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[insertChild](ToggleButton.md#insertchild)

#### Defined in

widget/widget.ts:431

___

### raise

▸ **raise**(): `boolean`

Raises this widget to the top of the parent widget's children.
The display order of this widget is determined by the order in which they appear in the parent widget's children.

#### Returns

`boolean`

#### Inherited from

[ToggleButton](ToggleButton.md).[raise](ToggleButton.md#raise)

#### Defined in

widget/widget.ts:406

___

### removeAttr

▸ **removeAttr**(`attr`): `void`

Removes the attribute of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[removeAttr](ToggleButton.md#removeattr)

#### Defined in

widget/widget.ts:382

___

### removeClass

▸ **removeClass**(`className`): `void`

Removes the class name of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[removeClass](ToggleButton.md#removeclass)

#### Defined in

widget/widget.ts:351

___

### setFlex

▸ **setFlex**(`orientation`, `alignItem?`, `spacing?`): `void`

Sets whether the widget uses flex layout.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `orientation` | [`Orientation`](../enums/Orientation.md) | Horizontal or vertical. |
| `alignItem?` | ``"center"`` \| ``"inherit"`` \| ``"stretch"`` \| ``"flex-start"`` \| ``"flex-end"`` \| ``"initial"`` \| ``"baseline"`` | @see(https://developer.mozilla.org/en-US/docs/Web/CSS/align-items) |
| `spacing?` | `number` | the spacing between widgets inside the layout. |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[setFlex](ToggleButton.md#setflex)

#### Defined in

widget/widget.ts:329

___

### show

▸ **show**(): `void`

Shows the widget and its child widgets.
This function is equivalent to setting the visible property to true.

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[show](ToggleButton.md#show)

#### Defined in

widget/widget.ts:70

___

### toggleAttr

▸ **toggleAttr**(`attr`, `on`): `void`

If param attr is true, adds the attribute, otherwise removes the attribute.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `attr` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[toggleAttr](ToggleButton.md#toggleattr)

#### Defined in

widget/widget.ts:398

___

### toggleClass

▸ **toggleClass**(`className`, `on`): `void`

If param on is true, adds the class name, otherwise removes the class name.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `className` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[toggleClass](ToggleButton.md#toggleclass)

#### Defined in

widget/widget.ts:367

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[unbind](ToggleButton.md#unbind)

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[unbind](ToggleButton.md#unbind)

#### Defined in

abstract/eventwatcher.ts:38

___

### update

▸ `Protected` **update**(): `void`

#### Returns

`void`

#### Inherited from

[ToggleButton](ToggleButton.md).[update](ToggleButton.md#update)

#### Defined in

widget/button.ts:125
