[wui.basic](../README.md) / [Exports](../modules.md) / FormatEdit

# Class: FormatEdit

The FormatEdit is a edit with a validator.
The text can be arbitrarily constrained using a validator.

## Hierarchy

- [`Edit`](Edit.md)

  ↳ **`FormatEdit`**

  ↳↳ [`NumberEdit`](NumberEdit.md)

## Table of contents

### Constructors

- [constructor](FormatEdit.md#constructor)

### Properties

- [m\_children](FormatEdit.md#m_children)
- [m\_content](FormatEdit.md#m_content)
- [m\_dom](FormatEdit.md#m_dom)
- [m\_parent](FormatEdit.md#m_parent)
- [m\_text](FormatEdit.md#m_text)
- [m\_validator](FormatEdit.md#m_validator)

### Accessors

- [alignment](FormatEdit.md#alignment)
- [blocked](FormatEdit.md#blocked)
- [children](FormatEdit.md#children)
- [css](FormatEdit.md#css)
- [dom](FormatEdit.md#dom)
- [enabled](FormatEdit.md#enabled)
- [height](FormatEdit.md#height)
- [id](FormatEdit.md#id)
- [left](FormatEdit.md#left)
- [parent](FormatEdit.md#parent)
- [password](FormatEdit.md#password)
- [placeholder](FormatEdit.md#placeholder)
- [position](FormatEdit.md#position)
- [readonly](FormatEdit.md#readonly)
- [rect](FormatEdit.md#rect)
- [size](FormatEdit.md#size)
- [style](FormatEdit.md#style)
- [text](FormatEdit.md#text)
- [tooltip](FormatEdit.md#tooltip)
- [top](FormatEdit.md#top)
- [validator](FormatEdit.md#validator)
- [visible](FormatEdit.md#visible)
- [width](FormatEdit.md#width)
- [sender](FormatEdit.md#sender)

### Methods

- [addAttr](FormatEdit.md#addattr)
- [addClass](FormatEdit.md#addclass)
- [attach](FormatEdit.md#attach)
- [bind](FormatEdit.md#bind)
- [clearChildren](FormatEdit.md#clearchildren)
- [close](FormatEdit.md#close)
- [create](FormatEdit.md#create)
- [delegate](FormatEdit.md#delegate)
- [destroy](FormatEdit.md#destroy)
- [detach](FormatEdit.md#detach)
- [emit](FormatEdit.md#emit)
- [free](FormatEdit.md#free)
- [hasAttr](FormatEdit.md#hasattr)
- [hasClass](FormatEdit.md#hasclass)
- [hide](FormatEdit.md#hide)
- [insertChild](FormatEdit.md#insertchild)
- [raise](FormatEdit.md#raise)
- [removeAttr](FormatEdit.md#removeattr)
- [removeClass](FormatEdit.md#removeclass)
- [setFlex](FormatEdit.md#setflex)
- [show](FormatEdit.md#show)
- [toggleAttr](FormatEdit.md#toggleattr)
- [toggleClass](FormatEdit.md#toggleclass)
- [unbind](FormatEdit.md#unbind)

## Constructors

### constructor

• **new FormatEdit**(`parent?`)

Constructs a format edit.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent?` | [`Widget`](Widget.md) |

#### Overrides

[Edit](Edit.md).[constructor](Edit.md#constructor)

#### Defined in

widget/edit.ts:135

## Properties

### m\_children

• `Protected` **m\_children**: [`Widget`](Widget.md)[] = `[]`

#### Inherited from

[Edit](Edit.md).[m_children](Edit.md#m_children)

#### Defined in

widget/widget.ts:15

___

### m\_content

• `Protected` **m\_content**: [`Widget`](Widget.md)

#### Inherited from

[Edit](Edit.md).[m_content](Edit.md#m_content)

#### Defined in

widget/widget.ts:14

___

### m\_dom

• `Protected` **m\_dom**: `HTMLElement`

#### Inherited from

[Edit](Edit.md).[m_dom](Edit.md#m_dom)

#### Defined in

widget/widget.ts:12

___

### m\_parent

• `Protected` **m\_parent**: [`Widget`](Widget.md)

#### Inherited from

[Edit](Edit.md).[m_parent](Edit.md#m_parent)

#### Defined in

widget/widget.ts:13

___

### m\_text

• `Protected` **m\_text**: `string` = `''`

#### Defined in

widget/edit.ts:129

___

### m\_validator

• `Protected` **m\_validator**: [`Validator`](Validator.md)

#### Defined in

widget/edit.ts:130

## Accessors

### alignment

• `get` **alignment**(): [`Alignment`](../enums/Alignment.md)

Returns the alignment of this edit.

#### Returns

[`Alignment`](../enums/Alignment.md)

#### Inherited from

Edit.alignment

#### Defined in

widget/edit.ts:119

• `set` **alignment**(`align`): `void`

Sets the alignment of this edit to the given align.

#### Parameters

| Name | Type |
| :------ | :------ |
| `align` | [`Alignment`](../enums/Alignment.md) |

#### Returns

`void`

#### Inherited from

Edit.alignment

#### Defined in

widget/edit.ts:112

___

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Inherited from

Edit.blocked

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Inherited from

Edit.blocked

#### Defined in

abstract/eventwatcher.ts:85

___

### children

• `get` **children**(): readonly [`Widget`](Widget.md)[]

Returns the list of children.

#### Returns

readonly [`Widget`](Widget.md)[]

#### Inherited from

Edit.children

#### Defined in

widget/widget.ts:104

___

### css

• `set` **css**(`style`): `void`

Sets the style of this widget. See also [id](Widget.md#id) [addClass](Widget.md#addclass).

#### Parameters

| Name | Type |
| :------ | :------ |
| `style` | `Partial`<[`StyleSheets`](../interfaces/StyleSheets.md)\> |

#### Returns

`void`

#### Inherited from

Edit.css

#### Defined in

widget/widget.ts:244

___

### dom

• `get` **dom**(): `HTMLInputElement`

Returns the dom of this edit.

#### Returns

`HTMLInputElement`

#### Inherited from

Edit.dom

#### Defined in

widget/edit.ts:36

___

### enabled

• `get` **enabled**(): `boolean`

Returns whether this widget or its parent chain is enabled or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

Edit.enabled

#### Defined in

widget/widget.ts:207

• `set` **enabled**(`enabled`): `void`

Sets whether this widget is enabled or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `enabled` | `boolean` |

#### Returns

`void`

#### Inherited from

Edit.enabled

#### Defined in

widget/widget.ts:214

___

### height

• `get` **height**(): `number`

Returns the height of this widget.

#### Returns

`number`

#### Inherited from

Edit.height

#### Defined in

widget/widget.ts:160

• `set` **height**(`height`): `void`

Sets the height of this widget to the given height.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `height` | `number` | The unit of height is px. |

#### Returns

`void`

#### Inherited from

Edit.height

#### Defined in

widget/widget.ts:177

___

### id

• `get` **id**(): `string`

Returns the id of this widget.

#### Returns

`string`

#### Inherited from

Edit.id

#### Defined in

widget/widget.ts:221

• `set` **id**(`id`): `void`

Set the id of this widget to the given id.
The id is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `id` | `string` |

#### Returns

`void`

#### Inherited from

Edit.id

#### Defined in

widget/widget.ts:230

___

### left

• `get` **left**(): `number`

Returns the left coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

Edit.left

#### Defined in

widget/widget.ts:280

• `set` **left**(`left`): `void`

Sets the left coordinate of this widget to the given left.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `left` | `number` | The unit of left is px. |

#### Returns

`void`

#### Inherited from

Edit.left

#### Defined in

widget/widget.ts:273

___

### parent

• `get` **parent**(): [`Widget`](Widget.md)

Returns the parent of this widget, or undefined if it does not have any parent widget.

#### Returns

[`Widget`](Widget.md)

#### Inherited from

Edit.parent

#### Defined in

widget/widget.ts:85

• `set` **parent**(`parent`): `void`

Sets the parent of the widget to the given parent.
If the new parent widget is the old parent widget, this function does nothing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

Edit.parent

#### Defined in

widget/widget.ts:93

___

### password

• `get` **password**(): `boolean`

Returns the password property of this edit.

#### Returns

`boolean`

#### Inherited from

Edit.password

#### Defined in

widget/edit.ts:105

• `set` **password**(`password`): `void`

Sets the password property to the given password.
If the property is true, this edit displays password mask characters instead of the characters actually entered.

#### Parameters

| Name | Type |
| :------ | :------ |
| `password` | `boolean` |

#### Returns

`void`

#### Inherited from

Edit.password

#### Defined in

widget/edit.ts:93

___

### placeholder

• `get` **placeholder**(): `string`

Returns the placeholder text of this edit.
By default, the value of this property is an empty string.

#### Returns

`string`

#### Inherited from

Edit.placeholder

#### Defined in

widget/edit.ts:77

• `set` **placeholder**(`source`): `void`

Sets the placeholder text of this edit.
Normally, an empty edit shows the placeholder text.

#### Parameters

| Name | Type |
| :------ | :------ |
| `source` | `string` |

#### Returns

`void`

#### Inherited from

Edit.placeholder

#### Defined in

widget/edit.ts:85

___

### position

• `get` **position**(): [`Point`](Point.md)

Returns the position of this widget relative to its parent.

#### Returns

[`Point`](Point.md)

#### Inherited from

Edit.position

#### Defined in

widget/widget.ts:311

• `set` **position**(`position`): `void`

Sets the position of this widget to the given position.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `position` | [`Point`](Point.md) | The unit of position is px. |

#### Returns

`void`

#### Inherited from

Edit.position

#### Defined in

widget/widget.ts:303

___

### readonly

• `get` **readonly**(): `boolean`

Returns whether this edit is read only or not.
In read only mode, the user cannot edit it.
By default, the value of this property is false.

#### Returns

`boolean`

#### Inherited from

Edit.readonly

#### Defined in

widget/edit.ts:62

• `set` **readonly**(`readonly`): `void`

Sets whether this edit is read only or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `readonly` | `boolean` |

#### Returns

`void`

#### Inherited from

Edit.readonly

#### Defined in

widget/edit.ts:69

___

### rect

• `get` **rect**(): [`Rect`](Rect.md)

Returns the rect of this widget relative to the desktop.

#### Returns

[`Rect`](Rect.md)

#### Inherited from

Edit.rect

#### Defined in

widget/widget.ts:318

___

### size

• `get` **size**(): [`Size`](Size.md)

Returns the size of this widget.

#### Returns

[`Size`](Size.md)

#### Inherited from

Edit.size

#### Defined in

widget/widget.ts:118

• `set` **size**(`size`): `void`

Sets the size of this widget to the given size.
If the size is Size(0, 0) will cause the widget to not appear on screen.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `size` | [`Size`](Size.md) | The unit of size is px. |

#### Returns

`void`

#### Inherited from

Edit.size

#### Defined in

widget/widget.ts:128

___

### style

• `get` **style**(): `CSSStyleDeclaration`

Returns the style of this widget.

#### Returns

`CSSStyleDeclaration`

#### Inherited from

Edit.style

#### Defined in

widget/widget.ts:237

___

### text

• `get` **text**(): `string`

Returns the text of this edit.
By default, the value of this property is an empty string.

#### Returns

`string`

#### Overrides

Edit.text

#### Defined in

widget/edit.ts:147

• `set` **text**(`text`): `void`

Sets the text of this edit to the given text.

#### Parameters

| Name | Type |
| :------ | :------ |
| `text` | `string` |

#### Returns

`void`

#### Overrides

Edit.text

#### Defined in

widget/edit.ts:154

___

### tooltip

• `get` **tooltip**(): `string`

Returns the tooltip of this widget.
By default, the value of this property is an empty string.

#### Returns

`string`

#### Inherited from

Edit.tooltip

#### Defined in

widget/widget.ts:254

• `set` **tooltip**(`tooltip`): `void`

Sets the tooltip of this widget to the given tooltip.

#### Parameters

| Name | Type |
| :------ | :------ |
| `tooltip` | `string` |

#### Returns

`void`

#### Inherited from

Edit.tooltip

#### Defined in

widget/widget.ts:261

___

### top

• `get` **top**(): `number`

Returns the top coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

Edit.top

#### Defined in

widget/widget.ts:295

• `set` **top**(`top`): `void`

Sets the top coordinate of this widget to the given top.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `top` | `number` | The unit of top is px. |

#### Returns

`void`

#### Inherited from

Edit.top

#### Defined in

widget/widget.ts:288

___

### validator

• `get` **validator**(): [`Validator`](Validator.md)

Returns the validator of this edit.
By default, the value of this property is undefined.

#### Returns

[`Validator`](Validator.md)

#### Defined in

widget/edit.ts:167

• `set` **validator**(`validator`): `void`

Sets the validator of this edit to the given validator;

#### Parameters

| Name | Type |
| :------ | :------ |
| `validator` | [`Validator`](Validator.md) |

#### Returns

`void`

#### Defined in

widget/edit.ts:174

___

### visible

• `get` **visible**(): `boolean`

Returns whether this widget or its parent chain is visible or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

Edit.visible

#### Defined in

widget/widget.ts:185

• `set` **visible**(`visible`): `void`

Sets whether this widget is visible or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `visible` | `boolean` |

#### Returns

`void`

#### Inherited from

Edit.visible

#### Defined in

widget/widget.ts:192

___

### width

• `get` **width**(): `number`

Returns the width of this widget.

#### Returns

`number`

#### Inherited from

Edit.width

#### Defined in

widget/widget.ts:136

• `set` **width**(`width`): `void`

Sets the width of this widget to the given width.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `width` | `number` | The unit of width is px. |

#### Returns

`void`

#### Inherited from

Edit.width

#### Defined in

widget/widget.ts:153

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Inherited from

Edit.sender

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### addAttr

▸ **addAttr**(`attr`): `void`

Adds the attribute of this widget.
The attribute is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[addAttr](Edit.md#addattr)

#### Defined in

widget/widget.ts:375

___

### addClass

▸ **addClass**(`className`): `void`

Adds the class name of this widget.
The class name is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[addClass](Edit.md#addclass)

#### Defined in

widget/widget.ts:344

___

### attach

▸ `Protected` **attach**(): `void`

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[attach](Edit.md#attach)

#### Defined in

widget/widget.ts:461

___

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[bind](Edit.md#bind)

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[bind](Edit.md#bind)

#### Defined in

abstract/eventwatcher.ts:29

___

### clearChildren

▸ **clearChildren**(): `void`

Clears all widgets in the list of children.

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[clearChildren](Edit.md#clearchildren)

#### Defined in

widget/widget.ts:450

___

### close

▸ **close**(): `void`

Closes this widget.
This function is equivalent to setting this widget's parent to undefined.

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[close](Edit.md#close)

#### Defined in

widget/widget.ts:62

___

### create

▸ `Protected` **create**(): `void`

#### Returns

`void`

#### Overrides

[Edit](Edit.md).[create](Edit.md#create)

#### Defined in

widget/edit.ts:139

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[delegate](Edit.md#delegate)

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[delegate](Edit.md#delegate)

#### Defined in

abstract/eventwatcher.ts:68

___

### destroy

▸ **destroy**(): `void`

Destroys the widget, All the widget's children are destroyed first.

The widget is destroyed when it’s parent is destroyed. When the widget is destroyed, make sure to release all resources, such as timers, etc.
Releases the resources in function free(), The system will call this function automatically when the parent widget or itself is destroyed.
See also [free](Widget.md#free).

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[destroy](Edit.md#destroy)

#### Defined in

widget/widget.ts:40

___

### detach

▸ `Protected` **detach**(): `void`

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[detach](Edit.md#detach)

#### Defined in

widget/widget.ts:471

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Inherited from

[Edit](Edit.md).[emit](Edit.md#emit)

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Inherited from

[Edit](Edit.md).[emit](Edit.md#emit)

#### Defined in

abstract/eventwatcher.ts:49

___

### free

▸ `Protected` **free**(): `void`

Frees the resources.See also [destroy](Widget.md#destroy).

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[free](Edit.md#free)

#### Defined in

widget/widget.ts:55

___

### hasAttr

▸ **hasAttr**(`attr`): `boolean`

Returns whether this widget contains the attribute.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`boolean`

#### Inherited from

[Edit](Edit.md).[hasAttr](Edit.md#hasattr)

#### Defined in

widget/widget.ts:389

___

### hasClass

▸ **hasClass**(`className`): `boolean`

Returns whether this widget contains the class name.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`boolean`

#### Inherited from

[Edit](Edit.md).[hasClass](Edit.md#hasclass)

#### Defined in

widget/widget.ts:358

___

### hide

▸ **hide**(): `void`

Hides the widget and its child widgets.
This function is equivalent to setting the visible property to false.

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[hide](Edit.md#hide)

#### Defined in

widget/widget.ts:78

___

### insertChild

▸ **insertChild**(`index`, `widget`): `void`

Inserts the child widget at index in the list of children.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[insertChild](Edit.md#insertchild)

#### Defined in

widget/widget.ts:431

___

### raise

▸ **raise**(): `boolean`

Raises this widget to the top of the parent widget's children.
The display order of this widget is determined by the order in which they appear in the parent widget's children.

#### Returns

`boolean`

#### Inherited from

[Edit](Edit.md).[raise](Edit.md#raise)

#### Defined in

widget/widget.ts:406

___

### removeAttr

▸ **removeAttr**(`attr`): `void`

Removes the attribute of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[removeAttr](Edit.md#removeattr)

#### Defined in

widget/widget.ts:382

___

### removeClass

▸ **removeClass**(`className`): `void`

Removes the class name of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[removeClass](Edit.md#removeclass)

#### Defined in

widget/widget.ts:351

___

### setFlex

▸ **setFlex**(`orientation`, `alignItem?`, `spacing?`): `void`

Sets whether the widget uses flex layout.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `orientation` | [`Orientation`](../enums/Orientation.md) | Horizontal or vertical. |
| `alignItem?` | ``"center"`` \| ``"inherit"`` \| ``"stretch"`` \| ``"flex-start"`` \| ``"flex-end"`` \| ``"initial"`` \| ``"baseline"`` | @see(https://developer.mozilla.org/en-US/docs/Web/CSS/align-items) |
| `spacing?` | `number` | the spacing between widgets inside the layout. |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[setFlex](Edit.md#setflex)

#### Defined in

widget/widget.ts:329

___

### show

▸ **show**(): `void`

Shows the widget and its child widgets.
This function is equivalent to setting the visible property to true.

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[show](Edit.md#show)

#### Defined in

widget/widget.ts:70

___

### toggleAttr

▸ **toggleAttr**(`attr`, `on`): `void`

If param attr is true, adds the attribute, otherwise removes the attribute.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `attr` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[toggleAttr](Edit.md#toggleattr)

#### Defined in

widget/widget.ts:398

___

### toggleClass

▸ **toggleClass**(`className`, `on`): `void`

If param on is true, adds the class name, otherwise removes the class name.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `className` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[toggleClass](Edit.md#toggleclass)

#### Defined in

widget/widget.ts:367

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[unbind](Edit.md#unbind)

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[Edit](Edit.md).[unbind](Edit.md#unbind)

#### Defined in

abstract/eventwatcher.ts:38
