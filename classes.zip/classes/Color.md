[wui.basic](../README.md) / [Exports](../modules.md) / Color

# Class: Color

The Color class is a color based on RGBA.

## Table of contents

### Constructors

- [constructor](Color.md#constructor)

### Properties

- [m\_alpha](Color.md#m_alpha)
- [m\_blue](Color.md#m_blue)
- [m\_green](Color.md#m_green)
- [m\_red](Color.md#m_red)

### Accessors

- [alpha](Color.md#alpha)
- [blue](Color.md#blue)
- [green](Color.md#green)
- [hex](Color.md#hex)
- [red](Color.md#red)
- [rgba](Color.md#rgba)

### Methods

- [clone](Color.md#clone)
- [compare](Color.md#compare)
- [copy](Color.md#copy)
- [darker](Color.md#darker)
- [lighter](Color.md#lighter)
- [toHSB](Color.md#tohsb)
- [toRGB](Color.md#torgb)
- [toRGBA](Color.md#torgba)
- [fromHSB](Color.md#fromhsb)
- [fromHex](Color.md#fromhex)
- [fromRGB](Color.md#fromrgb)
- [fromRGBA](Color.md#fromrgba)
- [random](Color.md#random)

## Constructors

### constructor

• **new Color**(`red?`, `green?`, `blue?`, `alpha?`)

Constructs a color with the red, green, blue, and the alpha.

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `red` | `number` | `255` |
| `green` | `number` | `255` |
| `blue` | `number` | `255` |
| `alpha` | `number` | `1.0` |

#### Defined in

core/color.ts:105

## Properties

### m\_alpha

• `Private` **m\_alpha**: `number`

#### Defined in

core/color.ts:24

___

### m\_blue

• `Private` **m\_blue**: `number`

#### Defined in

core/color.ts:23

___

### m\_green

• `Private` **m\_green**: `number`

#### Defined in

core/color.ts:22

___

### m\_red

• `Private` **m\_red**: `number`

#### Defined in

core/color.ts:21

## Accessors

### alpha

• `get` **alpha**(): `number`

Returns the alpha color component of this color.

#### Returns

`number`

#### Defined in

core/color.ts:157

• `set` **alpha**(`alpha`): `void`

Sets the alpha color component of this color to alpha that is specified in the range 0-1.0.

#### Parameters

| Name | Type |
| :------ | :------ |
| `alpha` | `number` |

#### Returns

`void`

#### Defined in

core/color.ts:164

___

### blue

• `get` **blue**(): `number`

Returns the blue color component of this color.

#### Returns

`number`

#### Defined in

core/color.ts:143

• `set` **blue**(`blue`): `void`

Sets the blue color component of this color to blue that is specified in the range 0-255.

#### Parameters

| Name | Type |
| :------ | :------ |
| `blue` | `number` |

#### Returns

`void`

#### Defined in

core/color.ts:150

___

### green

• `get` **green**(): `number`

Returns the green color component of this color.

#### Returns

`number`

#### Defined in

core/color.ts:129

• `set` **green**(`green`): `void`

Sets the green color component of this color to green that is specified in the range 0-255.

#### Parameters

| Name | Type |
| :------ | :------ |
| `green` | `number` |

#### Returns

`void`

#### Defined in

core/color.ts:136

___

### hex

• `get` **hex**(): `string`

Returns the string of this color in the specified format("#RRGGBB").

#### Returns

`string`

#### Defined in

core/color.ts:182

___

### red

• `get` **red**(): `number`

Returns the red color component of this color.

#### Returns

`number`

#### Defined in

core/color.ts:115

• `set` **red**(`red`): `void`

Sets the red color component of this color to red that is specified in the range 0-255.

#### Parameters

| Name | Type |
| :------ | :------ |
| `red` | `number` |

#### Returns

`void`

#### Defined in

core/color.ts:122

___

### rgba

• `get` **rgba**(): `string`

Returns the rgba string("rgba(r, g, b, a)") of this color.

#### Returns

`string`

#### Defined in

core/color.ts:171

## Methods

### clone

▸ **clone**(): [`Color`](Color.md)

Returns a copy of this color.

#### Returns

[`Color`](Color.md)

#### Defined in

core/color.ts:268

___

### compare

▸ **compare**(`other`): `boolean`

Returns true if this color and other are equal; otherwise returns false.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Color`](Color.md) |

#### Returns

`boolean`

#### Defined in

core/color.ts:275

___

### copy

▸ **copy**(`other`): `void`

Copies the other color to this color.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Color`](Color.md) |

#### Returns

`void`

#### Defined in

core/color.ts:258

___

### darker

▸ **darker**(`dark`): [`Color`](Color.md)

Returns a darker color, but does not change this color.

#### Parameters

| Name | Type |
| :------ | :------ |
| `dark` | `number` |

#### Returns

[`Color`](Color.md)

#### Defined in

core/color.ts:249

___

### lighter

▸ **lighter**(`light`): [`Color`](Color.md)

Returns a lighter color, but does not change this color.

#### Parameters

| Name | Type |
| :------ | :------ |
| `light` | `number` |

#### Returns

[`Color`](Color.md)

#### Defined in

core/color.ts:240

___

### toHSB

▸ **toHSB**(): [`HSB`](../interfaces/HSB.md)

Returns the HSB value of this color.

#### Returns

[`HSB`](../interfaces/HSB.md)

#### Defined in

core/color.ts:206

___

### toRGB

▸ **toRGB**(): [`RGB`](../interfaces/RGB.md)

Returns the RGB value of this color.

#### Returns

[`RGB`](../interfaces/RGB.md)

#### Defined in

core/color.ts:192

___

### toRGBA

▸ **toRGBA**(): [`RGBA`](../interfaces/RGBA.md)

Returns the RGBA value of this color.

#### Returns

[`RGBA`](../interfaces/RGBA.md)

#### Defined in

core/color.ts:199

___

### fromHSB

▸ `Static` **fromHSB**(`hsb`): [`Color`](Color.md)

Returns a color constructed from the HSB, h (hue), s (saturation), b (brightness).
The value of s, v must all be in the range 0-100; the value of h must be in the range 0-360.

#### Parameters

| Name | Type |
| :------ | :------ |
| `hsb` | [`HSB`](../interfaces/HSB.md) |

#### Returns

[`Color`](Color.md)

#### Defined in

core/color.ts:60

___

### fromHex

▸ `Static` **fromHex**(`hex`): [`Color`](Color.md)

Returns a color parsed from hex string("#RRGGBB").

#### Parameters

| Name | Type |
| :------ | :------ |
| `hex` | `string` |

#### Returns

[`Color`](Color.md)

#### Defined in

core/color.ts:47

___

### fromRGB

▸ `Static` **fromRGB**(`rgb`): [`Color`](Color.md)

Returns a color constructed from the given rgb.

#### Parameters

| Name | Type |
| :------ | :------ |
| `rgb` | [`RGB`](../interfaces/RGB.md) |

#### Returns

[`Color`](Color.md)

#### Defined in

core/color.ts:29

___

### fromRGBA

▸ `Static` **fromRGBA**(`rgba`): [`Color`](Color.md)

Returns a color constructed from the given rgba.
The alpha component is in the range 0-1.0.

#### Parameters

| Name | Type |
| :------ | :------ |
| `rgba` | [`RGBA`](../interfaces/RGBA.md) |

#### Returns

[`Color`](Color.md)

#### Defined in

core/color.ts:38

___

### random

▸ `Static` **random**(): [`Color`](Color.md)

Returns a random color.

#### Returns

[`Color`](Color.md)

#### Defined in

core/color.ts:94
