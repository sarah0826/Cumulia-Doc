[wui.basic](../README.md) / [Exports](../modules.md) / ButtonGroup

# Class: ButtonGroup

The ButtonGroup is an exclusive button group, then only one button in the group can be checked at any time.

## Hierarchy

- [`EventWatcher`](EventWatcher.md)

  ↳ **`ButtonGroup`**

## Table of contents

### Constructors

- [constructor](ButtonGroup.md#constructor)

### Properties

- [m\_toggledButton](ButtonGroup.md#m_toggledbutton)

### Accessors

- [blocked](ButtonGroup.md#blocked)
- [checkedButton](ButtonGroup.md#checkedbutton)
- [toggledButton](ButtonGroup.md#toggledbutton)
- [sender](ButtonGroup.md#sender)

### Methods

- [bind](ButtonGroup.md#bind)
- [delegate](ButtonGroup.md#delegate)
- [emit](ButtonGroup.md#emit)
- [unbind](ButtonGroup.md#unbind)

## Constructors

### constructor

• **new ButtonGroup**()

Constructs an exclusive button group.

#### Overrides

[EventWatcher](EventWatcher.md).[constructor](EventWatcher.md#constructor)

#### Defined in

widget/togglebutton.ts:12

## Properties

### m\_toggledButton

• `Private` **m\_toggledButton**: [`ToggleButton`](ToggleButton.md)

#### Defined in

widget/togglebutton.ts:7

## Accessors

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Inherited from

EventWatcher.blocked

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Inherited from

EventWatcher.blocked

#### Defined in

abstract/eventwatcher.ts:85

___

### checkedButton

• `get` **checkedButton**(): [`ToggleButton`](ToggleButton.md)

This property is the same as [toggledButton](ButtonGroup.md#toggledbutton).

#### Returns

[`ToggleButton`](ToggleButton.md)

#### Defined in

widget/togglebutton.ts:44

• `set` **checkedButton**(`button`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `button` | [`ToggleButton`](ToggleButton.md) |

#### Returns

`void`

#### Defined in

widget/togglebutton.ts:48

___

### toggledButton

• `get` **toggledButton**(): [`ToggleButton`](ToggleButton.md)

Returns the button group's checked button, or undefined if no button is checked.

#### Returns

[`ToggleButton`](ToggleButton.md)

#### Defined in

widget/togglebutton.ts:19

• `set` **toggledButton**(`button`): `void`

Sets the button group's checked button to button.
If the button is checked and has been in the group, this function does nothing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `button` | [`ToggleButton`](ToggleButton.md) |

#### Returns

`void`

#### Defined in

widget/togglebutton.ts:27

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Inherited from

EventWatcher.sender

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[bind](EventWatcher.md#bind)

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[bind](EventWatcher.md#bind)

#### Defined in

abstract/eventwatcher.ts:29

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[delegate](EventWatcher.md#delegate)

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[delegate](EventWatcher.md#delegate)

#### Defined in

abstract/eventwatcher.ts:68

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Inherited from

[EventWatcher](EventWatcher.md).[emit](EventWatcher.md#emit)

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Inherited from

[EventWatcher](EventWatcher.md).[emit](EventWatcher.md#emit)

#### Defined in

abstract/eventwatcher.ts:49

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[unbind](EventWatcher.md#unbind)

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[unbind](EventWatcher.md#unbind)

#### Defined in

abstract/eventwatcher.ts:38
