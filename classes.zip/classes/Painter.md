[wui.basic](../README.md) / [Exports](../modules.md) / Painter

# Class: Painter

## Table of contents

### Constructors

- [constructor](Painter.md#constructor)

### Properties

- [m\_context](Painter.md#m_context)

### Methods

- [drawArc](Painter.md#drawarc)
- [drawCircle](Painter.md#drawcircle)
- [drawConicalGradient](Painter.md#drawconicalgradient)
- [drawEllipse](Painter.md#drawellipse)
- [drawEllipsePie](Painter.md#drawellipsepie)
- [drawImage](Painter.md#drawimage)
- [drawLine](Painter.md#drawline)
- [drawPie](Painter.md#drawpie)
- [drawPoint](Painter.md#drawpoint)
- [drawPolygon](Painter.md#drawpolygon)
- [drawRect](Painter.md#drawrect)
- [drawRoundedRect](Painter.md#drawroundedrect)
- [drawText](Painter.md#drawtext)
- [eraseRect](Painter.md#eraserect)

## Constructors

### constructor

• **new Painter**(`context`)

#### Parameters

| Name | Type |
| :------ | :------ |
| `context` | `CanvasRenderingContext2D` |

#### Defined in

painting/painter.ts:17

## Properties

### m\_context

• `Private` **m\_context**: `CanvasRenderingContext2D`

#### Defined in

painting/painter.ts:15

## Methods

### drawArc

▸ **drawArc**(`x`, `y`, `radius`, `startAngle`, `endAngle`, `anticlockwise?`, `mode?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `radius` | `number` | `undefined` |
| `startAngle` | `number` | `undefined` |
| `endAngle` | `number` | `undefined` |
| `anticlockwise` | `boolean` | `false` |
| `mode` | [`DrawMode`](../enums/DrawMode.md) | `DrawMode.Stroke` |

#### Returns

`void`

#### Defined in

painting/painter.ts:108

___

### drawCircle

▸ **drawCircle**(`x`, `y`, `radius`, `anticlockwise?`, `mode?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `radius` | `number` | `undefined` |
| `anticlockwise` | `boolean` | `false` |
| `mode` | [`DrawMode`](../enums/DrawMode.md) | `DrawMode.Stroke` |

#### Returns

`void`

#### Defined in

painting/painter.ts:127

___

### drawConicalGradient

▸ **drawConicalGradient**(`x`, `y`, `radius`, `startAngle`, `endAngle`, `gradientColor`, `lineWidth?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `radius` | `number` | `undefined` |
| `startAngle` | `number` | `undefined` |
| `endAngle` | `number` | `undefined` |
| `gradientColor` | [`GradientColor`](GradientColor.md) | `undefined` |
| `lineWidth` | `number` | `1` |

#### Returns

`void`

#### Defined in

painting/painter.ts:190

___

### drawEllipse

▸ **drawEllipse**(`x`, `y`, `radiusX`, `radiusY`, `rotation`, `anticlockwise?`, `mode?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `radiusX` | `number` | `undefined` |
| `radiusY` | `number` | `undefined` |
| `rotation` | `number` | `undefined` |
| `anticlockwise` | `boolean` | `false` |
| `mode` | [`DrawMode`](../enums/DrawMode.md) | `DrawMode.Stroke` |

#### Returns

`void`

#### Defined in

painting/painter.ts:146

___

### drawEllipsePie

▸ **drawEllipsePie**(`x`, `y`, `radiusX`, `radiusY`, `rotation`, `startAngle`, `endAngle`, `anticlockwise?`, `mode?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `radiusX` | `number` | `undefined` |
| `radiusY` | `number` | `undefined` |
| `rotation` | `number` | `undefined` |
| `startAngle` | `number` | `undefined` |
| `endAngle` | `number` | `undefined` |
| `anticlockwise` | `boolean` | `false` |
| `mode` | [`DrawMode`](../enums/DrawMode.md) | `DrawMode.Stroke` |

#### Returns

`void`

#### Defined in

painting/painter.ts:136

___

### drawImage

▸ **drawImage**(`image`, `offsetX`, `offsetY`, `width?`, `height?`, `canvasOffsetX?`, `canvasOffsetY?`, `canvasImageWidth?`, `canvasImageHeight?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `image` | [`Image`](Image.md) |
| `offsetX` | `number` |
| `offsetY` | `number` |
| `width?` | `number` |
| `height?` | `number` |
| `canvasOffsetX?` | `number` |
| `canvasOffsetY?` | `number` |
| `canvasImageWidth?` | `number` |
| `canvasImageHeight?` | `number` |

#### Returns

`void`

#### Defined in

painting/painter.ts:174

___

### drawLine

▸ **drawLine**(`x1`, `y1`, `x2`, `y2`, `lineStyle?`, `dashLength?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x1` | `number` | `undefined` |
| `y1` | `number` | `undefined` |
| `x2` | `number` | `undefined` |
| `y2` | `number` | `undefined` |
| `lineStyle` | [`LineStyle`](../enums/LineStyle.md) | `LineStyle.SolidLine` |
| `dashLength` | `number` | `5` |

#### Returns

`void`

#### Defined in

painting/painter.ts:29

___

### drawPie

▸ **drawPie**(`x`, `y`, `radius`, `startAngle`, `endAngle`, `anticlockwise?`, `mode?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `radius` | `number` | `undefined` |
| `startAngle` | `number` | `undefined` |
| `endAngle` | `number` | `undefined` |
| `anticlockwise` | `boolean` | `false` |
| `mode` | [`DrawMode`](../enums/DrawMode.md) | `DrawMode.Stroke` |

#### Returns

`void`

#### Defined in

painting/painter.ts:117

___

### drawPoint

▸ **drawPoint**(`x1`, `y1`, `width?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x1` | `number` | `undefined` |
| `y1` | `number` | `undefined` |
| `width` | `number` | `1` |

#### Returns

`void`

#### Defined in

painting/painter.ts:21

___

### drawPolygon

▸ **drawPolygon**(`points`, `mode?`, `pointCount?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `points` | `number`[] | `undefined` |
| `mode` | [`DrawMode`](../enums/DrawMode.md) | `DrawMode.Stroke` |
| `pointCount?` | `number` | `undefined` |

#### Returns

`void`

#### Defined in

painting/painter.ts:92

___

### drawRect

▸ **drawRect**(`x`, `y`, `width`, `height`, `mode?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `width` | `number` | `undefined` |
| `height` | `number` | `undefined` |
| `mode` | [`DrawMode`](../enums/DrawMode.md) | `DrawMode.Stroke` |

#### Returns

`void`

#### Defined in

painting/painter.ts:62

___

### drawRoundedRect

▸ **drawRoundedRect**(`x`, `y`, `width`, `height`, `radius`, `mode?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `width` | `number` | `undefined` |
| `height` | `number` | `undefined` |
| `radius` | `number` | `undefined` |
| `mode` | [`DrawMode`](../enums/DrawMode.md) | `DrawMode.Stroke` |

#### Returns

`void`

#### Defined in

painting/painter.ts:70

___

### drawText

▸ **drawText**(`x`, `y`, `text`, `mode?`, `maxWidth?`): `void`

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `undefined` |
| `y` | `number` | `undefined` |
| `text` | `string` | `undefined` |
| `mode` | [`DrawMode`](../enums/DrawMode.md) | `DrawMode.Stroke` |
| `maxWidth?` | `number` | `undefined` |

#### Returns

`void`

#### Defined in

painting/painter.ts:155

___

### eraseRect

▸ **eraseRect**(`x`, `y`, `width`, `height`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |
| `width` | `number` |
| `height` | `number` |

#### Returns

`void`

#### Defined in

painting/painter.ts:55
