[wui.basic](../README.md) / [Exports](../modules.md) / NumberValidator

# Class: NumberValidator

The class itself is abstract, it is a validator that ensures a string contains a valid number within a specified range.

## Hierarchy

- [`Validator`](Validator.md)

  ↳ **`NumberValidator`**

  ↳↳ [`IntegerValidator`](IntegerValidator.md)

  ↳↳ [`UnsignedIntegerValidator`](UnsignedIntegerValidator.md)

  ↳↳ [`FloatValidator`](FloatValidator.md)

  ↳↳ [`UnsignedFloatValidator`](UnsignedFloatValidator.md)

## Table of contents

### Constructors

- [constructor](NumberValidator.md#constructor)

### Properties

- [m\_maximum](NumberValidator.md#m_maximum)
- [m\_minimum](NumberValidator.md#m_minimum)

### Accessors

- [maximum](NumberValidator.md#maximum)
- [minimum](NumberValidator.md#minimum)
- [pattern](NumberValidator.md#pattern)

### Methods

- [fixup](NumberValidator.md#fixup)
- [toValue](NumberValidator.md#tovalue)
- [validate](NumberValidator.md#validate)

## Constructors

### constructor

• **new NumberValidator**(`minimum`, `maximum`, `pattern?`)

Constructs a number validator with a regular expression, that accepts number from minimum to maximum.

#### Parameters

| Name | Type |
| :------ | :------ |
| `minimum` | `number` |
| `maximum` | `number` |
| `pattern?` | `RegExp` |

#### Overrides

[Validator](Validator.md).[constructor](Validator.md#constructor)

#### Defined in

validator/number.ts:13

## Properties

### m\_maximum

• `Protected` **m\_maximum**: `number` = `Number.POSITIVE_INFINITY`

#### Defined in

validator/number.ts:8

___

### m\_minimum

• `Protected` **m\_minimum**: `number` = `Number.NEGATIVE_INFINITY`

#### Defined in

validator/number.ts:7

## Accessors

### maximum

• `get` **maximum**(): `number`

Returns the number validator's maximum value.

#### Returns

`number`

#### Defined in

validator/number.ts:72

• `set` **maximum**(`maximum`): `void`

Sets the number validator's maximum value to maximum.

#### Parameters

| Name | Type |
| :------ | :------ |
| `maximum` | `number` |

#### Returns

`void`

#### Defined in

validator/number.ts:79

___

### minimum

• `get` **minimum**(): `number`

Returns the number validator's minimum value.

#### Returns

`number`

#### Defined in

validator/number.ts:58

• `set` **minimum**(`minimum`): `void`

Sets the number validator's minimum value to minimum.

#### Parameters

| Name | Type |
| :------ | :------ |
| `minimum` | `number` |

#### Returns

`void`

#### Defined in

validator/number.ts:65

___

### pattern

• `get` **pattern**(): `RegExp`

Returns the regular expression of this validator.

#### Returns

`RegExp`

#### Inherited from

Validator.pattern

#### Defined in

validator/validator.ts:36

• `set` **pattern**(`pattern`): `void`

Sets the regular expression of this validator to pattern.

#### Parameters

| Name | Type |
| :------ | :------ |
| `pattern` | `RegExp` |

#### Returns

`void`

#### Inherited from

Validator.pattern

#### Defined in

validator/validator.ts:43

## Methods

### fixup

▸ **fixup**(`input`): `string`

This function attempts to change input to be valid according to this validator's rules.

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` |

#### Returns

`string`

#### Overrides

[Validator](Validator.md).[fixup](Validator.md#fixup)

#### Defined in

validator/number.ts:39

___

### toValue

▸ `Protected` `Abstract` **toValue**(`input`): `number`

Converts the string to a number.

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` |

#### Returns

`number`

#### Defined in

validator/number.ts:86

___

### validate

▸ **validate**(`input`): [`ValidatorState`](../enums/ValidatorState.md)

Returns [Invalid](../enums/ValidatorState.md#invalid) if input is invalid according to this validator's rules.
Returns [Intermediate](../enums/ValidatorState.md#intermediate) if input is likely that a little more editing will make the input acceptable.
Returns [Acceptable](../enums/ValidatorState.md#acceptable) if the input is valid.

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` |

#### Returns

[`ValidatorState`](../enums/ValidatorState.md)

#### Overrides

[Validator](Validator.md).[validate](Validator.md#validate)

#### Defined in

validator/number.ts:25
