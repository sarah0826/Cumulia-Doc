[wui.basic](../README.md) / [Exports](../modules.md) / BoxLayout

# Class: BoxLayout

The BoxLayout class is a stretched FlexLayout.

## Hierarchy

- [`FlexLayout`](FlexLayout.md)

  ↳ **`BoxLayout`**

  ↳↳ [`HBoxLayout`](HBoxLayout.md)

  ↳↳ [`VBoxLayout`](VBoxLayout.md)

  ↳↳ [`Splitter`](Splitter.md)

## Table of contents

### Constructors

- [constructor](BoxLayout.md#constructor)

### Properties

- [m\_children](BoxLayout.md#m_children)
- [m\_content](BoxLayout.md#m_content)
- [m\_dom](BoxLayout.md#m_dom)
- [m\_parent](BoxLayout.md#m_parent)

### Accessors

- [alignment](BoxLayout.md#alignment)
- [blocked](BoxLayout.md#blocked)
- [children](BoxLayout.md#children)
- [css](BoxLayout.md#css)
- [dom](BoxLayout.md#dom)
- [enabled](BoxLayout.md#enabled)
- [height](BoxLayout.md#height)
- [id](BoxLayout.md#id)
- [itemsStreched](BoxLayout.md#itemsstreched)
- [left](BoxLayout.md#left)
- [orientation](BoxLayout.md#orientation)
- [parent](BoxLayout.md#parent)
- [position](BoxLayout.md#position)
- [rect](BoxLayout.md#rect)
- [size](BoxLayout.md#size)
- [spacing](BoxLayout.md#spacing)
- [style](BoxLayout.md#style)
- [tooltip](BoxLayout.md#tooltip)
- [top](BoxLayout.md#top)
- [visible](BoxLayout.md#visible)
- [width](BoxLayout.md#width)
- [sender](BoxLayout.md#sender)

### Methods

- [add](BoxLayout.md#add)
- [addAttr](BoxLayout.md#addattr)
- [addClass](BoxLayout.md#addclass)
- [addSpacer](BoxLayout.md#addspacer)
- [align2Str](BoxLayout.md#align2str)
- [attach](BoxLayout.md#attach)
- [bind](BoxLayout.md#bind)
- [clear](BoxLayout.md#clear)
- [clearChildren](BoxLayout.md#clearchildren)
- [close](BoxLayout.md#close)
- [delegate](BoxLayout.md#delegate)
- [destroy](BoxLayout.md#destroy)
- [detach](BoxLayout.md#detach)
- [emit](BoxLayout.md#emit)
- [free](BoxLayout.md#free)
- [getAlignment](BoxLayout.md#getalignment)
- [getFixedHeight](BoxLayout.md#getfixedheight)
- [getFixedWidth](BoxLayout.md#getfixedwidth)
- [getStretch](BoxLayout.md#getstretch)
- [hasAttr](BoxLayout.md#hasattr)
- [hasClass](BoxLayout.md#hasclass)
- [hide](BoxLayout.md#hide)
- [insert](BoxLayout.md#insert)
- [insertChild](BoxLayout.md#insertchild)
- [raise](BoxLayout.md#raise)
- [remove](BoxLayout.md#remove)
- [removeAttr](BoxLayout.md#removeattr)
- [removeClass](BoxLayout.md#removeclass)
- [setAlignment](BoxLayout.md#setalignment)
- [setFixedHeight](BoxLayout.md#setfixedheight)
- [setFixedWidth](BoxLayout.md#setfixedwidth)
- [setFlex](BoxLayout.md#setflex)
- [setStretch](BoxLayout.md#setstretch)
- [show](BoxLayout.md#show)
- [str2Align](BoxLayout.md#str2align)
- [toggleAttr](BoxLayout.md#toggleattr)
- [toggleClass](BoxLayout.md#toggleclass)
- [unbind](BoxLayout.md#unbind)

## Constructors

### constructor

• **new BoxLayout**(`parent?`, `orientation?`)

Constructs a box layout with parent and orientation.

#### Parameters

| Name | Type | Default value | Description |
| :------ | :------ | :------ | :------ |
| `parent?` | [`Widget`](Widget.md) | `undefined` |  |
| `orientation` | [`Orientation`](../enums/Orientation.md) | `Orientation.Horizontal` | Horizontal or Vertical. |

#### Overrides

[FlexLayout](FlexLayout.md).[constructor](FlexLayout.md#constructor)

#### Defined in

layout/box.ts:13

## Properties

### m\_children

• `Protected` **m\_children**: [`Widget`](Widget.md)[] = `[]`

#### Inherited from

[FlexLayout](FlexLayout.md).[m_children](FlexLayout.md#m_children)

#### Defined in

widget/widget.ts:15

___

### m\_content

• `Protected` **m\_content**: [`Widget`](Widget.md)

#### Inherited from

[FlexLayout](FlexLayout.md).[m_content](FlexLayout.md#m_content)

#### Defined in

widget/widget.ts:14

___

### m\_dom

• `Protected` **m\_dom**: `HTMLElement`

#### Inherited from

[FlexLayout](FlexLayout.md).[m_dom](FlexLayout.md#m_dom)

#### Defined in

widget/widget.ts:12

___

### m\_parent

• `Protected` **m\_parent**: [`Widget`](Widget.md)

#### Inherited from

[FlexLayout](FlexLayout.md).[m_parent](FlexLayout.md#m_parent)

#### Defined in

widget/widget.ts:13

## Accessors

### alignment

• `get` **alignment**(): [`Alignment`](../enums/Alignment.md)

Returns the alignment along the main axis.

#### Returns

[`Alignment`](../enums/Alignment.md)

#### Inherited from

FlexLayout.alignment

#### Defined in

layout/flex.ts:61

• `set` **alignment**(`alignment`): `void`

Sets the alignment along the main axis to the given alignment.

#### Parameters

| Name | Type |
| :------ | :------ |
| `alignment` | [`Alignment`](../enums/Alignment.md) |

#### Returns

`void`

#### Inherited from

FlexLayout.alignment

#### Defined in

layout/flex.ts:54

___

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Inherited from

FlexLayout.blocked

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Inherited from

FlexLayout.blocked

#### Defined in

abstract/eventwatcher.ts:85

___

### children

• `get` **children**(): readonly [`Widget`](Widget.md)[]

Returns the list of children.

#### Returns

readonly [`Widget`](Widget.md)[]

#### Inherited from

FlexLayout.children

#### Defined in

widget/widget.ts:104

___

### css

• `set` **css**(`style`): `void`

Sets the style of this widget. See also [id](Widget.md#id) [addClass](Widget.md#addclass).

#### Parameters

| Name | Type |
| :------ | :------ |
| `style` | `Partial`<[`StyleSheets`](../interfaces/StyleSheets.md)\> |

#### Returns

`void`

#### Inherited from

FlexLayout.css

#### Defined in

widget/widget.ts:244

___

### dom

• `get` **dom**(): `HTMLElement`

Returns the dom of this widget.

#### Returns

`HTMLElement`

#### Inherited from

FlexLayout.dom

#### Defined in

widget/widget.ts:111

___

### enabled

• `get` **enabled**(): `boolean`

Returns whether this widget or its parent chain is enabled or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

FlexLayout.enabled

#### Defined in

widget/widget.ts:207

• `set` **enabled**(`enabled`): `void`

Sets whether this widget is enabled or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `enabled` | `boolean` |

#### Returns

`void`

#### Inherited from

FlexLayout.enabled

#### Defined in

widget/widget.ts:214

___

### height

• `get` **height**(): `number`

Returns the height of this widget.

#### Returns

`number`

#### Inherited from

FlexLayout.height

#### Defined in

widget/widget.ts:160

• `set` **height**(`height`): `void`

Sets the height of this widget to the given height.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `height` | `number` | The unit of height is px. |

#### Returns

`void`

#### Inherited from

FlexLayout.height

#### Defined in

widget/widget.ts:177

___

### id

• `get` **id**(): `string`

Returns the id of this widget.

#### Returns

`string`

#### Inherited from

FlexLayout.id

#### Defined in

widget/widget.ts:221

• `set` **id**(`id`): `void`

Set the id of this widget to the given id.
The id is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `id` | `string` |

#### Returns

`void`

#### Inherited from

FlexLayout.id

#### Defined in

widget/widget.ts:230

___

### itemsStreched

• `get` **itemsStreched**(): `boolean`

Returns whether all widgets inside this box layout is streched or not.

#### Returns

`boolean`

#### Defined in

layout/box.ts:140

• `set` **itemsStreched**(`streched`): `void`

Sets whether all widgets inside this box layout is streched or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `streched` | `boolean` |

#### Returns

`void`

#### Defined in

layout/box.ts:133

___

### left

• `get` **left**(): `number`

Returns the left coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

FlexLayout.left

#### Defined in

widget/widget.ts:280

• `set` **left**(`left`): `void`

Sets the left coordinate of this widget to the given left.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `left` | `number` | The unit of left is px. |

#### Returns

`void`

#### Inherited from

FlexLayout.left

#### Defined in

widget/widget.ts:273

___

### orientation

• `get` **orientation**(): [`Orientation`](../enums/Orientation.md)

Returns the orientation of this flex layout.

#### Returns

[`Orientation`](../enums/Orientation.md)

#### Inherited from

FlexLayout.orientation

#### Defined in

layout/flex.ts:24

• `set` **orientation**(`orientation`): `void`

Sets the orientation of this flex layout to the given orientation.

#### Parameters

| Name | Type |
| :------ | :------ |
| `orientation` | [`Orientation`](../enums/Orientation.md) |

#### Returns

`void`

#### Inherited from

FlexLayout.orientation

#### Defined in

layout/flex.ts:31

___

### parent

• `get` **parent**(): [`Widget`](Widget.md)

Returns the parent of this widget, or undefined if it does not have any parent widget.

#### Returns

[`Widget`](Widget.md)

#### Inherited from

FlexLayout.parent

#### Defined in

widget/widget.ts:85

• `set` **parent**(`parent`): `void`

Sets the parent of the widget to the given parent.
If the new parent widget is the old parent widget, this function does nothing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

FlexLayout.parent

#### Defined in

widget/widget.ts:93

___

### position

• `get` **position**(): [`Point`](Point.md)

Returns the position of this widget relative to its parent.

#### Returns

[`Point`](Point.md)

#### Inherited from

FlexLayout.position

#### Defined in

widget/widget.ts:311

• `set` **position**(`position`): `void`

Sets the position of this widget to the given position.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `position` | [`Point`](Point.md) | The unit of position is px. |

#### Returns

`void`

#### Inherited from

FlexLayout.position

#### Defined in

widget/widget.ts:303

___

### rect

• `get` **rect**(): [`Rect`](Rect.md)

Returns the rect of this widget relative to the desktop.

#### Returns

[`Rect`](Rect.md)

#### Inherited from

FlexLayout.rect

#### Defined in

widget/widget.ts:318

___

### size

• `get` **size**(): [`Size`](Size.md)

Returns the size of this widget.

#### Returns

[`Size`](Size.md)

#### Inherited from

FlexLayout.size

#### Defined in

widget/widget.ts:118

• `set` **size**(`size`): `void`

Sets the size of this widget to the given size.
If the size is Size(0, 0) will cause the widget to not appear on screen.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `size` | [`Size`](Size.md) | The unit of size is px. |

#### Returns

`void`

#### Inherited from

FlexLayout.size

#### Defined in

widget/widget.ts:128

___

### spacing

• `get` **spacing**(): `number`

Returns the spacing between widgets inside this flex layout.

#### Returns

`number`

#### Inherited from

FlexLayout.spacing

#### Defined in

layout/flex.ts:47

• `set` **spacing**(`spacing`): `void`

Set the spacing to the given pacing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `spacing` | `number` |

#### Returns

`void`

#### Inherited from

FlexLayout.spacing

#### Defined in

layout/flex.ts:39

___

### style

• `get` **style**(): `CSSStyleDeclaration`

Returns the style of this widget.

#### Returns

`CSSStyleDeclaration`

#### Inherited from

FlexLayout.style

#### Defined in

widget/widget.ts:237

___

### tooltip

• `get` **tooltip**(): `string`

Returns the tooltip of this widget.
By default, the value of this property is an empty string.

#### Returns

`string`

#### Inherited from

FlexLayout.tooltip

#### Defined in

widget/widget.ts:254

• `set` **tooltip**(`tooltip`): `void`

Sets the tooltip of this widget to the given tooltip.

#### Parameters

| Name | Type |
| :------ | :------ |
| `tooltip` | `string` |

#### Returns

`void`

#### Inherited from

FlexLayout.tooltip

#### Defined in

widget/widget.ts:261

___

### top

• `get` **top**(): `number`

Returns the top coordinate of this widget relative to its parent.

#### Returns

`number`

#### Inherited from

FlexLayout.top

#### Defined in

widget/widget.ts:295

• `set` **top**(`top`): `void`

Sets the top coordinate of this widget to the given top.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `top` | `number` | The unit of top is px. |

#### Returns

`void`

#### Inherited from

FlexLayout.top

#### Defined in

widget/widget.ts:288

___

### visible

• `get` **visible**(): `boolean`

Returns whether this widget or its parent chain is visible or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Inherited from

FlexLayout.visible

#### Defined in

widget/widget.ts:185

• `set` **visible**(`visible`): `void`

Sets whether this widget is visible or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `visible` | `boolean` |

#### Returns

`void`

#### Inherited from

FlexLayout.visible

#### Defined in

widget/widget.ts:192

___

### width

• `get` **width**(): `number`

Returns the width of this widget.

#### Returns

`number`

#### Inherited from

FlexLayout.width

#### Defined in

widget/widget.ts:136

• `set` **width**(`width`): `void`

Sets the width of this widget to the given width.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `width` | `number` | The unit of width is px. |

#### Returns

`void`

#### Inherited from

FlexLayout.width

#### Defined in

widget/widget.ts:153

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Inherited from

FlexLayout.sender

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### add

▸ **add**(`widget`, `stretch?`, `alignment?`): `void`

Adds widget to the end of this box layout, with a stretch factor and alignment.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `widget` | [`Widget`](Widget.md) |  |
| `stretch?` | `number` | Widgets with higher stretch factors will grow more. |
| `alignment?` | [`Alignment`](../enums/Alignment.md) | the alignment of widget inside this box layout. |

#### Returns

`void`

#### Defined in

layout/box.ts:26

___

### addAttr

▸ **addAttr**(`attr`): `void`

Adds the attribute of this widget.
The attribute is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[addAttr](FlexLayout.md#addattr)

#### Defined in

widget/widget.ts:375

___

### addClass

▸ **addClass**(`className`): `void`

Adds the class name of this widget.
The class name is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[addClass](FlexLayout.md#addclass)

#### Defined in

widget/widget.ts:344

___

### addSpacer

▸ **addSpacer**(): `void`

Adds a new spacer to the end of this box layout.

#### Returns

`void`

#### Defined in

layout/box.ts:52

___

### align2Str

▸ `Protected` **align2Str**(`align`): `string`

#### Parameters

| Name | Type |
| :------ | :------ |
| `align` | [`Alignment`](../enums/Alignment.md) |

#### Returns

`string`

#### Inherited from

[FlexLayout](FlexLayout.md).[align2Str](FlexLayout.md#align2str)

#### Defined in

layout/flex.ts:66

___

### attach

▸ `Protected` **attach**(): `void`

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[attach](FlexLayout.md#attach)

#### Defined in

widget/widget.ts:461

___

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[bind](FlexLayout.md#bind)

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[bind](FlexLayout.md#bind)

#### Defined in

abstract/eventwatcher.ts:29

___

### clear

▸ **clear**(): `void`

Clears all child widgets.

#### Returns

`void`

#### Defined in

layout/box.ts:66

___

### clearChildren

▸ **clearChildren**(): `void`

Clears all widgets in the list of children.

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[clearChildren](FlexLayout.md#clearchildren)

#### Defined in

widget/widget.ts:450

___

### close

▸ **close**(): `void`

Closes this widget.
This function is equivalent to setting this widget's parent to undefined.

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[close](FlexLayout.md#close)

#### Defined in

widget/widget.ts:62

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[delegate](FlexLayout.md#delegate)

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[delegate](FlexLayout.md#delegate)

#### Defined in

abstract/eventwatcher.ts:68

___

### destroy

▸ **destroy**(): `void`

Destroys the widget, All the widget's children are destroyed first.

The widget is destroyed when it’s parent is destroyed. When the widget is destroyed, make sure to release all resources, such as timers, etc.
Releases the resources in function free(), The system will call this function automatically when the parent widget or itself is destroyed.
See also [free](Widget.md#free).

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[destroy](FlexLayout.md#destroy)

#### Defined in

widget/widget.ts:40

___

### detach

▸ `Protected` **detach**(): `void`

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[detach](FlexLayout.md#detach)

#### Defined in

widget/widget.ts:471

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Inherited from

[FlexLayout](FlexLayout.md).[emit](FlexLayout.md#emit)

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Inherited from

[FlexLayout](FlexLayout.md).[emit](FlexLayout.md#emit)

#### Defined in

abstract/eventwatcher.ts:49

___

### free

▸ `Protected` **free**(): `void`

Frees the resources.See also [destroy](Widget.md#destroy).

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[free](FlexLayout.md#free)

#### Defined in

widget/widget.ts:55

___

### getAlignment

▸ **getAlignment**(`widget`): [`Alignment`](../enums/Alignment.md)

Returns the alignment of widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `widget` | [`Widget`](Widget.md) |

#### Returns

[`Alignment`](../enums/Alignment.md)

#### Defined in

layout/box.ts:95

___

### getFixedHeight

▸ **getFixedHeight**(`widget`): `number`

Returns the fixed height of widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`number`

#### Defined in

layout/box.ts:126

___

### getFixedWidth

▸ **getFixedWidth**(`widget`): `number`

Returns the fixed width of widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`number`

#### Defined in

layout/box.ts:111

___

### getStretch

▸ **getStretch**(`widget`): `number`

Returns the stretch factor of widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`number`

#### Defined in

layout/box.ts:81

___

### hasAttr

▸ **hasAttr**(`attr`): `boolean`

Returns whether this widget contains the attribute.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`boolean`

#### Inherited from

[FlexLayout](FlexLayout.md).[hasAttr](FlexLayout.md#hasattr)

#### Defined in

widget/widget.ts:389

___

### hasClass

▸ **hasClass**(`className`): `boolean`

Returns whether this widget contains the class name.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`boolean`

#### Inherited from

[FlexLayout](FlexLayout.md).[hasClass](FlexLayout.md#hasclass)

#### Defined in

widget/widget.ts:358

___

### hide

▸ **hide**(): `void`

Hides the widget and its child widgets.
This function is equivalent to setting the visible property to false.

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[hide](FlexLayout.md#hide)

#### Defined in

widget/widget.ts:78

___

### insert

▸ **insert**(`index`, `widget`, `stretch?`, `alignment?`): `void`

Inserts widget at position index, with a stretch factor and alignment.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `widget` | [`Widget`](Widget.md) |
| `stretch?` | `number` |
| `alignment?` | [`Alignment`](../enums/Alignment.md) |

#### Returns

`void`

#### Defined in

layout/box.ts:39

___

### insertChild

▸ **insertChild**(`index`, `widget`): `void`

Inserts the child widget at index in the list of children.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[insertChild](FlexLayout.md#insertchild)

#### Defined in

widget/widget.ts:431

___

### raise

▸ **raise**(): `boolean`

Raises this widget to the top of the parent widget's children.
The display order of this widget is determined by the order in which they appear in the parent widget's children.

#### Returns

`boolean`

#### Inherited from

[FlexLayout](FlexLayout.md).[raise](FlexLayout.md#raise)

#### Defined in

widget/widget.ts:406

___

### remove

▸ **remove**(`widget`): `void`

Removes the widget from this box layout.

#### Parameters

| Name | Type |
| :------ | :------ |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Defined in

layout/box.ts:59

___

### removeAttr

▸ **removeAttr**(`attr`): `void`

Removes the attribute of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[removeAttr](FlexLayout.md#removeattr)

#### Defined in

widget/widget.ts:382

___

### removeClass

▸ **removeClass**(`className`): `void`

Removes the class name of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[removeClass](FlexLayout.md#removeclass)

#### Defined in

widget/widget.ts:351

___

### setAlignment

▸ **setAlignment**(`widget`, `alignment`): `void`

Sets the alignment of widget to alignment.

#### Parameters

| Name | Type |
| :------ | :------ |
| `widget` | [`Widget`](Widget.md) |
| `alignment` | [`Alignment`](../enums/Alignment.md) |

#### Returns

`void`

#### Defined in

layout/box.ts:88

___

### setFixedHeight

▸ **setFixedHeight**(`widget`, `height`): `void`

Sets the fixed height of widget to height.

#### Parameters

| Name | Type |
| :------ | :------ |
| `widget` | [`Widget`](Widget.md) |
| `height` | `number` |

#### Returns

`void`

#### Defined in

layout/box.ts:118

___

### setFixedWidth

▸ **setFixedWidth**(`widget`, `width`): `void`

Sets the fixed width of widget to width.

#### Parameters

| Name | Type |
| :------ | :------ |
| `widget` | [`Widget`](Widget.md) |
| `width` | `number` |

#### Returns

`void`

#### Defined in

layout/box.ts:103

___

### setFlex

▸ **setFlex**(`orientation`, `alignItem?`, `spacing?`): `void`

Sets whether the widget uses flex layout.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `orientation` | [`Orientation`](../enums/Orientation.md) | Horizontal or vertical. |
| `alignItem?` | ``"center"`` \| ``"inherit"`` \| ``"stretch"`` \| ``"flex-start"`` \| ``"flex-end"`` \| ``"initial"`` \| ``"baseline"`` | @see(https://developer.mozilla.org/en-US/docs/Web/CSS/align-items) |
| `spacing?` | `number` | the spacing between widgets inside the layout. |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[setFlex](FlexLayout.md#setflex)

#### Defined in

widget/widget.ts:329

___

### setStretch

▸ **setStretch**(`widget`, `stretch`): `void`

Sets the stretch factor of widget to stretch.

#### Parameters

| Name | Type |
| :------ | :------ |
| `widget` | [`Widget`](Widget.md) |
| `stretch` | `number` |

#### Returns

`void`

#### Defined in

layout/box.ts:73

___

### show

▸ **show**(): `void`

Shows the widget and its child widgets.
This function is equivalent to setting the visible property to true.

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[show](FlexLayout.md#show)

#### Defined in

widget/widget.ts:70

___

### str2Align

▸ `Protected` **str2Align**(`str`): [`Alignment`](../enums/Alignment.md)

#### Parameters

| Name | Type |
| :------ | :------ |
| `str` | `string` |

#### Returns

[`Alignment`](../enums/Alignment.md)

#### Inherited from

[FlexLayout](FlexLayout.md).[str2Align](FlexLayout.md#str2align)

#### Defined in

layout/flex.ts:79

___

### toggleAttr

▸ **toggleAttr**(`attr`, `on`): `void`

If param attr is true, adds the attribute, otherwise removes the attribute.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `attr` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[toggleAttr](FlexLayout.md#toggleattr)

#### Defined in

widget/widget.ts:398

___

### toggleClass

▸ **toggleClass**(`className`, `on`): `void`

If param on is true, adds the class name, otherwise removes the class name.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `className` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[toggleClass](FlexLayout.md#toggleclass)

#### Defined in

widget/widget.ts:367

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[unbind](FlexLayout.md#unbind)

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[FlexLayout](FlexLayout.md).[unbind](FlexLayout.md#unbind)

#### Defined in

abstract/eventwatcher.ts:38
