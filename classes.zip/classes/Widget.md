[wui.basic](../README.md) / [Exports](../modules.md) / Widget

# Class: Widget

The Widget is the base class of all user interface objects.The widget is the atom of the user interface: it receives mouse, keyboard and other events from the window system.

When a widget is used as a container to group a number of child widgets, it is known as a composite widget.
The widget is offline if this's parent or ancestor is undefined.

The Widget is the encapsulation of the dom(By default, it is a div tag), and provides elegant api interfaces.

## Hierarchy

- [`EventWatcher`](EventWatcher.md)

  ↳ **`Widget`**

  ↳↳ [`Desktop`](Desktop.md)

  ↳↳ [`Panel`](Panel.md)

  ↳↳ [`Icon`](Icon.md)

  ↳↳ [`Image`](Image.md)

  ↳↳ [`Canvas`](Canvas.md)

  ↳↳ [`Spacer`](Spacer.md)

  ↳↳ [`Separator`](Separator.md)

  ↳↳ [`RubberBand`](RubberBand.md)

  ↳↳ [`Background`](Background.md)

  ↳↳ [`Splash`](Splash.md)

  ↳↳ [`Text`](Text.md)

  ↳↳ [`Label`](Label.md)

  ↳↳ [`Layout`](Layout.md)

  ↳↳ [`Popup`](Popup.md)

  ↳↳ [`Button`](Button.md)

  ↳↳ [`Edit`](Edit.md)

  ↳↳ [`ScrollArea`](ScrollArea.md)

  ↳↳ [`TextEdit`](TextEdit.md)

  ↳↳ [`TabBar`](TabBar.md)

  ↳↳ [`Gripper`](Gripper.md)

  ↳↳ [`TabWidget`](TabWidget.md)

## Table of contents

### Constructors

- [constructor](Widget.md#constructor)

### Properties

- [m\_children](Widget.md#m_children)
- [m\_content](Widget.md#m_content)
- [m\_dom](Widget.md#m_dom)
- [m\_parent](Widget.md#m_parent)
- [m\_tooltip](Widget.md#m_tooltip)

### Accessors

- [blocked](Widget.md#blocked)
- [children](Widget.md#children)
- [css](Widget.md#css)
- [dom](Widget.md#dom)
- [enabled](Widget.md#enabled)
- [height](Widget.md#height)
- [id](Widget.md#id)
- [left](Widget.md#left)
- [parent](Widget.md#parent)
- [position](Widget.md#position)
- [rect](Widget.md#rect)
- [size](Widget.md#size)
- [style](Widget.md#style)
- [tooltip](Widget.md#tooltip)
- [top](Widget.md#top)
- [visible](Widget.md#visible)
- [width](Widget.md#width)
- [sender](Widget.md#sender)

### Methods

- [addAttr](Widget.md#addattr)
- [addClass](Widget.md#addclass)
- [attach](Widget.md#attach)
- [bind](Widget.md#bind)
- [clearChildren](Widget.md#clearchildren)
- [close](Widget.md#close)
- [delegate](Widget.md#delegate)
- [destroy](Widget.md#destroy)
- [detach](Widget.md#detach)
- [emit](Widget.md#emit)
- [free](Widget.md#free)
- [hasAttr](Widget.md#hasattr)
- [hasClass](Widget.md#hasclass)
- [hide](Widget.md#hide)
- [insertChild](Widget.md#insertchild)
- [raise](Widget.md#raise)
- [removeAttr](Widget.md#removeattr)
- [removeClass](Widget.md#removeclass)
- [setFlex](Widget.md#setflex)
- [show](Widget.md#show)
- [toggleAttr](Widget.md#toggleattr)
- [toggleClass](Widget.md#toggleclass)
- [unbind](Widget.md#unbind)

## Constructors

### constructor

• **new Widget**(`parent?`, `tagName?`)

Constructs a widget which is a child of parent.

#### Parameters

| Name | Type | Default value | Description |
| :------ | :------ | :------ | :------ |
| `parent?` | [`Widget`](Widget.md) | `undefined` | If parent is another widget, this widget becomes a child widget inside parent. |
| `tagName` | keyof `HTMLElementTagNameMap` | `'div'` | The dom tag of this widget. |

#### Overrides

[EventWatcher](EventWatcher.md).[constructor](EventWatcher.md#constructor)

#### Defined in

widget/widget.ts:23

## Properties

### m\_children

• `Protected` **m\_children**: [`Widget`](Widget.md)[] = `[]`

#### Defined in

widget/widget.ts:15

___

### m\_content

• `Protected` **m\_content**: [`Widget`](Widget.md)

#### Defined in

widget/widget.ts:14

___

### m\_dom

• `Protected` **m\_dom**: `HTMLElement`

#### Defined in

widget/widget.ts:12

___

### m\_parent

• `Protected` **m\_parent**: [`Widget`](Widget.md)

#### Defined in

widget/widget.ts:13

___

### m\_tooltip

• `Private` **m\_tooltip**: `string`

#### Defined in

widget/widget.ts:16

## Accessors

### blocked

• `get` **blocked**(): `boolean`

Returns true if events are blocked; otherwise returns false.

#### Returns

`boolean`

#### Inherited from

EventWatcher.blocked

#### Defined in

abstract/eventwatcher.ts:78

• `set` **blocked**(`blocked`): `void`

If blocked is true, events emitted by this event watcher are blocked (i.e., emitting an event will not call any callback functions binded to it).

#### Parameters

| Name | Type |
| :------ | :------ |
| `blocked` | `boolean` |

#### Returns

`void`

#### Inherited from

EventWatcher.blocked

#### Defined in

abstract/eventwatcher.ts:85

___

### children

• `get` **children**(): readonly [`Widget`](Widget.md)[]

Returns the list of children.

#### Returns

readonly [`Widget`](Widget.md)[]

#### Defined in

widget/widget.ts:104

___

### css

• `set` **css**(`style`): `void`

Sets the style of this widget. See also [id](Widget.md#id) [addClass](Widget.md#addclass).

#### Parameters

| Name | Type |
| :------ | :------ |
| `style` | `Partial`<[`StyleSheets`](../interfaces/StyleSheets.md)\> |

#### Returns

`void`

#### Defined in

widget/widget.ts:244

___

### dom

• `get` **dom**(): `HTMLElement`

Returns the dom of this widget.

#### Returns

`HTMLElement`

#### Defined in

widget/widget.ts:111

___

### enabled

• `get` **enabled**(): `boolean`

Returns whether this widget or its parent chain is enabled or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Defined in

widget/widget.ts:207

• `set` **enabled**(`enabled`): `void`

Sets whether this widget is enabled or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `enabled` | `boolean` |

#### Returns

`void`

#### Defined in

widget/widget.ts:214

___

### height

• `get` **height**(): `number`

Returns the height of this widget.

#### Returns

`number`

#### Defined in

widget/widget.ts:160

• `set` **height**(`height`): `void`

Sets the height of this widget to the given height.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `height` | `number` | The unit of height is px. |

#### Returns

`void`

#### Defined in

widget/widget.ts:177

___

### id

• `get` **id**(): `string`

Returns the id of this widget.

#### Returns

`string`

#### Defined in

widget/widget.ts:221

• `set` **id**(`id`): `void`

Set the id of this widget to the given id.
The id is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `id` | `string` |

#### Returns

`void`

#### Defined in

widget/widget.ts:230

___

### left

• `get` **left**(): `number`

Returns the left coordinate of this widget relative to its parent.

#### Returns

`number`

#### Defined in

widget/widget.ts:280

• `set` **left**(`left`): `void`

Sets the left coordinate of this widget to the given left.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `left` | `number` | The unit of left is px. |

#### Returns

`void`

#### Defined in

widget/widget.ts:273

___

### parent

• `get` **parent**(): [`Widget`](Widget.md)

Returns the parent of this widget, or undefined if it does not have any parent widget.

#### Returns

[`Widget`](Widget.md)

#### Defined in

widget/widget.ts:85

• `set` **parent**(`parent`): `void`

Sets the parent of the widget to the given parent.
If the new parent widget is the old parent widget, this function does nothing.

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Defined in

widget/widget.ts:93

___

### position

• `get` **position**(): [`Point`](Point.md)

Returns the position of this widget relative to its parent.

#### Returns

[`Point`](Point.md)

#### Defined in

widget/widget.ts:311

• `set` **position**(`position`): `void`

Sets the position of this widget to the given position.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `position` | [`Point`](Point.md) | The unit of position is px. |

#### Returns

`void`

#### Defined in

widget/widget.ts:303

___

### rect

• `get` **rect**(): [`Rect`](Rect.md)

Returns the rect of this widget relative to the desktop.

#### Returns

[`Rect`](Rect.md)

#### Defined in

widget/widget.ts:318

___

### size

• `get` **size**(): [`Size`](Size.md)

Returns the size of this widget.

#### Returns

[`Size`](Size.md)

#### Defined in

widget/widget.ts:118

• `set` **size**(`size`): `void`

Sets the size of this widget to the given size.
If the size is Size(0, 0) will cause the widget to not appear on screen.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `size` | [`Size`](Size.md) | The unit of size is px. |

#### Returns

`void`

#### Defined in

widget/widget.ts:128

___

### style

• `get` **style**(): `CSSStyleDeclaration`

Returns the style of this widget.

#### Returns

`CSSStyleDeclaration`

#### Defined in

widget/widget.ts:237

___

### tooltip

• `get` **tooltip**(): `string`

Returns the tooltip of this widget.
By default, the value of this property is an empty string.

#### Returns

`string`

#### Defined in

widget/widget.ts:254

• `set` **tooltip**(`tooltip`): `void`

Sets the tooltip of this widget to the given tooltip.

#### Parameters

| Name | Type |
| :------ | :------ |
| `tooltip` | `string` |

#### Returns

`void`

#### Defined in

widget/widget.ts:261

___

### top

• `get` **top**(): `number`

Returns the top coordinate of this widget relative to its parent.

#### Returns

`number`

#### Defined in

widget/widget.ts:295

• `set` **top**(`top`): `void`

Sets the top coordinate of this widget to the given top.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `top` | `number` | The unit of top is px. |

#### Returns

`void`

#### Defined in

widget/widget.ts:288

___

### visible

• `get` **visible**(): `boolean`

Returns whether this widget or its parent chain is visible or not.
By default, the value of this property is true.

#### Returns

`boolean`

#### Defined in

widget/widget.ts:185

• `set` **visible**(`visible`): `void`

Sets whether this widget is visible or not.

#### Parameters

| Name | Type |
| :------ | :------ |
| `visible` | `boolean` |

#### Returns

`void`

#### Defined in

widget/widget.ts:192

___

### width

• `get` **width**(): `number`

Returns the width of this widget.

#### Returns

`number`

#### Defined in

widget/widget.ts:136

• `set` **width**(`width`): `void`

Sets the width of this widget to the given width.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `width` | `number` | The unit of width is px. |

#### Returns

`void`

#### Defined in

widget/widget.ts:153

___

### sender

• `Static` `get` **sender**(): [`EventWatcher`](EventWatcher.md)

Returns the object that sent the event.

#### Returns

[`EventWatcher`](EventWatcher.md)

#### Inherited from

EventWatcher.sender

#### Defined in

abstract/eventwatcher.ts:21

## Methods

### addAttr

▸ **addAttr**(`attr`): `void`

Adds the attribute of this widget.
The attribute is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Defined in

widget/widget.ts:375

___

### addClass

▸ **addClass**(`className`): `void`

Adds the class name of this widget.
The class name is used to set the style. See also [css](Widget.md#css)

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Defined in

widget/widget.ts:344

___

### attach

▸ `Protected` **attach**(): `void`

#### Returns

`void`

#### Defined in

widget/widget.ts:461

___

### bind

▸ **bind**<`K`\>(`name`, `callback`): `void`

Adds a callback function that's going to be called when the event is emitted.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `callback` | (...`data`: [`EventMap`](../interfaces/EventMap.md)[`K`]) => `void` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[bind](EventWatcher.md#bind)

#### Defined in

abstract/eventwatcher.ts:28

▸ **bind**(`name`, `callback`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `callback` | (...`data`: `any`[]) => `void` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[bind](EventWatcher.md#bind)

#### Defined in

abstract/eventwatcher.ts:29

___

### clearChildren

▸ **clearChildren**(): `void`

Clears all widgets in the list of children.

#### Returns

`void`

#### Defined in

widget/widget.ts:450

___

### close

▸ **close**(): `void`

Closes this widget.
This function is equivalent to setting this widget's parent to undefined.

#### Returns

`void`

#### Defined in

widget/widget.ts:62

___

### delegate

▸ **delegate**<`K`\>(`watcher`, `name`): `void`

Delegates this event watcher to handle the given watcher's event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[delegate](EventWatcher.md#delegate)

#### Defined in

abstract/eventwatcher.ts:67

▸ **delegate**(`watcher`, `name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `watcher` | [`EventWatcher`](EventWatcher.md) |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[delegate](EventWatcher.md#delegate)

#### Defined in

abstract/eventwatcher.ts:68

___

### destroy

▸ **destroy**(): `void`

Destroys the widget, All the widget's children are destroyed first.

The widget is destroyed when it’s parent is destroyed. When the widget is destroyed, make sure to release all resources, such as timers, etc.
Releases the resources in function free(), The system will call this function automatically when the parent widget or itself is destroyed.
See also [free](Widget.md#free).

#### Returns

`void`

#### Defined in

widget/widget.ts:40

___

### detach

▸ `Protected` **detach**(): `void`

#### Returns

`void`

#### Defined in

widget/widget.ts:471

___

### emit

▸ **emit**<`K`\>(`name`, `...data`): `boolean`

Emits an arbitrary set of arguments to the callback function which is binded to the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |
| `...data` | [`EventMap`](../interfaces/EventMap.md)[`K`] |

#### Returns

`boolean`

#### Inherited from

[EventWatcher](EventWatcher.md).[emit](EventWatcher.md#emit)

#### Defined in

abstract/eventwatcher.ts:48

▸ **emit**(`name`, `...data`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |
| `...data` | `any`[] |

#### Returns

`boolean`

#### Inherited from

[EventWatcher](EventWatcher.md).[emit](EventWatcher.md#emit)

#### Defined in

abstract/eventwatcher.ts:49

___

### free

▸ `Protected` **free**(): `void`

Frees the resources.See also [destroy](Widget.md#destroy).

#### Returns

`void`

#### Defined in

widget/widget.ts:55

___

### hasAttr

▸ **hasAttr**(`attr`): `boolean`

Returns whether this widget contains the attribute.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`boolean`

#### Defined in

widget/widget.ts:389

___

### hasClass

▸ **hasClass**(`className`): `boolean`

Returns whether this widget contains the class name.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`boolean`

#### Defined in

widget/widget.ts:358

___

### hide

▸ **hide**(): `void`

Hides the widget and its child widgets.
This function is equivalent to setting the visible property to false.

#### Returns

`void`

#### Defined in

widget/widget.ts:78

___

### insertChild

▸ **insertChild**(`index`, `widget`): `void`

Inserts the child widget at index in the list of children.

#### Parameters

| Name | Type |
| :------ | :------ |
| `index` | `number` |
| `widget` | [`Widget`](Widget.md) |

#### Returns

`void`

#### Defined in

widget/widget.ts:431

___

### raise

▸ **raise**(): `boolean`

Raises this widget to the top of the parent widget's children.
The display order of this widget is determined by the order in which they appear in the parent widget's children.

#### Returns

`boolean`

#### Defined in

widget/widget.ts:406

___

### removeAttr

▸ **removeAttr**(`attr`): `void`

Removes the attribute of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `string` |

#### Returns

`void`

#### Defined in

widget/widget.ts:382

___

### removeClass

▸ **removeClass**(`className`): `void`

Removes the class name of this widget.

#### Parameters

| Name | Type |
| :------ | :------ |
| `className` | `string` |

#### Returns

`void`

#### Defined in

widget/widget.ts:351

___

### setFlex

▸ **setFlex**(`orientation`, `alignItem?`, `spacing?`): `void`

Sets whether the widget uses flex layout.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `orientation` | [`Orientation`](../enums/Orientation.md) | Horizontal or vertical. |
| `alignItem?` | ``"center"`` \| ``"inherit"`` \| ``"stretch"`` \| ``"flex-start"`` \| ``"flex-end"`` \| ``"initial"`` \| ``"baseline"`` | @see(https://developer.mozilla.org/en-US/docs/Web/CSS/align-items) |
| `spacing?` | `number` | the spacing between widgets inside the layout. |

#### Returns

`void`

#### Defined in

widget/widget.ts:329

___

### show

▸ **show**(): `void`

Shows the widget and its child widgets.
This function is equivalent to setting the visible property to true.

#### Returns

`void`

#### Defined in

widget/widget.ts:70

___

### toggleAttr

▸ **toggleAttr**(`attr`, `on`): `void`

If param attr is true, adds the attribute, otherwise removes the attribute.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `attr` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Defined in

widget/widget.ts:398

___

### toggleClass

▸ **toggleClass**(`className`, `on`): `void`

If param on is true, adds the class name, otherwise removes the class name.

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `className` | `string` |  |
| `on` | `boolean` | true or false |

#### Returns

`void`

#### Defined in

widget/widget.ts:367

___

### unbind

▸ **unbind**<`K`\>(`name`): `void`

Removes the specified watcher for the event named name.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof [`EventMap`](../interfaces/EventMap.md) |

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `K` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[unbind](EventWatcher.md#unbind)

#### Defined in

abstract/eventwatcher.ts:37

▸ **unbind**(`name`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `name` | `string` |

#### Returns

`void`

#### Inherited from

[EventWatcher](EventWatcher.md).[unbind](EventWatcher.md#unbind)

#### Defined in

abstract/eventwatcher.ts:38
