[wui.basic](../README.md) / [Exports](../modules.md) / Utilities

# Class: Utilities

## Table of contents

### Constructors

- [constructor](Utilities.md#constructor)

### Methods

- [align2Str](Utilities.md#align2str)
- [empty](Utilities.md#empty)
- [getChildFromElement](Utilities.md#getchildfromelement)
- [getKey](Utilities.md#getkey)
- [getModifier](Utilities.md#getmodifier)
- [getMouseButton](Utilities.md#getmousebutton)
- [index](Utilities.md#index)
- [insertAfter](Utilities.md#insertafter)
- [str2Align](Utilities.md#str2align)

## Constructors

### constructor

• **new Utilities**()

## Methods

### align2Str

▸ `Static` **align2Str**(`align`): `string`

Converts the enum align to a string.

#### Parameters

| Name | Type |
| :------ | :------ |
| `align` | [`Alignment`](../enums/Alignment.md) |

#### Returns

`string`

#### Defined in

tools/utilities.ts:126

___

### empty

▸ `Static` **empty**(`element`): `void`

Removes all child elements of the given element.

#### Parameters

| Name | Type |
| :------ | :------ |
| `element` | `HTMLElement` |

#### Returns

`void`

#### Defined in

tools/utilities.ts:99

___

### getChildFromElement

▸ `Static` **getChildFromElement**(`parent`, `element`, `key`): [`Widget`](Widget.md)

#### Parameters

| Name | Type |
| :------ | :------ |
| `parent` | [`Widget`](Widget.md) |
| `element` | `HTMLElement` |
| `key` | `string` |

#### Returns

[`Widget`](Widget.md)

#### Defined in

tools/utilities.ts:103

___

### getKey

▸ `Static` **getKey**(`event`): [`Key`](../enums/Key.md)

Returns the code of the key that was pressed or released.

#### Parameters

| Name | Type |
| :------ | :------ |
| `event` | `KeyboardEvent` |

#### Returns

[`Key`](../enums/Key.md)

#### Defined in

tools/utilities.ts:27

___

### getModifier

▸ `Static` **getModifier**(`event`): [`Modifier`](../enums/Modifier.md)

Returns the keyboard modifier flag.

#### Parameters

| Name | Type |
| :------ | :------ |
| `event` | `MouseEvent` \| `KeyboardEvent` |

#### Returns

[`Modifier`](../enums/Modifier.md)

#### Defined in

tools/utilities.ts:7

___

### getMouseButton

▸ `Static` **getMouseButton**(`event`): [`MouseButton`](../enums/MouseButton.md)

Returns the mouse button.

#### Parameters

| Name | Type |
| :------ | :------ |
| `event` | `MouseEvent` |

#### Returns

[`MouseButton`](../enums/MouseButton.md)

#### Defined in

tools/utilities.ts:34

___

### index

▸ `Static` **index**(`element`): `number`

Returns the position of the given element relative to its sibling elements.

#### Parameters

| Name | Type |
| :------ | :------ |
| `element` | `HTMLElement` |

#### Returns

`number`

#### Defined in

tools/utilities.ts:72

___

### insertAfter

▸ `Static` **insertAfter**(`element`, `target`): `void`

Insert the element after the given target.

#### Parameters

| Name | Type |
| :------ | :------ |
| `element` | `HTMLElement` |
| `target` | `HTMLElement` |

#### Returns

`void`

#### Defined in

tools/utilities.ts:84

___

### str2Align

▸ `Static` **str2Align**(`str`): [`Alignment`](../enums/Alignment.md)

Converts the given string to a enum [Alignment](../enums/Alignment.md).

#### Parameters

| Name | Type |
| :------ | :------ |
| `str` | `string` |

#### Returns

[`Alignment`](../enums/Alignment.md)

#### Defined in

tools/utilities.ts:143
