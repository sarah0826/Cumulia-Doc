[wui.basic](../README.md) / [Exports](../modules.md) / Range

# Class: Range

The Range class is a range from minimum to maximum.

## Table of contents

### Constructors

- [constructor](Range.md#constructor)

### Properties

- [m\_maximum](Range.md#m_maximum)
- [m\_minimum](Range.md#m_minimum)

### Accessors

- [maximum](Range.md#maximum)
- [minimum](Range.md#minimum)

### Methods

- [add](Range.md#add)
- [addValue](Range.md#addvalue)
- [center](Range.md#center)
- [clone](Range.md#clone)
- [compare](Range.md#compare)
- [copy](Range.md#copy)
- [inRange](Range.md#inrange)
- [isValid](Range.md#isvalid)
- [length](Range.md#length)
- [relativeOf](Range.md#relativeof)
- [set](Range.md#set)
- [unset](Range.md#unset)

## Constructors

### constructor

• **new Range**(`minimum?`, `maximum?`)

Constructs a range with the given minimum and maximum.

#### Parameters

| Name | Type | Default value | Description |
| :------ | :------ | :------ | :------ |
| `minimum` | `number` | `0` | The default value is 0. |
| `maximum` | `number` | `1.0` | The default value is 1.0. |

#### Defined in

core/range.ts:13

## Properties

### m\_maximum

• `Private` **m\_maximum**: `number`

#### Defined in

core/range.ts:6

___

### m\_minimum

• `Private` **m\_minimum**: `number`

#### Defined in

core/range.ts:5

## Accessors

### maximum

• `get` **maximum**(): `number`

Returns the range's maximum value.

#### Returns

`number`

#### Defined in

core/range.ts:35

• `set` **maximum**(`maximum`): `void`

Sets the range's maximum value to maximum.

#### Parameters

| Name | Type |
| :------ | :------ |
| `maximum` | `number` |

#### Returns

`void`

#### Defined in

core/range.ts:42

___

### minimum

• `get` **minimum**(): `number`

Returns the range's minimum value.

#### Returns

`number`

#### Defined in

core/range.ts:21

• `set` **minimum**(`minimum`): `void`

Sets the range's minimum value to minimum.

#### Parameters

| Name | Type |
| :------ | :------ |
| `minimum` | `number` |

#### Returns

`void`

#### Defined in

core/range.ts:28

## Methods

### add

▸ **add**(`range`): `void`

Adds the given range to this range.

#### Parameters

| Name | Type |
| :------ | :------ |
| `range` | [`Range`](Range.md) |

#### Returns

`void`

#### Defined in

core/range.ts:104

___

### addValue

▸ **addValue**(`value`): `void`

Adds the given value to this range.

#### Parameters

| Name | Type |
| :------ | :------ |
| `value` | `number` |

#### Returns

`void`

#### Defined in

core/range.ts:112

___

### center

▸ **center**(): `number`

Returns the center value of the range.

#### Returns

`number`

#### Defined in

core/range.ts:57

___

### clone

▸ **clone**(): [`Range`](Range.md)

Returns a copy of this range.

#### Returns

[`Range`](Range.md)

#### Defined in

core/range.ts:128

___

### compare

▸ **compare**(`other`): `boolean`

Returns true if this range and other are equal; otherwise returns false.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Range`](Range.md) |

#### Returns

`boolean`

#### Defined in

core/range.ts:135

___

### copy

▸ **copy**(`other`): `void`

Copies the other range to this range.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Range`](Range.md) |

#### Returns

`void`

#### Defined in

core/range.ts:120

___

### inRange

▸ **inRange**(`value`): `boolean`

Returns true if the given value is in the range, otherwise returns false.

#### Parameters

| Name | Type |
| :------ | :------ |
| `value` | `number` |

#### Returns

`boolean`

#### Defined in

core/range.ts:71

___

### isValid

▸ **isValid**(): `boolean`

Returns true if the range is valid(minimum <= maximum), otherwise returns false.

#### Returns

`boolean`

#### Defined in

core/range.ts:89

___

### length

▸ **length**(): `number`

Returns the length of the range.

#### Returns

`number`

#### Defined in

core/range.ts:64

___

### relativeOf

▸ **relativeOf**(`value`): `number`

Returns the ratio of the given value to the range.

#### Parameters

| Name | Type |
| :------ | :------ |
| `value` | `number` |

#### Returns

`number`

#### Defined in

core/range.ts:78

___

### set

▸ **set**(`minimum`, `maximum`): `void`

Sets the range's minimum and maximum value.

#### Parameters

| Name | Type |
| :------ | :------ |
| `minimum` | `number` |
| `maximum` | `number` |

#### Returns

`void`

#### Defined in

core/range.ts:49

___

### unset

▸ **unset**(): `void`

Resets the range.

#### Returns

`void`

#### Defined in

core/range.ts:96
