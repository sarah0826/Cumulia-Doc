[wui.basic](../README.md) / [Exports](../modules.md) / Size

# Class: Size

The Size is specified by a x(width) and a y(height).

## Table of contents

### Constructors

- [constructor](Size.md#constructor)

### Properties

- [m\_x](Size.md#m_x)
- [m\_y](Size.md#m_y)

### Accessors

- [x](Size.md#x)
- [y](Size.md#y)

### Methods

- [boundedTo](Size.md#boundedto)
- [clone](Size.md#clone)
- [compare](Size.md#compare)
- [copy](Size.md#copy)
- [expandedTo](Size.md#expandedto)
- [isNull](Size.md#isnull)
- [isValid](Size.md#isvalid)

## Constructors

### constructor

• **new Size**(`x?`, `y?`)

Constructs a size with the given x(width) and y(height).

#### Parameters

| Name | Type | Default value |
| :------ | :------ | :------ |
| `x` | `number` | `0` |
| `y` | `number` | `0` |

#### Defined in

core/size.ts:11

## Properties

### m\_x

• `Private` **m\_x**: `number`

#### Defined in

core/size.ts:5

___

### m\_y

• `Private` **m\_y**: `number`

#### Defined in

core/size.ts:6

## Accessors

### x

• `get` **x**(): `number`

Returns the width of this size.

#### Returns

`number`

#### Defined in

core/size.ts:19

• `set` **x**(`x`): `void`

Sets the width to the given x.

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |

#### Returns

`void`

#### Defined in

core/size.ts:26

___

### y

• `get` **y**(): `number`

Returns the height of this size.

#### Returns

`number`

#### Defined in

core/size.ts:33

• `set` **y**(`y`): `void`

Sets the height to the given y.

#### Parameters

| Name | Type |
| :------ | :------ |
| `y` | `number` |

#### Returns

`void`

#### Defined in

core/size.ts:40

## Methods

### boundedTo

▸ **boundedTo**(`other`): [`Size`](Size.md)

Returns a size holding the minimum width and height of this size and the given other.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Size`](Size.md) |

#### Returns

[`Size`](Size.md)

#### Defined in

core/size.ts:70

___

### clone

▸ **clone**(): [`Size`](Size.md)

Returns a copy of this size.

#### Returns

[`Size`](Size.md)

#### Defined in

core/size.ts:87

___

### compare

▸ **compare**(`other`): `boolean`

Returns true if this size and other are equal; otherwise returns false.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Size`](Size.md) |

#### Returns

`boolean`

#### Defined in

core/size.ts:94

___

### copy

▸ **copy**(`other`): `void`

Copies the other size to this size.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Size`](Size.md) |

#### Returns

`void`

#### Defined in

core/size.ts:79

___

### expandedTo

▸ **expandedTo**(`other`): [`Size`](Size.md)

Returns a size holding the maximum width and height of this size and the given other.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | [`Size`](Size.md) |

#### Returns

[`Size`](Size.md)

#### Defined in

core/size.ts:61

___

### isNull

▸ **isNull**(): `boolean`

Returns true if both the width and height is 0; otherwise returns false.

#### Returns

`boolean`

#### Defined in

core/size.ts:47

___

### isValid

▸ **isValid**(): `boolean`

Returns true if both the width and height is equal to or greater than 0; otherwise returns false.

#### Returns

`boolean`

#### Defined in

core/size.ts:54
